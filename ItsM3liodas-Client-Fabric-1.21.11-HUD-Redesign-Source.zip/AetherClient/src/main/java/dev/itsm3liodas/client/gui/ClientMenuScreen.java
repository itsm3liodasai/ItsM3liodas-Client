package dev.itsm3liodas.client.gui;

import dev.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A compact, client-side settings interface. */
public final class ClientMenuScreen extends Screen {
    private int page = 0;
    private static final int ACCENT_DEFAULT = 0x45B7FF;

    public ClientMenuScreen() { super(Component.literal("ItsM3liodas Client")); }

    @Override protected void init() { rebuild(); }

    private int panelLeft() { return width / 2 - 190; }
    private int panelTop() { return height / 2 - 145; }

    private void rebuild() {
        clearWidgets();
        int left = panelLeft();
        int top = panelTop();
        int navX = left + 14;
        int contentX = left + 126;
        int contentW = 244;

        addRenderableWidget(nav("HUD", 0, navX, top + 67, page == 0));
        addRenderableWidget(nav("Appearance", 1, navX, top + 94, page == 1));
        addRenderableWidget(nav("Reset", 2, navX, top + 121, page == 2));
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + 14, top + 245, 96, 20).build());

        if (page == 0) {
            addRenderableWidget(Button.builder(Component.literal("FPS  " + state("showFps")), b -> flip("showFps"))
                    .bounds(contentX, top + 68, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Ping  " + state("showPing")), b -> flip("showPing"))
                    .bounds(contentX, top + 96, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Coordinates  " + state("showCoordinates")), b -> flip("showCoordinates"))
                    .bounds(contentX, top + 124, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Direction  " + state("showDirection")), b -> flip("showDirection"))
                    .bounds(contentX, top + 152, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Clock  " + state("showClock")), b -> flip("showClock"))
                    .bounds(contentX, top + 180, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Armor  " + state("showArmor")), b -> flip("showArmor"))
                    .bounds(contentX, top + 208, 116, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Effects  " + state("showEffects")), b -> flip("showEffects"))
                    .bounds(contentX + 122, top + 208, 122, 22).build());
        } else if (page == 1) {
            addRenderableWidget(Button.builder(Component.literal("Theme  ·  " + ClientConfig.get().theme), b -> {
                String[] themes = {"DARK", "LIGHT", "BLUE", "CUSTOM"};
                int i = 0; for (; i < themes.length; i++) if (themes[i].equals(ClientConfig.get().theme)) break;
                ClientConfig.get().theme = themes[(i + 1) % themes.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Accent  ·  " + String.format("#%06X", ClientConfig.get().accent)), b -> {
                int[] colors = {0x00B2FF, 0x9B7BFF, 0x35D49A, 0xFF9D45, 0xFF6FAE};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().accent) break;
                ClientConfig.get().accent = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD scale  ·  " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD opacity  ·  " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 171, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Compact HUD  ·  " + state("compactHud")), b -> flip("compactHud"))
                    .bounds(contentX, top + 203, contentW, 24).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Restore default settings"), b -> { ClientConfig.reset(); rebuild(); })
                    .bounds(contentX, top + 90, contentW, 26).build());
        }
    }

    private Button nav(String label, int target, int x, int y, boolean selected) {
        return Button.builder(Component.literal((selected ? "◆  " : "   ") + label), b -> { page = target; rebuild(); })
                .bounds(x, y, 96, 22).build();
    }

    private String state(String field) { return readBoolean(field) ? "ON" : "OFF"; }
    private void flip(String field) { writeBoolean(field, !readBoolean(field)); rebuild(); }
    private boolean readBoolean(String field) {
        try { return ClientConfig.Data.class.getField(field).getBoolean(ClientConfig.get()); }
        catch (ReflectiveOperationException ignored) { return false; }
    }
    private void writeBoolean(String field, boolean value) {
        try { ClientConfig.Data.class.getField(field).setBoolean(ClientConfig.get(), value); ClientConfig.save(); }
        catch (ReflectiveOperationException ignored) { }
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int x = panelLeft(), y = panelTop();
        String theme = ClientConfig.get().theme;
        boolean light = theme.equals("LIGHT");
        int panel = light ? 0xF0F3F6FA : theme.equals("BLUE") ? 0xF0122038 : 0xF0111722;
        int sidebar = light ? 0xFFe7ebf1 : 0xFF0B111B;
        int mainText = light ? 0xFF18202C : 0xFFF2F6FC;
        int muted = light ? 0xFF657184 : 0xFF91A0B4;
        int accent = 0xFF000000 | (ClientConfig.get().accent & 0xFFFFFF);
        g.fill(x, y, x + 380, y + 290, 0x90000000);
        g.fill(x + 2, y + 2, x + 378, y + 288, panel);
        g.fill(x + 2, y + 2, x + 378, y + 5, accent);
        g.fill(x + 2, y + 48, x + 378, y + 49, light ? 0xFFD8DEE8 : 0xFF263244);
        g.fill(x + 2, y + 50, x + 116, y + 288, sidebar);
        g.fill(x + 115, y + 50, x + 116, y + 288, light ? 0xFFD8DEE8 : 0xFF263244);
        g.drawString(font, "✦  ITSM3LIODAS", x + 16, y + 15, mainText, false);
        g.drawString(font, "CLIENT", x + 16 + font.width("✦  ITSM3LIODAS") + 6, y + 15, accent, false);
        g.drawString(font, "FABRIC 1.21.11  ·  RIGHT SHIFT", x + 16, y + 31, muted, false);
        String heading = page == 0 ? "HUD ELEMENTS" : page == 1 ? "APPEARANCE" : "SETTINGS";
        String sub = page == 0 ? "Choose the information shown on screen" : page == 1 ? "Make the interface yours" : "Restore the original configuration";
        g.drawString(font, heading, x + 130, y + 17, mainText, false);
        g.drawString(font, sub, x + 130, y + 33, muted, false);
        g.drawString(font, "ITS M3LIODAS CLIENT  /  v1.0", x + 130, y + 268, muted, false);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
