# ItsM3liodas Client

A client-side **Fabric-only** Minecraft mod for **Minecraft Java Edition 1.21.11**. It focuses on readable HUD information, a compact settings menu, and configurable appearance. It contains no combat automation, movement automation, x-ray, ESP, packet manipulation, anti-cheat bypasses, or other unfair gameplay modules.

## Target versions

- Minecraft: **1.21.11 only**
- Mod loader: Fabric Loader 0.18.1 or newer
- Fabric API: 0.141.1+1.21.11
- Java: 21
- Fabric Loom: 1.14-SNAPSHOT (remapping plugin)
- Gradle: 9.2.1 in the GitHub Actions workflow

## Included features

- Right Shift opens the client settings menu.
- Read-only HUD: FPS, ping, coordinates, direction, local clock, armor-piece count and active-effect count.
- Per-element HUD toggles.
- HUD scale, opacity and compact layout settings.
- Dark, Light and Blue theme selection, plus accent-color presets.
- Settings persist in `.minecraft/config/itsm3liodas-client.json`.
- Reset-to-defaults control.
- Fabric client-only entrypoint; it does not need a server plugin.

## Not included yet

This is an initial 1.21.11 port, not a finished premium client. It does not yet include a draggable HUD editor, keystrokes, CPS, individual potion timers, screenshot/resource-pack managers, custom crosshair, hotbar/chat/scoreboard restyling, custom main menu, menu music, named config profiles, or an icon injected beside the player's name in the vanilla TAB list. Those features need separate implementation and testing. The client HUD and menu do not promise a specific FPS increase; for substantial rendering optimizations, use a compatible, separately maintained optimization mod such as Sodium and test compatibility with your modpack.

## Build locally

1. Install JDK 21.
2. Install Gradle 9.2.1 or use the included `gradlew` bootstrap script.
3. From the project root run `./gradlew build` (Linux/macOS) or `gradlew.bat build` (Windows).
4. If successful, the remapped mod JAR is in `build/libs/`.
5. Install Fabric Loader for Minecraft 1.21.11 and place the JAR plus Fabric API 0.141.1+1.21.11 in the instance's `mods` folder.

The bootstrap scripts download Gradle on first use and therefore require internet access. They are lightweight bootstrap scripts, not the official binary Gradle Wrapper JAR.

## GitHub Actions

1. Create an empty GitHub repository.
2. Upload the **contents** of this ZIP's root folder to the repository root.
3. Commit to the `main` branch.
4. Open **Actions**. A push to `main` starts the build automatically.
5. To run manually, choose **Build ItsM3liodas Client** and click **Run workflow**.
6. After a successful run, download the `ItsM3liodas-Client-Fabric-1.21.11` artifact from the run summary.

The workflow fails if Gradle compilation fails or no JAR is produced. It does not upload a fake or placeholder JAR.

## Controls

- **Right Shift**: open the client settings menu.
- Click HUD toggles and appearance controls to change settings; changes are saved automatically.

## Build verification

The project source and version configuration have been updated for Minecraft 1.21.11. A full Gradle build has **not** been run in this environment because Gradle is not installed and external dependency downloads are unavailable here. Use GitHub Actions for the first dependency-resolved compile; if it fails, share the failing log so the exact API/compiler issue can be corrected.
