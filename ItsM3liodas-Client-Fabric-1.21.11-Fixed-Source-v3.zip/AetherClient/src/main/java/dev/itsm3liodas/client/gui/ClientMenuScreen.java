package dev.itsm3liodas.client.gui;

import dev.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ClientMenuScreen extends Screen {
    private int page = 0;

    public ClientMenuScreen() { super(Component.literal("ItsM3liodas Client")); }

    @Override protected void init() { rebuild(); }

    private void rebuild() {
        clearWidgets();
        int left = width / 2 - 145;
        int top = height / 2 - 105;
        addRenderableWidget(Button.builder(Component.literal("HUD"), b -> { page = 0; rebuild(); })
                .bounds(left, top, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Appearance"), b -> { page = 1; rebuild(); })
                .bounds(left + 95, top, 105, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> { page = 2; rebuild(); })
                .bounds(left + 205, top, 85, 20).build());

        int y = top + 34;
        if (page == 0) {
            toggle(left, y, "FPS counter", "showFps"); y += 24;
            toggle(left, y, "Ping", "showPing"); y += 24;
            toggle(left, y, "Coordinates", "showCoordinates"); y += 24;
            toggle(left, y, "Direction", "showDirection"); y += 24;
            toggle(left, y, "Clock", "showClock"); y += 24;
            toggle(left, y, "Armor status", "showArmor"); y += 24;
            toggle(left, y, "Effect count", "showEffects");
        } else if (page == 1) {
            addRenderableWidget(Button.builder(Component.literal("Theme: " + ClientConfig.get().theme), b -> {
                String[] themes = {"DARK", "LIGHT", "BLUE", "CUSTOM"};
                int i = 0;
                for (; i < themes.length; i++) if (themes[i].equals(ClientConfig.get().theme)) break;
                ClientConfig.get().theme = themes[(i + 1) % themes.length]; ClientConfig.save(); rebuild();
            }).bounds(left, y, 220, 20).build());
            y += 27;
            addRenderableWidget(Button.builder(Component.literal("Accent color: " + String.format("#%06X", ClientConfig.get().accent)), b -> {
                int[] colors = {0x45B7FF, 0x9B7BFF, 0x35D49A, 0xFF9D45, 0xFF6FAE};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().accent) break;
                ClientConfig.get().accent = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(left, y, 220, 20).build());
            y += 27;
            addRenderableWidget(Button.builder(Component.literal("HUD scale: " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(left, y, 220, 20).build());
            y += 27;
            addRenderableWidget(Button.builder(Component.literal("HUD opacity: " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(left, y, 220, 20).build());
            y += 27;
            addRenderableWidget(Button.builder(Component.literal("Compact HUD: " + (ClientConfig.get().compactHud ? "ON" : "OFF")), b -> {
                ClientConfig.get().compactHud = !ClientConfig.get().compactHud; ClientConfig.save(); rebuild();
            }).bounds(left, y, 220, 20).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Reset all settings to defaults"), b -> {
                ClientConfig.reset(); rebuild();
            }).bounds(left, y, 230, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(width / 2 - 45, top + 225, 90, 20).build());
    }

    private void toggle(int x, int y, String label, String field) {
        boolean enabled = readBoolean(field);
        addRenderableWidget(Button.builder(Component.literal(label + ": " + (enabled ? "ON" : "OFF")), b -> {
            writeBoolean(field, !readBoolean(field)); rebuild();
        }).bounds(x, y, 220, 20).build());
    }

    private boolean readBoolean(String field) {
        try { return ClientConfig.Data.class.getField(field).getBoolean(ClientConfig.get()); }
        catch (ReflectiveOperationException ignored) { return false; }
    }

    private void writeBoolean(String field, boolean value) {
        try { ClientConfig.Data.class.getField(field).setBoolean(ClientConfig.get(), value); ClientConfig.save(); }
        catch (ReflectiveOperationException ignored) { }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int x = width / 2 - 160, y = height / 2 - 125;
        String theme = ClientConfig.get().theme;
        int panel = switch (theme) {
            case "LIGHT" -> 0xEEF0F3F8;
            case "BLUE" -> 0xEE101F35;
            default -> 0xEE111722;
        };
        int text = theme.equals("LIGHT") ? 0xFF18202C : 0xFFFFFFFF;
        graphics.fill(x, y, x + 320, y + 270, panel);
        graphics.fill(x, y, x + 320, y + 3, 0xFF000000 | (ClientConfig.get().accent & 0xFFFFFF));
        graphics.drawString(font, "✦ ITSM3LIODAS CLIENT", x + 15, y + 12, text, false);
        graphics.drawString(font, "VISUALS  /  CUSTOMIZATION  /  QUALITY OF LIFE", x + 15, y + 25,
                theme.equals("LIGHT") ? 0xFF566273 : 0xFF9BA9BC, false);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
