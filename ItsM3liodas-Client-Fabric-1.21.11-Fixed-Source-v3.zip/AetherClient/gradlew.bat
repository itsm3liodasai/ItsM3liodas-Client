@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=9.2.1
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME=%GRADLE_USER_HOME%\itsm3liodas-wrapper\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\itsm3liodas-wrapper" mkdir "%GRADLE_USER_HOME%\itsm3liodas-wrapper"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%TEMP%\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_USER_HOME%\itsm3liodas-wrapper'"
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
