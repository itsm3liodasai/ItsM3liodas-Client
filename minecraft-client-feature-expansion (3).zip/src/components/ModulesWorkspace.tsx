import React, { useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Crosshair,
  Disc3,
  Download,
  Eye,
  Heart,
  Info,
  Loader2,
  Music,
  Package,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Search,
  ShieldAlert,
  SkipBack,
  SkipForward,
  Star,
  Trash2,
  Upload,
} from 'lucide-react';
import { COLOR_GRADING_PRESETS, MODULE_DEFINITIONS } from '../data/themesAndDocs';
import { formatKeyCodeLabel, LiveWorldTelemetry, MusicPlayerState } from '../store/useClientStore';
import {
  ClientConfig,
  ColorGradingPreset,
  FontFamilyId,
  HandAuraStyle,
  KeybindActionId,
  MotionBlurPreset,
  ParticleStyle,
  PerformancePreset,
  ThemeId,
  ViewmodelItemCategory,
  VisualPackEntry,
} from '../types/client';
import { SliderRow, ToggleRow } from './SettingTooltip';
import { SystemSettingsPanels } from './SystemSettingsPanels';

interface ModulesWorkspaceProps {
  config: ClientConfig;
  setConfig: React.Dispatch<React.SetStateAction<ClientConfig>>;
  world: LiveWorldTelemetry;
  setWorld: React.Dispatch<React.SetStateAction<LiveWorldTelemetry>>;
  musicState: MusicPlayerState;
  onTogglePlayMusic: () => void;
  onStepTrack: (dir: 1 | -1) => void;
  onSelectTrack: (id: string) => void;
  onLoadAudioFile: (file: File) => void;
  onAttachLrc: (raw: string) => void;
  onLookupOnlineLyrics: (artist: string, title: string) => void;
  keybindConflicts: Record<KeybindActionId, KeybindActionId[]>;
  onApplyTheme: (id: ThemeId) => void;
  onApplyMotionBlurPreset: (preset: MotionBlurPreset) => void;
  onApplyColorGradingPreset: (preset: ColorGradingPreset) => void;
  onApplyPerformance: (preset: PerformancePreset) => void;
  onToggleFavorite: (id: string) => void;
  onRecordSetting: (id: string, label: string, category: string) => void;
  onToggleVisualPack: (id: string) => void;
  onImportVisualPack: (raw: string) => boolean;
  onExportConfig: () => void;
  onImportConfig: (raw: string) => void;
  onRestoreBackup: () => void;
  onResetAll: () => void;
  onToast: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

type CategoryTab =
  | 'all'
  | 'favorites'
  | 'Visuals'
  | 'Camera'
  | 'HUD'
  | 'World & Items'
  | 'Packs & Styles'
  | 'themes'
  | 'keybinds'
  | 'performance';

export const ModulesWorkspace: React.FC<ModulesWorkspaceProps> = ({
  config,
  setConfig,
  world,
  setWorld,
  musicState,
  onTogglePlayMusic,
  onStepTrack,
  onSelectTrack,
  onLoadAudioFile,
  onAttachLrc,
  onLookupOnlineLyrics,
  keybindConflicts,
  onApplyTheme,
  onApplyMotionBlurPreset,
  onApplyColorGradingPreset,
  onApplyPerformance,
  onToggleFavorite,
  onRecordSetting,
  onToggleVisualPack,
  onImportVisualPack,
  onExportConfig,
  onImportConfig,
  onRestoreBackup,
  onResetAll,
  onToast,
}) => {
  const [categoryTab, setCategoryTab] = useState<CategoryTab>('all');
  const [search, setSearch] = useState('');
  const [selectedModuleId, setSelectedModuleId] = useState<string>('musicLyrics');
  const [packSearch, setPackSearch] = useState('');
  const [customGradeName, setCustomGradeName] = useState('');
  const [lookupArtist, setLookupArtist] = useState('');
  const [lookupTitle, setLookupTitle] = useState('');
  const packImportRef = useRef<HTMLInputElement | null>(null);
  const audioUploadRef = useRef<HTMLInputElement | null>(null);
  const lrcUploadRef = useRef<HTMLInputElement | null>(null);

  const isModuleEnabled = (id: string): boolean => {
    switch (id) {
      case 'musicLyrics':
        return config.musicLyrics.enabled;
      case 'motionBlur':
        return config.motionBlur.enabled;
      case 'menuBlur':
        return config.menuBlur.enabled;
      case 'nametags':
        return config.nametags.enabled;
      case 'crosshair':
        return config.crosshair.enabled;
      case 'blockOutline':
        return config.blockOutline.enabled;
      case 'itemPhysics':
        return config.itemPhysics.enabled;
      case 'colorGrading':
        return config.colorGrading.enabled;
      case 'visualPacks':
        return config.visualPacks.enabled;
      case 'handAura':
        return config.handAura.enabled;
      case 'zoom':
        return config.zoom.enabled;
      case 'freelook':
        return config.freelook.enabled;
      case 'shulkerPreview':
        return config.shulkerPreview.enabled;
      case 'viewmodel':
        return config.viewmodel.enabled;
      case 'particles':
        return config.particles.enabled;
      default:
        return false;
    }
  };

  const toggleModule = (id: string) => {
    setConfig((c) => {
      switch (id) {
        case 'musicLyrics':
          return { ...c, musicLyrics: { ...c.musicLyrics, enabled: !c.musicLyrics.enabled } };
        case 'motionBlur':
          return { ...c, motionBlur: { ...c.motionBlur, enabled: !c.motionBlur.enabled } };
        case 'menuBlur':
          return { ...c, menuBlur: { ...c.menuBlur, enabled: !c.menuBlur.enabled } };
        case 'nametags':
          return { ...c, nametags: { ...c.nametags, enabled: !c.nametags.enabled } };
        case 'crosshair':
          return { ...c, crosshair: { ...c.crosshair, enabled: !c.crosshair.enabled } };
        case 'blockOutline':
          return { ...c, blockOutline: { ...c.blockOutline, enabled: !c.blockOutline.enabled } };
        case 'itemPhysics':
          return { ...c, itemPhysics: { ...c.itemPhysics, enabled: !c.itemPhysics.enabled } };
        case 'colorGrading':
          return { ...c, colorGrading: { ...c.colorGrading, enabled: !c.colorGrading.enabled } };
        case 'visualPacks':
          return { ...c, visualPacks: { ...c.visualPacks, enabled: !c.visualPacks.enabled } };
        case 'handAura':
          return { ...c, handAura: { ...c.handAura, enabled: !c.handAura.enabled } };
        case 'zoom':
          return { ...c, zoom: { ...c.zoom, enabled: !c.zoom.enabled } };
        case 'freelook':
          return { ...c, freelook: { ...c.freelook, enabled: !c.freelook.enabled } };
        case 'shulkerPreview':
          return { ...c, shulkerPreview: { ...c.shulkerPreview, enabled: !c.shulkerPreview.enabled } };
        case 'viewmodel':
          return { ...c, viewmodel: { ...c.viewmodel, enabled: !c.viewmodel.enabled } };
        case 'particles':
          return { ...c, particles: { ...c.particles, enabled: !c.particles.enabled } };
        default:
          return c;
      }
    });
    onRecordSetting(id, id, 'Module Toggle');
  };

  const filteredModules = useMemo(() => {
    const q = search.trim().toLowerCase();
    return MODULE_DEFINITIONS.filter((m) => {
      if (categoryTab === 'favorites' && !config.favoriteModules.includes(m.id)) return false;
      if (
        categoryTab !== 'all' &&
        categoryTab !== 'favorites' &&
        categoryTab !== 'themes' &&
        categoryTab !== 'keybinds' &&
        categoryTab !== 'performance' &&
        m.category !== categoryTab
      ) {
        return false;
      }
      if (!q) return true;
      return (
        m.name.toLowerCase().includes(q) ||
        m.summary.toLowerCase().includes(q) ||
        m.explanation.toLowerCase().includes(q)
      );
    });
  }, [categoryTab, search, config.favoriteModules]);

  const activeModule = MODULE_DEFINITIONS.find((m) => m.id === selectedModuleId) ?? MODULE_DEFINITIONS[0];
  const isSystemSection = categoryTab === 'themes' || categoryTab === 'keybinds' || categoryTab === 'performance';

  const exportVisualPack = (pack: VisualPackEntry) => {
    const blob = new Blob([JSON.stringify(pack, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pack.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onToast('Visual Pack Exported', `Saved ${pack.name} manifest.`, 'success');
  };

  const renderModuleInspector = () => {
    const accent = config.theme.accentColor;

    switch (activeModule.id) {
      case 'musicLyrics': {
        const currentTrack =
          musicState.tracks.find((t) => t.id === musicState.currentTrackId) ?? musicState.tracks[0];
        return (
          <div className="space-y-3">
            {/* Valence-style Live Player Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/15 bg-black/40 p-3">
              <div className="flex items-center gap-3">
                <div
                  style={{
                    background: `linear-gradient(135deg, ${currentTrack.coverColors[0]}, ${currentTrack.coverColors[1]})`,
                  }}
                  className="flex h-11 w-11 items-center justify-center rounded-lg border border-white/20"
                >
                  <Disc3 className={`h-5 w-5 text-white ${musicState.playing ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">{currentTrack.title}</div>
                  <div className="text-[11px] text-slate-300">{currentTrack.artist} · {currentTrack.lyrics.length} synced lines</div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onStepTrack(-1)}
                  className="rounded-lg border border-white/15 bg-white/5 p-1.5 text-slate-200 hover:bg-white/15"
                >
                  <SkipBack className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={onTogglePlayMusic}
                  style={{ backgroundColor: accent }}
                  className="rounded-lg px-3 py-1.5 text-xs font-semibold text-white"
                >
                  {musicState.playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={() => onStepTrack(1)}
                  className="rounded-lg border border-white/15 bg-white/5 p-1.5 text-slate-200 hover:bg-white/15"
                >
                  <SkipForward className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Track Switcher + Real Local Audio / LRC Upload */}
            <div className="flex flex-wrap items-center gap-1.5">
              {musicState.tracks.map((tr) => (
                <button
                  key={tr.id}
                  type="button"
                  onClick={() => onSelectTrack(tr.id)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] font-medium ${
                    tr.id === musicState.currentTrackId
                      ? 'border-transparent text-white'
                      : 'border-white/10 bg-black/30 text-slate-300 hover:bg-white/10'
                  }`}
                  style={tr.id === musicState.currentTrackId ? { backgroundColor: accent } : undefined}
                >
                  <Music className="mr-1 inline h-3 w-3" />
                  {tr.title}
                </button>
              ))}
              <button
                type="button"
                onClick={() => audioUploadRef.current?.click()}
                className="inline-flex items-center gap-1 rounded-lg border border-emerald-400/35 bg-emerald-500/15 px-2.5 py-1 text-[11px] font-medium text-emerald-200 hover:bg-emerald-500/25"
              >
                <Upload className="h-3 w-3" /> Load MP3/OGG/WAV
              </button>
              <button
                type="button"
                onClick={() => lrcUploadRef.current?.click()}
                className="inline-flex items-center gap-1 rounded-lg border border-sky-400/35 bg-sky-500/15 px-2.5 py-1 text-[11px] font-medium text-sky-200 hover:bg-sky-500/25"
              >
                <Upload className="h-3 w-3" /> Attach .LRC Lyrics
              </button>
              <input
                ref={audioUploadRef}
                type="file"
                accept="audio/*"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onLoadAudioFile(f);
                  e.target.value = '';
                }}
                className="hidden"
              />
              <input
                ref={lrcUploadRef}
                type="file"
                accept=".lrc,.txt"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = new FileReader();
                  r.onload = () => onAttachLrc(String(r.result));
                  r.readAsText(f);
                  e.target.value = '';
                }}
                className="hidden"
              />
            </div>

            {/* Real Async LRCLIB Synced Lyrics Fetcher */}
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-white/10 bg-black/30 p-2.5">
              <input
                type="text"
                value={lookupArtist}
                onChange={(e) => setLookupArtist(e.target.value)}
                placeholder="Artist (e.g. Porter Robinson)"
                className="min-w-[130px] flex-1 rounded border border-white/10 bg-black/40 px-2 py-1 text-xs text-white placeholder-slate-500"
              />
              <input
                type="text"
                value={lookupTitle}
                onChange={(e) => setLookupTitle(e.target.value)}
                placeholder="Track Title (e.g. Sad Machine)"
                className="min-w-[130px] flex-1 rounded border border-white/10 bg-black/40 px-2 py-1 text-xs text-white placeholder-slate-500"
              />
              <button
                type="button"
                disabled={musicState.fetchingLyrics}
                onClick={() => onLookupOnlineLyrics(lookupArtist, lookupTitle)}
                style={{ backgroundColor: accent }}
                className="inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-semibold text-white disabled:opacity-60"
              >
                {musicState.fetchingLyrics ? <Loader2 className="h-3 w-3 animate-spin" /> : <Search className="h-3 w-3" />}
                Fetch Synced Lyrics
              </button>
            </div>

            {/* ValenceMOD Style Customization */}
            <div className="grid grid-cols-2 gap-3">
              <SliderRow
                label="Sky Lyrics Scale"
                value={config.musicLyrics.lyricScale}
                min={0.65}
                max={1.7}
                step={0.05}
                unit="x"
                docKey="musicLyrics.lyricScale"
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, lyricScale: v } }))}
              />
              <SliderRow
                label="Lyrics Opacity"
                value={config.musicLyrics.lyricOpacity}
                min={0.25}
                max={1}
                step={0.05}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, lyricOpacity: v } }))}
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <select
                value={config.musicLyrics.lyricPosition}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    musicLyrics: { ...c.musicLyrics, lyricPosition: e.target.value as ClientConfig['musicLyrics']['lyricPosition'] },
                  }))
                }
                className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-xs text-white"
              >
                <option value="sky-center">Position: Sky Center</option>
                <option value="top-banner">Position: Top Banner</option>
                <option value="above-hotbar">Position: Above Hotbar</option>
              </select>
              <select
                value={config.musicLyrics.lyricFont}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    musicLyrics: { ...c.musicLyrics, lyricFont: e.target.value as FontFamilyId },
                  }))
                }
                className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-xs text-white"
              >
                <option value="space">Font: Space Grotesk</option>
                <option value="inter">Font: Inter Clean</option>
                <option value="mono">Font: JetBrains Mono</option>
                <option value="pixel">Font: Crisp Pixel</option>
              </select>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Lyric Color</span>
                <input
                  type="color"
                  value={config.musicLyrics.lyricColor}
                  onChange={(e) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, lyricColor: e.target.value } }))}
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              <ToggleRow
                label="Floating Sky Lyrics"
                checked={config.musicLyrics.showSkyLyrics}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, showSkyLyrics: v } }))}
              />
              <ToggleRow
                label="Now Playing Card"
                checked={config.musicLyrics.showNowPlayingCard}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, showNowPlayingCard: v } }))}
              />
              <ToggleRow
                label="Album Tint Sync"
                checked={config.musicLyrics.albumTintSync}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, albumTintSync: v } }))}
              />
              <ToggleRow
                label="Lyric Neon Glow"
                checked={config.musicLyrics.lyricGlow}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, lyricGlow: v } }))}
              />
              <ToggleRow
                label="Show Next Line"
                checked={config.musicLyrics.showNextLine}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, showNextLine: v } }))}
              />
              <ToggleRow
                label="Audio Equalizer"
                checked={config.musicLyrics.showEqualizer}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, musicLyrics: { ...c.musicLyrics, showEqualizer: v } }))}
              />
            </div>

            {/* Optional Spotify PKCE Client ID Configuration (Transparent about OAuth) */}
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-emerald-400/20 bg-emerald-950/20 p-2.5 text-xs">
              <input
                type="text"
                value={config.musicLyrics.spotifyClientId}
                onChange={(e) =>
                  setConfig((c) => ({
                    ...c,
                    musicLyrics: {
                      ...c.musicLyrics,
                      spotifyClientId: e.target.value.trim(),
                      spotifyStatus: e.target.value.trim().length > 8 ? 'OAuth PKCE Ready' : 'Local Synced Mode',
                    },
                  }))
                }
                placeholder="Optional Spotify App Client ID (for local MC PKCE polling)"
                className="min-w-[200px] flex-1 rounded border border-white/10 bg-black/40 px-2.5 py-1 font-mono text-[11px] text-white placeholder-slate-500"
              />
              <span className="rounded bg-emerald-500/20 px-2 py-1 text-[10px] font-semibold text-emerald-200">
                {config.musicLyrics.spotifyStatus}
              </span>
            </div>
          </div>
        );
      }

      case 'motionBlur':
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {(['Off', 'Low', 'Medium', 'High', 'Cinematic', 'Custom'] as MotionBlurPreset[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => {
                    onApplyMotionBlurPreset(p);
                    onRecordSetting('motionBlur', `Motion Blur: ${p}`, 'Visuals');
                  }}
                  className={`rounded-lg border px-2.5 py-1 text-xs font-medium ${
                    config.motionBlur.preset === p ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300 hover:bg-white/10'
                  }`}
                  style={config.motionBlur.preset === p ? { backgroundColor: accent } : undefined}
                >
                  {p}
                </button>
              ))}
            </div>
            <SliderRow
              label="Blur Intensity"
              value={config.motionBlur.intensity}
              min={0}
              max={1}
              step={0.05}
              docKey="motionBlur.intensity"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, preset: 'Custom', intensity: v } }))}
            />
            <SliderRow
              label="Blur Duration (Trail Decay)"
              value={config.motionBlur.durationMs}
              min={8}
              max={100}
              step={2}
              unit=" ms"
              docKey="motionBlur.durationMs"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, preset: 'Custom', durationMs: v } }))}
            />
            <SliderRow
              label="Blur Quality Samples"
              value={config.motionBlur.qualitySamples}
              min={2}
              max={16}
              step={1}
              unit=" taps"
              docKey="motionBlur.qualitySamples"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, preset: 'Custom', qualitySamples: v } }))}
            />
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <ToggleRow
                label="Camera Motion Blur"
                checked={config.motionBlur.cameraBlur}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, cameraBlur: v } }))}
              />
              <ToggleRow
                label="Optional GUI Blur"
                checked={config.motionBlur.guiBlur}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, guiBlur: v } }))}
              />
              <ToggleRow
                label="Background Blur"
                checked={config.motionBlur.backgroundBlur}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, motionBlur: { ...c.motionBlur, backgroundBlur: v } }))}
              />
            </div>
            <div className="rounded-xl border border-sky-400/25 bg-sky-950/25 p-3 text-[11px] leading-relaxed text-sky-100">
              <strong className="block text-sky-200">How Intensity, Duration &amp; Quality Affect Visuals &amp; Performance:</strong>
              Intensity sets the blend weight of prior frames; Duration controls how long streaks linger after stopping a camera turn; Quality sets accumulation tap count (2–4 taps are lightweight for laptops, while 12–16 taps yield silky cinema gradients at higher GPU fill-rate cost). Works independently of Menu Blur.
            </div>
          </div>
        );

      case 'menuBlur':
        return (
          <div className="space-y-3">
            <SliderRow
              label="Blur Strength"
              value={config.menuBlur.strength}
              min={0}
              max={24}
              step={1}
              unit="px"
              docKey="menuBlur.strength"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, strength: v } }))}
            />
            <SliderRow
              label="Background Dimming"
              value={config.menuBlur.dimming}
              min={0}
              max={0.85}
              step={0.05}
              docKey="menuBlur.dimming"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, dimming: v } }))}
            />
            <SliderRow
              label="Panel Opacity"
              value={config.menuBlur.opacity}
              min={0.35}
              max={1}
              step={0.05}
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, opacity: v } }))}
            />
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <ToggleRow
                label="Smooth Transitions"
                checked={config.menuBlur.smoothTransitions}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, smoothTransitions: v } }))}
              />
              <ToggleRow
                label="Performance-Friendly Mode"
                description="Caps backdrop blur radius to reduce GPU bandwidth."
                checked={config.menuBlur.performanceFriendly}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, performanceFriendly: v } }))}
              />
              <ToggleRow
                label="Blur Client Menu"
                checked={config.menuBlur.blurClientMenu}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, blurClientMenu: v } }))}
              />
              <ToggleRow
                label="Blur Inventories"
                checked={config.menuBlur.blurInventory}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, menuBlur: { ...c.menuBlur, blurInventory: v } }))}
              />
            </div>
          </div>
        );

      case 'nametags':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Text Color</span>
                <input
                  type="color"
                  value={config.nametags.textColor}
                  onChange={(e) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, textColor: e.target.value } }))}
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
              <select
                value={config.nametags.font}
                onChange={(e) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, font: e.target.value as FontFamilyId } }))}
                className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-xs text-white"
              >
                <option value="inter">Inter Font</option>
                <option value="space">Space Grotesk</option>
                <option value="mono">JetBrains Mono</option>
                <option value="pixel">Pixel Crisp</option>
              </select>
            </div>
            <SliderRow
              label="Text Scale"
              value={config.nametags.size}
              min={0.6}
              max={1.8}
              step={0.05}
              unit="x"
              docKey="nametags.size"
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, size: v } }))}
            />
            <SliderRow
              label="Background Opacity"
              value={config.nametags.backgroundOpacity}
              min={0}
              max={0.95}
              step={0.05}
              accentColor={accent}
              onChange={(v) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, backgroundOpacity: v } }))}
            />
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
              <ToggleRow
                label="Text Shadow"
                checked={config.nametags.textShadow}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, textShadow: v } }))}
              />
              <ToggleRow
                label="Health (When Permitted)"
                checked={config.nametags.showHealthWhenPermitted}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, showHealthWhenPermitted: v } }))}
              />
              <ToggleRow
                label="Distance Scaling"
                checked={config.nametags.distanceScaling}
                accentColor={accent}
                onChange={(v) => setConfig((c) => ({ ...c, nametags: { ...c.nametags, distanceScaling: v } }))}
              />
            </div>
          </div>
        );

      case 'crosshair':
        return (
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-xl border border-white/15 bg-gradient-to-br from-slate-800 to-slate-950 p-3">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                  <Crosshair className="h-3.5 w-3.5" style={{ color: accent }} /> Live Crosshair Preview
                </div>
                <div className="flex flex-wrap gap-1">
                  {[
                    { name: 'M3liodas Cross', size: 8, thickness: 2, gap: 3, dot: true, outline: true },
                    { name: 'Precision Dot', size: 0, thickness: 3, gap: 0, dot: true, outline: true },
                    { name: 'Classic Plus', size: 7, thickness: 2, gap: 0, dot: false, outline: false },
                    { name: 'Wide Arena', size: 10, thickness: 2, gap: 6, dot: true, outline: true },
                  ].map((pr) => (
                    <button
                      key={pr.name}
                      type="button"
                      onClick={() =>
                        setConfig((c) => ({
                          ...c,
                          crosshair: {
                            ...c.crosshair,
                            preset: pr.name,
                            size: pr.size,
                            thickness: pr.thickness,
                            gap: pr.gap,
                            centerDot: pr.dot,
                            outline: pr.outline,
                          },
                        }))
                      }
                      className={`rounded border px-2 py-0.5 text-[11px] ${
                        config.crosshair.preset === pr.name ? 'border-white/40 bg-white/15 text-white' : 'border-white/10 bg-black/30 text-slate-300'
                      }`}
                    >
                      {pr.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className="relative flex h-20 w-20 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-sky-900/40">
                <div style={{ opacity: config.crosshair.opacity }} className="relative">
                  <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, bottom: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px #000' : undefined }} />
                  <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px #000' : undefined }} />
                  <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, right: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px #000' : undefined }} />
                  <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, left: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px #000' : undefined }} />
                  {config.crosshair.centerDot && (
                    <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: -config.crosshair.thickness / 2, width: config.crosshair.thickness, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px #000' : undefined }} />
                  )}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SliderRow label="Arm Length" value={config.crosshair.size} min={0} max={18} step={1} unit="px" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, preset: 'Custom', size: v } }))} />
              <SliderRow label="Thickness" value={config.crosshair.thickness} min={1} max={5} step={1} unit="px" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, preset: 'Custom', thickness: v } }))} />
              <SliderRow label="Center Gap" value={config.crosshair.gap} min={0} max={14} step={1} unit="px" docKey="crosshair.gap" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, preset: 'Custom', gap: v } }))} />
              <SliderRow label="Opacity" value={config.crosshair.opacity} min={0.15} max={1} step={0.05} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, opacity: v } }))} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Color</span>
                <input type="color" value={config.crosshair.color} onChange={(e) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, color: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <ToggleRow label="Center Dot" checked={config.crosshair.centerDot} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, centerDot: v } }))} />
              <ToggleRow label="Outline" checked={config.crosshair.outline} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, outline: v } }))} />
            </div>
          </div>
        );

      case 'blockOutline':
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {[
                { name: 'Midnight Neon', color: '#7C5CFF', thickness: 2.5, opacity: 0.88, glow: true },
                { name: 'Vanilla Crisp', color: '#000000', thickness: 1.5, opacity: 0.55, glow: false },
                { name: 'Blossom Soft', color: '#F472B6', thickness: 2.5, opacity: 0.85, glow: true },
                { name: 'Arctic Cyan', color: '#38BDF8', thickness: 2.0, opacity: 0.9, glow: true },
              ].map((pr) => (
                <button
                  key={pr.name}
                  type="button"
                  onClick={() => setConfig((c) => ({ ...c, blockOutline: { ...c.blockOutline, preset: pr.name, color: pr.color, thickness: pr.thickness, opacity: pr.opacity, glow: pr.glow } }))}
                  className={`rounded-lg border px-2.5 py-1 text-xs ${
                    config.blockOutline.preset === pr.name ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.blockOutline.preset === pr.name ? { backgroundColor: accent } : undefined}
                >
                  {pr.name}
                </button>
              ))}
            </div>
            <SliderRow label="Outline Thickness" value={config.blockOutline.thickness} min={1} max={6} step={0.5} unit="px" docKey="blockOutline.thickness" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, blockOutline: { ...c.blockOutline, thickness: v } }))} />
            <SliderRow label="Outline Opacity" value={config.blockOutline.opacity} min={0.15} max={1} step={0.05} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, blockOutline: { ...c.blockOutline, opacity: v } }))} />
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Outline Color</span>
                <input type="color" value={config.blockOutline.color} onChange={(e) => setConfig((c) => ({ ...c, blockOutline: { ...c.blockOutline, color: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <ToggleRow label="Soft Outer Glow" checked={config.blockOutline.glow} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, blockOutline: { ...c.blockOutline, glow: v } }))} />
            </div>
          </div>
        );

      case 'itemPhysics':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
              {(['Flat Lay', 'Gentle Hover', 'Classic Spin', 'Cinematic Float'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setConfig((c) => ({ ...c, itemPhysics: { ...c.itemPhysics, style: st } }))}
                  className={`rounded-lg border px-2.5 py-1.5 text-xs font-medium ${
                    config.itemPhysics.style === st ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.itemPhysics.style === st ? { backgroundColor: accent } : undefined}
                >
                  {st}
                </button>
              ))}
            </div>
            <SliderRow label="Animation Speed" value={config.itemPhysics.speed} min={0.2} max={2.5} step={0.1} unit="x" docKey="itemPhysics.speed" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, itemPhysics: { ...c.itemPhysics, speed: v } }))} />
            <SliderRow label="Max Animated Items (Perf Cap)" value={config.itemPhysics.maxAnimatedItems} min={8} max={128} step={8} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, itemPhysics: { ...c.itemPhysics, maxAnimatedItems: v } }))} />
            <div className="grid grid-cols-2 gap-2">
              <ToggleRow label="Decorative Rotation" checked={config.itemPhysics.rotation} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, itemPhysics: { ...c.itemPhysics, rotation: v } }))} />
              <ToggleRow label="Smooth Visual Bob" checked={config.itemPhysics.smoothMovement} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, itemPhysics: { ...c.itemPhysics, smoothMovement: v } }))} />
            </div>
          </div>
        );

      case 'colorGrading':
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(COLOR_GRADING_PRESETS) as ColorGradingPreset[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => onApplyColorGradingPreset(p)}
                  className={`rounded-lg border px-2.5 py-1 text-xs font-medium ${
                    config.colorGrading.preset === p ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.colorGrading.preset === p ? { backgroundColor: accent } : undefined}
                >
                  {p}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <SliderRow label="Brightness" value={config.colorGrading.brightness} min={0.6} max={1.5} step={0.02} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', brightness: v } }))} />
              <SliderRow label="Contrast" value={config.colorGrading.contrast} min={0.6} max={1.6} step={0.02} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', contrast: v } }))} />
              <SliderRow label="Saturation" value={config.colorGrading.saturation} min={0} max={1.8} step={0.04} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', saturation: v } }))} />
              <SliderRow label="Temperature (Cool ↔ Warm)" value={config.colorGrading.temperature} min={-0.8} max={0.8} step={0.04} docKey="colorGrading.temperature" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', temperature: v } }))} />
              <SliderRow label="Gamma" value={config.colorGrading.gamma} min={0.6} max={1.6} step={0.02} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', gamma: v } }))} />
              <SliderRow label="Vignette" value={config.colorGrading.vignette} min={0} max={0.85} step={0.05} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, preset: 'Custom', vignette: v } }))} />
            </div>
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-white/10 bg-black/30 p-2.5">
              <span className="text-xs text-slate-300">Filter Tint:</span>
              <input type="color" value={config.colorGrading.filterColor} onChange={(e) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, filterColor: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              <div className="min-w-[140px] flex-1">
                <SliderRow label="Filter Strength" value={config.colorGrading.filterStrength} min={0} max={0.45} step={0.02} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, filterStrength: v } }))} />
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 border-t border-white/10 pt-2">
              <input
                type="text"
                value={customGradeName}
                onChange={(e) => setCustomGradeName(e.target.value)}
                placeholder="Save preset name..."
                className="w-40 rounded-lg border border-white/10 bg-black/40 px-2.5 py-1 text-xs text-white placeholder-slate-500"
              />
              <button
                type="button"
                onClick={() => {
                  const n = customGradeName.trim();
                  if (!n) return;
                  setConfig((c) => ({
                    ...c,
                    colorGrading: {
                      ...c.colorGrading,
                      savedPresets: [
                        ...c.colorGrading.savedPresets,
                        {
                          id: `cg_${Date.now()}`,
                          name: n,
                          brightness: c.colorGrading.brightness,
                          contrast: c.colorGrading.contrast,
                          saturation: c.colorGrading.saturation,
                          temperature: c.colorGrading.temperature,
                          gamma: c.colorGrading.gamma,
                          vignette: c.colorGrading.vignette,
                          filterColor: c.colorGrading.filterColor,
                          filterStrength: c.colorGrading.filterStrength,
                        },
                      ],
                    },
                  }));
                  setCustomGradeName('');
                  onToast('Preset Saved', `Saved "${n}" color grading preset.`, 'success');
                }}
                className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium text-white"
                style={{ backgroundColor: accent }}
              >
                <Plus className="h-3.5 w-3.5" /> Save Preset
              </button>
              {config.colorGrading.savedPresets.map((sp) => (
                <div key={sp.id} className="inline-flex items-center rounded-lg border border-white/15 bg-white/5">
                  <button
                    type="button"
                    onClick={() =>
                      setConfig((c) => ({
                        ...c,
                        colorGrading: { ...c.colorGrading, enabled: true, preset: 'Custom', ...sp },
                      }))
                    }
                    className="px-2 py-1 text-xs text-slate-200 hover:bg-white/10"
                  >
                    {sp.name}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setConfig((c) => ({
                        ...c,
                        colorGrading: {
                          ...c.colorGrading,
                          savedPresets: c.colorGrading.savedPresets.filter((x) => x.id !== sp.id),
                        },
                      }))
                    }
                    className="px-1.5 py-1 text-slate-400 hover:text-rose-300"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'visualPacks': {
        const filteredPacks = config.visualPacks.packs.filter(
          (p) =>
            !packSearch.trim() ||
            p.name.toLowerCase().includes(packSearch.toLowerCase()) ||
            p.description.toLowerCase().includes(packSearch.toLowerCase())
        );
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[180px] flex-1">
                <Search className="absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={packSearch}
                  onChange={(e) => setPackSearch(e.target.value)}
                  placeholder="Search visual packs..."
                  className="w-full rounded-lg border border-white/10 bg-black/40 py-1.5 pr-3 pl-8 text-xs text-white"
                />
              </div>
              <button
                type="button"
                onClick={() => packImportRef.current?.click()}
                className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-xs text-white hover:bg-white/10"
              >
                <Upload className="h-3.5 w-3.5" /> Import Safe Pack (.json)
              </button>
              <input
                ref={packImportRef}
                type="file"
                accept=".json"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const r = new FileReader();
                  r.onload = () => onImportVisualPack(String(r.result));
                  r.readAsText(f);
                  e.target.value = '';
                }}
                className="hidden"
              />
            </div>
            <div className="space-y-2">
              {filteredPacks.map((pack) => (
                <div key={pack.id} className="rounded-xl border border-white/10 bg-black/30 p-3">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div className="flex h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-white/15">
                        {pack.swatchColors.map((sw, i) => (
                          <div key={i} className="h-full flex-1" style={{ backgroundColor: sw }} />
                        ))}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-xs font-semibold text-white">{pack.name}</span>
                          <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">v{pack.version}</span>
                          {pack.compatible ? (
                            <span className="inline-flex items-center gap-1 rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] text-emerald-300">
                              <CheckCircle2 className="h-3 w-3" /> {pack.mcFormat}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded bg-amber-500/20 px-1.5 py-0.5 text-[10px] text-amber-200">
                              <ShieldAlert className="h-3 w-3" /> {pack.mcFormat}
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 text-[11px] text-slate-300">{pack.description}</p>
                        <div className="mt-1 flex flex-wrap gap-2 text-[10px] text-slate-400">
                          <span>Author: {pack.author}</span>
                          <span>License: {pack.license}</span>
                          <span>Assets: {pack.verifiedAssets.length} validated</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => exportVisualPack(pack)}
                        className="rounded-lg border border-white/10 bg-white/5 p-1.5 text-slate-300 hover:text-white"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onToggleVisualPack(pack.id)}
                        className={`rounded-lg px-2.5 py-1 text-xs font-semibold ${
                          pack.enabled ? 'bg-emerald-500/25 text-emerald-200' : 'bg-white/10 text-slate-300'
                        }`}
                      >
                        {pack.enabled ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      }

      case 'handAura':
        return (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
              {(['Soft Glow', 'Neon', 'Magical', 'Electric', 'Rainbow', 'Minimal Outline'] as HandAuraStyle[]).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setConfig((c) => ({ ...c, handAura: { ...c.handAura, style: st } }))}
                  className={`rounded-lg border px-2 py-1.5 text-[11px] font-medium ${
                    config.handAura.style === st ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.handAura.style === st ? { backgroundColor: accent } : undefined}
                >
                  {st}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SliderRow label="Glow Intensity" value={config.handAura.intensity} min={0.1} max={1} step={0.05} docKey="handAura.intensity" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, intensity: v } }))} />
              <SliderRow label="Aura Size" value={config.handAura.size} min={0.6} max={2.2} step={0.05} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, size: v } }))} />
              <SliderRow label="Transparency" value={config.handAura.transparency} min={0.15} max={1} step={0.05} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, transparency: v } }))} />
              <SliderRow label="Animation Speed" value={config.handAura.animationSpeed} min={0.2} max={2.5} step={0.1} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, animationSpeed: v } }))} />
              <SliderRow label="Particle Amount" value={config.handAura.particleAmount} min={0} max={32} step={2} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, particleAmount: v } }))} />
              <select
                value={config.handAura.quality}
                onChange={(e) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, quality: e.target.value as 'Low' | 'Balanced' | 'High' } }))}
                className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-xs text-white"
              >
                <option value="Low">Quality: Low</option>
                <option value="Balanced">Quality: Balanced</option>
                <option value="High">Quality: High</option>
              </select>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Primary</span>
                <input type="color" value={config.handAura.primaryColor} onChange={(e) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, primaryColor: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Secondary</span>
                <input type="color" value={config.handAura.secondaryColor} onChange={(e) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, secondaryColor: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <ToggleRow label="Held Item Glow" checked={config.handAura.heldItemEffect} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, handAura: { ...c.handAura, heldItemEffect: v } }))} />
            </div>
          </div>
        );

      case 'zoom':
        return (
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-xs">
              <span>Active Keybind: <strong className="font-mono text-white">{formatKeyCodeLabel(config.keybinds.zoom.key)}</strong> ({config.zoom.mode} Mode)</span>
              <button
                type="button"
                onClick={() => setWorld((w) => ({ ...w, zoomEngaged: !w.zoomEngaged }))}
                className="rounded-md px-2.5 py-1 text-xs font-semibold text-white"
                style={{ backgroundColor: world.zoomEngaged ? '#10B981' : accent }}
              >
                {world.zoomEngaged ? 'Zoom Active (Reset)' : 'Test Zoom Live'}
              </button>
            </div>
            <SliderRow label="Zoom Strength" value={config.zoom.strength} min={1.5} max={10} step={0.25} unit="x" docKey="zoom.strength" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, zoom: { ...c.zoom, strength: v } }))} />
            <SliderRow label="Transition Speed" value={config.zoom.transitionSpeed} min={2} max={20} step={1} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, zoom: { ...c.zoom, transitionSpeed: v } }))} />
            <div className="grid grid-cols-2 gap-2">
              <ToggleRow label="Toggle Mode (vs Hold)" checked={config.zoom.mode === 'Toggle'} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, zoom: { ...c.zoom, mode: v ? 'Toggle' : 'Hold' }, keybinds: { ...c.keybinds, zoom: { ...c.keybinds.zoom, mode: v ? 'Toggle' : 'Hold' } } }))} />
              <ToggleRow label="Reduce Sensitivity" checked={config.zoom.reduceSensitivity} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, zoom: { ...c.zoom, reduceSensitivity: v } }))} />
            </div>
          </div>
        );

      case 'freelook':
        return (
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-xs">
              <span>Keybind: <strong className="font-mono text-white">{formatKeyCodeLabel(config.keybinds.freelook.key)}</strong> ({config.freelook.mode})</span>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, freelookEngaged: !w.freelookEngaged }))}
                  className="rounded-md px-2.5 py-1 text-xs font-semibold text-white"
                  style={{ backgroundColor: world.freelookEngaged ? '#0EA5E9' : accent }}
                >
                  <Eye className="mr-1 inline h-3 w-3" /> {world.freelookEngaged ? 'Disable Freelook' : 'Engage Freelook'}
                </button>
                <button
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, freelookEngaged: false, freelookYawOffset: 0, freelookPitchOffset: 0 }))}
                  className="rounded-md border border-white/15 bg-white/5 px-2 py-1 text-xs text-slate-200 hover:bg-white/10"
                >
                  <RotateCcw className="h-3 w-3" />
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SliderRow label="Horizontal Sensitivity" value={config.freelook.horizontalSensitivity} min={0.2} max={2.5} step={0.1} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, horizontalSensitivity: v } }))} />
              <SliderRow label="Vertical Sensitivity" value={config.freelook.verticalSensitivity} min={0.2} max={2.5} step={0.1} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, verticalSensitivity: v } }))} />
              <SliderRow label="Max Horizontal Angle" value={config.freelook.maxHorizontalDeg} min={30} max={180} step={5} unit="°" docKey="freelook.maxHorizontalDeg" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, maxHorizontalDeg: v } }))} />
              <SliderRow label="Max Vertical Angle" value={config.freelook.maxVerticalDeg} min={30} max={89} step={1} unit="°" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, maxVerticalDeg: v } }))} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <ToggleRow label="Toggle Mode" checked={config.freelook.mode === 'Toggle'} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, mode: v ? 'Toggle' : 'Hold' }, keybinds: { ...c.keybinds, freelook: { ...c.keybinds.freelook, mode: v ? 'Toggle' : 'Hold' } } }))} />
              <ToggleRow label="Smooth Camera" checked={config.freelook.smoothMovement} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, smoothMovement: v } }))} />
              <ToggleRow label="3rd Person Support" checked={config.freelook.thirdPersonSupport} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, freelook: { ...c.freelook, thirdPersonSupport: v } }))} />
            </div>
            <div className="rounded-xl border border-amber-400/25 bg-amber-950/20 p-3 text-[11px] text-amber-100">
              <strong>Compatibility &amp; Fair-Play Notice:</strong> Freelook strictly offsets local rendering camera angles (`CameraMixin`) and never sends spoofed rotation packets or changes server facing. Note that certain competitive PvP servers prohibit free-look mods via client policy — disable on restricted servers.
            </div>
          </div>
        );

      case 'shulkerPreview':
        return (
          <div className="space-y-3">
            <SliderRow label="Preview Scale" value={config.shulkerPreview.previewScale} min={0.75} max={1.35} step={0.05} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, shulkerPreview: { ...c.shulkerPreview, previewScale: v } }))} />
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
              {(['M3liodas Glass', 'Obsidian Dark', 'Vanilla Classic', 'Accent Border'] as const).map((bg) => (
                <button
                  key={bg}
                  type="button"
                  onClick={() => setConfig((c) => ({ ...c, shulkerPreview: { ...c.shulkerPreview, backgroundStyle: bg } }))}
                  className={`rounded-lg border px-2 py-1.5 text-[11px] font-medium ${
                    config.shulkerPreview.backgroundStyle === bg ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.shulkerPreview.backgroundStyle === bg ? { backgroundColor: accent } : undefined}
                >
                  {bg}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              <ToggleRow label="Smooth Open" checked={config.shulkerPreview.smoothAnimation} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, shulkerPreview: { ...c.shulkerPreview, smoothAnimation: v } }))} />
              <ToggleRow label="Enchant Glint" checked={config.shulkerPreview.showEnchantments} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, shulkerPreview: { ...c.shulkerPreview, showEnchantments: v } }))} />
              <ToggleRow label="Durability Bars" checked={config.shulkerPreview.showDurability} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, shulkerPreview: { ...c.shulkerPreview, showDurability: v } }))} />
            </div>
            <div className="rounded-lg border border-purple-400/30 bg-purple-950/20 px-3 py-2 text-[11px] text-purple-200">
              <Package className="mr-1.5 inline h-3.5 w-3.5" /> Hover over the purple <strong>BOX</strong> slot on the bottom hotbar in the live viewport to inspect the animated Shulker Box preview!
            </div>
          </div>
        );

      case 'viewmodel': {
        const cat = config.viewmodel.activeCategory;
        const offsets = config.viewmodel.categories[cat];
        const updateCat = (patch: Partial<typeof offsets>) => {
          setConfig((c) => ({
            ...c,
            viewmodel: {
              ...c.viewmodel,
              categories: {
                ...c.viewmodel.categories,
                [cat]: { ...c.viewmodel.categories[cat], ...patch },
              },
            },
          }));
        };
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex gap-1.5">
                {(['swords', 'blocks', 'consumables', 'ranged'] as ViewmodelItemCategory[]).map((vc) => (
                  <button
                    key={vc}
                    type="button"
                    onClick={() => setConfig((c) => ({ ...c, viewmodel: { ...c.viewmodel, activeCategory: vc } }))}
                    className={`rounded-lg border px-2.5 py-1 text-xs font-medium capitalize ${
                      cat === vc ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                    }`}
                    style={cat === vc ? { backgroundColor: accent } : undefined}
                  >
                    {vc}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => updateCat({ handX: 0, handY: 0, handZ: 0, itemX: 0, itemY: 0, itemZ: 0, scale: 1, rotX: 0, rotY: 0, rotZ: 0 })}
                className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/10"
              >
                <RotateCcw className="h-3 w-3" /> Reset Category
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SliderRow label="Hand Horizontal (X)" value={offsets.handX} min={-0.8} max={0.8} step={0.02} accentColor={accent} onChange={(v) => updateCat({ handX: v })} />
              <SliderRow label="Hand Vertical (Y)" value={offsets.handY} min={-0.8} max={0.8} step={0.02} accentColor={accent} onChange={(v) => updateCat({ handY: v })} />
              <SliderRow label="Item Offset (X)" value={offsets.itemX} min={-0.6} max={0.6} step={0.02} accentColor={accent} onChange={(v) => updateCat({ itemX: v })} />
              <SliderRow label="Item Offset (Y)" value={offsets.itemY} min={-0.6} max={0.6} step={0.02} accentColor={accent} onChange={(v) => updateCat({ itemY: v })} />
              <SliderRow label="Scale" value={offsets.scale} min={0.5} max={1.6} step={0.05} unit="x" accentColor={accent} onChange={(v) => updateCat({ scale: v })} />
              <SliderRow label="Rotation (Roll Z)" value={offsets.rotZ} min={-45} max={45} step={1} unit="°" accentColor={accent} onChange={(v) => updateCat({ rotZ: v })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <ToggleRow label="Show Right Hand" checked={config.viewmodel.rightHandEnabled} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, viewmodel: { ...c.viewmodel, rightHandEnabled: v } }))} />
              <ToggleRow label="Mirror Left Offhand" checked={config.viewmodel.leftHandEnabled} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, viewmodel: { ...c.viewmodel, leftHandEnabled: v } }))} />
            </div>
          </div>
        );
      }

      case 'particles':
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {(['Starlight Sparkles', 'Sakura Petals', 'Ember Sparks', 'Frost Snowflakes', 'Void Motes', 'Enchant Runes', 'Neon Rings'] as ParticleStyle[]).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setConfig((c) => ({ ...c, particles: { ...c.particles, style: st } }))}
                  className={`rounded-lg border px-2.5 py-1 text-xs ${
                    config.particles.style === st ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300'
                  }`}
                  style={config.particles.style === st ? { backgroundColor: accent } : undefined}
                >
                  {st}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <SliderRow label="Particle Amount" value={config.particles.amount} min={4} max={100} step={4} docKey="particles.amount" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, particles: { ...c.particles, amount: v } }))} />
              <SliderRow label="Particle Size" value={config.particles.size} min={0.4} max={2.5} step={0.1} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, particles: { ...c.particles, size: v } }))} />
              <SliderRow label="Transparency" value={config.particles.transparency} min={0.15} max={1} step={0.05} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, particles: { ...c.particles, transparency: v } }))} />
              <SliderRow label="Animation Speed" value={config.particles.speed} min={0.2} max={2.5} step={0.1} unit="x" accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, particles: { ...c.particles, speed: v } }))} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Color 1</span>
                <input type="color" value={config.particles.primaryColor} onChange={(e) => setConfig((c) => ({ ...c, particles: { ...c.particles, primaryColor: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Color 2</span>
                <input type="color" value={config.particles.secondaryColor} onChange={(e) => setConfig((c) => ({ ...c, particles: { ...c.particles, secondaryColor: e.target.value } }))} className="h-5 w-7 cursor-pointer bg-transparent" />
              </label>
              <ToggleRow label="Perf Mode" checked={config.particles.performanceMode} accentColor={accent} onChange={(v) => setConfig((c) => ({ ...c, particles: { ...c.particles, performanceMode: v } }))} />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex h-full flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-2.5">
        <div className="flex flex-wrap gap-1">
          {(
            [
              { id: 'all', label: 'All Modules' },
              { id: 'favorites', label: `Favorites (${config.favoriteModules.length})` },
              { id: 'Visuals', label: 'Visuals' },
              { id: 'Camera', label: 'Camera' },
              { id: 'HUD', label: 'HUD, Music & Crosshair' },
              { id: 'World & Items', label: 'World & Items' },
              { id: 'Packs & Styles', label: 'Visual Packs' },
              { id: 'themes', label: 'Themes & Motion' },
              { id: 'keybinds', label: 'Keybinds' },
              { id: 'performance', label: 'Performance & Config' },
            ] as { id: CategoryTab; label: string }[]
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setCategoryTab(t.id)}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
                categoryTab === t.id ? 'text-white shadow' : 'text-slate-300 hover:bg-white/10'
              }`}
              style={categoryTab === t.id ? { backgroundColor: config.theme.accentColor } : undefined}
            >
              {t.label}
            </button>
          ))}
        </div>

        {!isSystemSection && (
          <div className="relative min-w-[200px]">
            <Search className="absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search modules..."
              className="w-full rounded-lg border border-white/10 bg-black/40 py-1.5 pr-3 pl-8 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>
        )}
      </div>

      {config.recentSettings.length > 0 && !isSystemSection && (
        <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/10 bg-black/25 px-3 py-1.5 text-[11px]">
          <span className="flex items-center gap-1 font-medium text-slate-400">
            <Clock className="h-3 w-3" /> Recent:
          </span>
          {config.recentSettings.slice(0, 5).map((r) => (
            <button
              key={`${r.id}_${r.timestamp}`}
              type="button"
              onClick={() => {
                if (MODULE_DEFINITIONS.some((m) => m.id === r.id)) {
                  setSelectedModuleId(r.id);
                }
              }}
              className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-slate-200 hover:bg-white/15"
            >
              {r.label}
            </button>
          ))}
        </div>
      )}

      {isSystemSection ? (
        <div className="flex-1 overflow-y-auto pr-1">
          <SystemSettingsPanels
            section={categoryTab}
            config={config}
            setConfig={setConfig}
            world={world}
            keybindConflicts={keybindConflicts}
            onApplyTheme={onApplyTheme}
            onApplyPerformance={onApplyPerformance}
            onExportConfig={onExportConfig}
            onImportConfig={onImportConfig}
            onRestoreBackup={onRestoreBackup}
            onResetAll={onResetAll}
            onToast={onToast}
          />
        </div>
      ) : (
        <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="max-h-[480px] space-y-2 overflow-y-auto pr-1 lg:col-span-5">
            {filteredModules.map((mod) => {
              const enabled = isModuleEnabled(mod.id);
              const selected = activeModule.id === mod.id;
              const fav = config.favoriteModules.includes(mod.id);
              const kbCode = mod.keybindAction ? config.keybinds[mod.keybindAction]?.key : undefined;
              return (
                <div
                  key={mod.id}
                  onClick={() => setSelectedModuleId(mod.id)}
                  className={`cursor-pointer rounded-xl border p-3 transition-all ${
                    selected ? 'border-white/35 bg-white/[0.10] shadow-lg' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-xs font-semibold text-white">{mod.name}</span>
                        <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">{mod.category}</span>
                        {kbCode && (
                          <span className="rounded border border-white/15 bg-black/40 px-1.5 py-0.5 font-mono text-[10px] text-sky-300">
                            [{formatKeyCodeLabel(kbCode)}]
                          </span>
                        )}
                      </div>
                      <p className="mt-1 text-[11px] text-slate-300">{mod.summary}</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(mod.id);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-400"
                      >
                        {fav ? <Heart className="h-3.5 w-3.5 fill-rose-400 text-rose-400" /> : <Star className="h-3.5 w-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleModule(mod.id);
                        }}
                        style={enabled ? { backgroundColor: config.theme.accentColor } : undefined}
                        className={`rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                          enabled ? 'text-white' : 'bg-white/10 text-slate-400 hover:text-white'
                        }`}
                      >
                        {enabled ? 'ON' : 'OFF'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="max-h-[480px] space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-4 lg:col-span-7">
            <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">{activeModule.name}</h3>
                  <span className="rounded-md bg-white/10 px-2 py-0.5 text-[10px] font-medium text-slate-300">
                    {activeModule.category}
                  </span>
                </div>
                <p className="mt-1 flex items-start gap-1.5 text-xs text-slate-300">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-300" />
                  <span>{activeModule.explanation}</span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => toggleModule(activeModule.id)}
                style={isModuleEnabled(activeModule.id) ? { backgroundColor: config.theme.accentColor } : undefined}
                className={`shrink-0 rounded-lg px-3.5 py-1.5 text-xs font-semibold text-white transition-colors ${
                  isModuleEnabled(activeModule.id) ? '' : 'bg-white/15 text-slate-300 hover:bg-white/25'
                }`}
              >
                {isModuleEnabled(activeModule.id) ? 'Enabled' : 'Disabled'}
              </button>
            </div>

            {renderModuleInspector()}
          </div>
        </div>
      )}
    </div>
  );
};
