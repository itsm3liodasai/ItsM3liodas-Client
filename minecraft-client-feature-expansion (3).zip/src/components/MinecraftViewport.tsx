import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Compass,
  Disc3,
  Eye,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { LiveWorldTelemetry, MusicPlayerState } from '../store/useClientStore';
import { ClientConfig, FontFamilyId, HudElementConfig, HudElementId } from '../types/client';
import { ArmorPixelIcon, ArmorSlotKind } from './ArmorIcons';

interface MinecraftViewportProps {
  config: ClientConfig;
  world: LiveWorldTelemetry;
  setWorld: React.Dispatch<React.SetStateAction<LiveWorldTelemetry>>;
  musicState?: MusicPlayerState;
  onTogglePlayMusic?: () => void;
  onStepTrack?: (dir: 1 | -1) => void;
  onMouseAction: (btn: 0 | 2, down: boolean) => void;
  interactiveMode?: boolean;
  onUpdateHudPosition?: (id: HudElementId, x: number, y: number) => void;
  selectedHudId?: HudElementId | null;
  onSelectHudId?: (id: HudElementId) => void;
  hudEditMode?: boolean;
}

const FONT_CSS: Record<FontFamilyId, string> = {
  inter: "'Inter', sans-serif",
  space: "'Space Grotesk', sans-serif",
  mono: "'JetBrains Mono', monospace",
  pixel: "'JetBrains Mono', monospace",
};

const SHULKER_CONTENTS = [
  { name: 'Netherite Sword', count: 1, color: '#64748B', enchant: 'Sharpness V · Unbreaking III', dur: 94 },
  { name: 'Enchanted Golden Apple', count: 12, color: '#FACC15', enchant: 'Glint', dur: null },
  { name: 'Totem of Undying', count: 1, color: '#FDE047', enchant: null, dur: null },
  { name: 'Ender Pearl', count: 16, color: '#14B8A6', enchant: null, dur: null },
  { name: 'Diamond Pickaxe', count: 1, color: '#38BDF8', enchant: 'Efficiency V · Silk Touch', dur: 76 },
  { name: 'Chorus Fruit', count: 32, color: '#C084FC', enchant: null, dur: null },
  { name: 'Potion of Swiftness II', count: 1, color: '#7DD3FC', enchant: 'Speed II (1:30)', dur: null },
  { name: 'Rocket Firework', count: 64, color: '#F43F5E', enchant: 'Flight Duration 3', dur: null },
  { name: 'Obsidian', count: 64, color: '#312E81', enchant: null, dur: null },
];

export const MinecraftViewport: React.FC<MinecraftViewportProps> = ({
  config,
  world,
  setWorld,
  musicState,
  onTogglePlayMusic,
  onStepTrack,
  onMouseAction,
  interactiveMode = true,
  onUpdateHudPosition,
  selectedHudId,
  onSelectHudId,
  hudEditMode = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const trailCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [shulkerHovered, setShulkerHovered] = useState(false);
  const [clockTick, setClockTick] = useState(() => new Date());
  const draggingHudRef = useRef<{ id: HudElementId; offsetX: number; offsetY: number } | null>(null);
  const camDragRef = useRef<{ active: boolean; lastX: number; lastY: number }>({ active: false, lastX: 0, lastY: 0 });
  const zoomAnimRef = useRef(1.0);
  const prevAnglesRef = useRef({ yaw: world.yaw, pitch: world.pitch });
  const fpsCounterRef = useRef({ frames: 0, lastReport: performance.now() });

  useEffect(() => {
    const id = window.setInterval(() => setClockTick(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const activePacks = useMemo(
    () => new Set(config.visualPacks.enabled ? config.visualPacks.packs.filter((p) => p.enabled).map((p) => p.id) : []),
    [config.visualPacks]
  );

  // Active Track & Synced Lyric Line (ValenceMOD inspired)
  const activeTrack = useMemo(() => {
    if (!musicState) return null;
    return musicState.tracks.find((t) => t.id === musicState.currentTrackId) ?? musicState.tracks[0] ?? null;
  }, [musicState]);

  const lyricCursor = useMemo(() => {
    if (!activeTrack || !musicState) return { prev: null, current: null, next: null };
    const pos = musicState.positionSec;
    let activeIdx = 0;
    for (let i = 0; i < activeTrack.lyrics.length; i++) {
      if (activeTrack.lyrics[i].timeSec <= pos) activeIdx = i;
      else break;
    }
    return {
      prev: activeIdx > 0 ? activeTrack.lyrics[activeIdx - 1] : null,
      current: activeTrack.lyrics[activeIdx] ?? null,
      next: activeIdx + 1 < activeTrack.lyrics.length ? activeTrack.lyrics[activeIdx + 1] : null,
    };
  }, [activeTrack, musicState]);

  // Main real-time viewport canvas engine
  useEffect(() => {
    let raf = 0;
    const start = performance.now();

    const maxP = 120;
    const particlePool = Array.from({ length: maxP }, (_, i) => ({
      x: ((i * 73) % 1000) / 1000,
      y: ((i * 197) % 1000) / 1000,
      vx: ((i % 13) - 6) * 0.008,
      vy: 0.02 + (i % 7) * 0.008,
      phase: i * 0.65,
    }));

    const renderFrame = (now: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const dpr = config.performance.reducedQualityMode ? 1 : Math.min(window.devicePixelRatio || 1, 1.75);
      const rect = canvas.getBoundingClientRect();
      const targetW = Math.max(320, Math.round(rect.width * dpr));
      const targetH = Math.max(200, Math.round(rect.height * dpr));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      fpsCounterRef.current.frames += 1;
      const elapsedFps = now - fpsCounterRef.current.lastReport;
      if (elapsedFps >= 500) {
        const measured = Math.round((fpsCounterRef.current.frames * 1000) / elapsedFps);
        const ft = Number((elapsedFps / fpsCounterRef.current.frames).toFixed(1));
        fpsCounterRef.current.frames = 0;
        fpsCounterRef.current.lastReport = now;
        setWorld((w) => (w.fps === measured ? w : { ...w, fps: measured, frameTimeMs: ft }));
      }

      const w = canvas.width;
      const h = canvas.height;
      const t = (now - start) * 0.001;

      const targetZoom = config.zoom.enabled && world.zoomEngaged ? config.zoom.strength : 1.0;
      const lerpAlpha = Math.min(1, 0.016 * config.zoom.transitionSpeed * 1.4);
      zoomAnimRef.current += (targetZoom - zoomAnimRef.current) * lerpAlpha;
      const zoomFactor = zoomAnimRef.current;

      const camYaw = world.yaw + (config.freelook.enabled ? world.freelookYawOffset : 0);
      const camPitch = world.pitch + (config.freelook.enabled ? world.freelookPitchOffset : 0);

      const dYaw = camYaw - prevAnglesRef.current.yaw;
      const dPitch = camPitch - prevAnglesRef.current.pitch;
      prevAnglesRef.current = { yaw: camYaw, pitch: camPitch };
      const camVelocity = Math.min(1.0, Math.hypot(dYaw, dPitch) / 6.0);

      // 1. Skybox
      const hasStarSky = activePacks.has('pack_starlight_sky');
      const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.65);
      if (hasStarSky) {
        skyGrad.addColorStop(0, '#090D26');
        skyGrad.addColorStop(0.55, '#1B1A4B');
        skyGrad.addColorStop(1, '#37306B');
      } else {
        skyGrad.addColorStop(0, '#10224A');
        skyGrad.addColorStop(0.6, '#28528B');
        skyGrad.addColorStop(1, '#68A3D8');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, w, h);

      const horizonY = h * (0.48 - (camPitch / 90) * 0.45);
      const panShift = ((camYaw % 360) / 360) * w;

      if (hasStarSky) {
        ctx.fillStyle = 'rgba(226, 232, 240, 0.78)';
        for (let i = 0; i < 42; i++) {
          const sx = (((i * 173 - panShift * 0.8) % w) + w) % w;
          const sy = (i * 89) % Math.max(40, horizonY);
          const sz = (i % 3 === 0 ? 2.1 : 1.2) * dpr;
          ctx.fillRect(sx, sy, sz, sz);
        }
      }
      const celX = (((w * 0.72 - panShift) % w) + w) % w;
      const celY = horizonY - h * 0.25;
      ctx.fillStyle = hasStarSky ? '#E2E8F0' : '#FEF08A';
      ctx.shadowColor = hasStarSky ? '#818CF8' : '#FACC15';
      ctx.shadowBlur = 24 * dpr;
      ctx.fillRect(celX - 18 * dpr * zoomFactor, celY - 18 * dpr * zoomFactor, 36 * dpr * zoomFactor, 36 * dpr * zoomFactor);
      ctx.shadowBlur = 0;

      ctx.fillStyle = hasStarSky ? '#12152E' : '#1E3A5F';
      ctx.beginPath();
      ctx.moveTo(0, horizonY + 20);
      for (let i = 0; i <= 12; i++) {
        const mx = (i / 12) * w;
        const peak = Math.sin(i * 1.1 + camYaw * 0.025) * 32 * dpr * zoomFactor + Math.cos(i * 2.3) * 16 * dpr;
        ctx.lineTo(mx, horizonY - Math.abs(peak));
      }
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fill();

      // 2. Voxel Terrain Plane
      const hasCrispBlocks = activePacks.has('pack_crisp_borders');
      const groundGrad = ctx.createLinearGradient(0, horizonY, 0, h);
      groundGrad.addColorStop(0, hasStarSky ? '#1B332A' : '#2D5A36');
      groundGrad.addColorStop(0.4, hasStarSky ? '#142423' : '#22472B');
      groundGrad.addColorStop(1, '#0F181D');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, horizonY, w, h - horizonY);

      ctx.strokeStyle = hasCrispBlocks ? 'rgba(255,255,255,0.09)' : 'rgba(15, 23, 42, 0.28)';
      ctx.lineWidth = 1;
      for (let row = 1; row <= 8; row++) {
        const py = horizonY + Math.pow(row / 8, 1.7) * (h - horizonY);
        ctx.beginPath();
        ctx.moveTo(0, py);
        ctx.lineTo(w, py);
        ctx.stroke();
      }
      for (let col = -6; col <= 6; col++) {
        const offset = (col - (camYaw % 45) / 45) * 75 * zoomFactor * dpr;
        ctx.beginPath();
        ctx.moveTo(w / 2 + offset * 0.25, horizonY);
        ctx.lineTo(w / 2 + offset * 2.1, h);
        ctx.stroke();
      }

      const projectObj = (worldYawOffset: number, dist: number, heightOffset: number) => {
        const relDeg = ((worldYawOffset - (camYaw - 142) + 540) % 360) - 180;
        const fovSpan = 75 / zoomFactor;
        if (Math.abs(relDeg) > fovSpan * 1.15) return null;
        const sx = w / 2 + (relDeg / fovSpan) * w;
        const sy = horizonY + (110 / dist) * h * 0.14 * zoomFactor + heightOffset * zoomFactor * dpr;
        const scale = (16 / dist) * zoomFactor * dpr;
        return { sx, sy, scale, dist };
      };

      // 3. Target Block + Custom Block Outline
      const blockProj = projectObj(0, 7.5, 42);
      if (blockProj) {
        const bs = 28 * blockProj.scale;
        const bx = blockProj.sx - bs / 2;
        const by = blockProj.sy - bs / 2;

        ctx.fillStyle = hasCrispBlocks ? '#475569' : '#3B4252';
        ctx.fillRect(bx, by, bs, bs);
        ctx.fillStyle = hasCrispBlocks ? '#64748B' : '#4C566A';
        ctx.beginPath();
        ctx.moveTo(bx, by);
        ctx.lineTo(bx + bs * 0.25, by - bs * 0.18);
        ctx.lineTo(bx + bs * 1.25, by - bs * 0.18);
        ctx.lineTo(bx + bs, by);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#2E3440';
        ctx.beginPath();
        ctx.moveTo(bx + bs, by);
        ctx.lineTo(bx + bs * 1.25, by - bs * 0.18);
        ctx.lineTo(bx + bs * 1.25, by + bs * 0.82);
        ctx.lineTo(bx + bs, by + bs);
        ctx.closePath();
        ctx.fill();

        if (config.blockOutline.enabled) {
          ctx.save();
          ctx.globalAlpha = config.blockOutline.opacity;
          ctx.strokeStyle = config.blockOutline.color;
          ctx.lineWidth = Math.max(1, config.blockOutline.thickness * dpr);
          if (config.blockOutline.glow) {
            ctx.shadowColor = config.blockOutline.color;
            ctx.shadowBlur = 14 * dpr;
          }
          ctx.strokeRect(bx, by, bs, bs);
          ctx.beginPath();
          ctx.moveTo(bx, by);
          ctx.lineTo(bx + bs * 0.25, by - bs * 0.18);
          ctx.lineTo(bx + bs * 1.25, by - bs * 0.18);
          ctx.lineTo(bx + bs * 1.25, by + bs * 0.82);
          ctx.lineTo(bx + bs, by + bs);
          ctx.moveTo(bx + bs, by);
          ctx.lineTo(bx + bs * 1.25, by - bs * 0.18);
          ctx.stroke();
          ctx.restore();
        } else {
          ctx.strokeStyle = 'rgba(0,0,0,0.65)';
          ctx.lineWidth = 1.2 * dpr;
          ctx.strokeRect(bx, by, bs, bs);
        }
      }

      // 4. Dropped Items + Item Physics
      const droppedItems = [
        { yaw: -16, dist: 8.5, color: '#38BDF8' },
        { yaw: -11, dist: 9.2, color: '#FACC15' },
        { yaw: 14, dist: 8.2, color: '#A855F7' },
        { yaw: 19, dist: 9.5, color: '#34D399' },
      ];
      droppedItems.slice(0, config.itemPhysics.maxAnimatedItems).forEach((it, idx) => {
        const ip = projectObj(it.yaw, it.dist, 76);
        if (!ip) return;
        const speed = config.itemPhysics.enabled ? config.itemPhysics.speed : 1.0;
        const bob = config.itemPhysics.enabled
          ? config.itemPhysics.style === 'Flat Lay'
            ? 0
            : Math.sin(t * 2.5 * speed + idx) * (config.itemPhysics.smoothMovement ? 6 : 3) * dpr
          : Math.sin(t * 2.0 + idx) * 4 * dpr;
        const rot = config.itemPhysics.enabled
          ? config.itemPhysics.rotation
            ? t * 1.8 * speed + idx
            : config.itemPhysics.style === 'Flat Lay'
            ? 0.78
            : 0
          : t * 1.4 + idx;

        ctx.save();
        ctx.translate(ip.sx, ip.sy + bob);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(0, 12 * ip.scale, 8 * ip.scale, 3 * ip.scale, 0, 0, Math.PI * 2);
        ctx.fill();

        if (config.itemPhysics.enabled && config.itemPhysics.style === 'Flat Lay') {
          ctx.scale(1, 0.55);
          ctx.rotate(rot);
        } else {
          ctx.scale(Math.max(0.25, Math.abs(Math.cos(rot))), 1);
        }
        const sz = 9 * ip.scale;
        ctx.fillStyle = it.color;
        ctx.fillRect(-sz, -sz, sz * 2, sz * 2);
        ctx.strokeStyle = 'rgba(255,255,255,0.45)';
        ctx.lineWidth = 1;
        ctx.strokeRect(-sz, -sz, sz * 2, sz * 2);
        ctx.restore();
      });

      // 5. Visible Players + Moving Cosmetics + Nametags
      const visiblePlayers = [
        { name: 'ItsM3liodas', hp: 20, yaw: -22, dist: 12, shirt: '#7C5CFF', usePlayerCosmetics: true },
        { name: 'Astra_MC', hp: 16, yaw: 21, dist: 22, shirt: '#38BDF8', usePlayerCosmetics: false },
      ];
      visiblePlayers.forEach((pl, plIdx) => {
        const pp = projectObj(pl.yaw, pl.dist, 46);
        if (!pp) return;
        const s = pp.scale * 1.15;

        if (config.cosmetics.enabled) {
          const hasWings = pl.usePlayerCosmetics ? Boolean(config.cosmetics.equipped.wings) : true;
          const hasCape = pl.usePlayerCosmetics ? Boolean(config.cosmetics.equipped.capes) : false;
          const pCol = pl.usePlayerCosmetics ? config.cosmetics.primaryDye : '#38BDF8';
          const sCol = pl.usePlayerCosmetics ? config.cosmetics.secondaryDye : '#C084FC';
          const spread = pl.usePlayerCosmetics ? config.cosmetics.wingSpread : 0.9;
          const flapFreq = 3.8 * (pl.usePlayerCosmetics ? config.cosmetics.wingFlapSpeed : 1.0);
          const flapPhase = config.cosmetics.animationsEnabled ? Math.sin(t * flapFreq + plIdx) : 0;

          if (hasWings) {
            const wingAngle = 0.25 + flapPhase * 0.34;
            const wingLen = 18 * s * spread;
            const wingH = 12 * s * spread;
            ctx.save();
            ctx.translate(pp.sx - 4 * s, pp.sy - 11 * s);
            ctx.rotate(-wingAngle);
            ctx.fillStyle = pCol;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(-wingLen, -wingH * 0.65);
            ctx.lineTo(-wingLen * 0.85, wingH * 0.45);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = sCol;
            ctx.beginPath();
            ctx.moveTo(-wingLen * 0.45, -wingH * 0.25);
            ctx.lineTo(-wingLen * 1.15, -wingH * 0.35);
            ctx.lineTo(-wingLen * 0.9, wingH * 0.55);
            ctx.closePath();
            ctx.fill();
            ctx.restore();

            ctx.save();
            ctx.translate(pp.sx + 4 * s, pp.sy - 11 * s);
            ctx.rotate(wingAngle);
            ctx.fillStyle = pCol;
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(wingLen, -wingH * 0.65);
            ctx.lineTo(wingLen * 0.85, wingH * 0.45);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = sCol;
            ctx.beginPath();
            ctx.moveTo(wingLen * 0.45, -wingH * 0.25);
            ctx.lineTo(wingLen * 1.15, -wingH * 0.35);
            ctx.lineTo(wingLen * 0.9, wingH * 0.55);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
          }

          if (hasCape) {
            const capeSway = config.cosmetics.animationsEnabled ? Math.sin(t * 3.0 + plIdx) * 3 * s : 0;
            ctx.fillStyle = pCol;
            ctx.beginPath();
            ctx.moveTo(pp.sx - 6 * s, pp.sy - 15 * s);
            ctx.lineTo(pp.sx + 6 * s, pp.sy - 15 * s);
            ctx.lineTo(pp.sx + 7 * s + capeSway, pp.sy + 6 * s);
            ctx.lineTo(pp.sx - 7 * s + capeSway, pp.sy + 6 * s);
            ctx.closePath();
            ctx.fill();
          }
        }

        ctx.fillStyle = '#E8B89A';
        ctx.fillRect(pp.sx - 6 * s, pp.sy - 28 * s, 12 * s, 12 * s);
        ctx.fillStyle = pl.shirt;
        ctx.fillRect(pp.sx - 6 * s, pp.sy - 16 * s, 12 * s, 16 * s);
        ctx.fillStyle = '#0F172A';
        ctx.fillRect(pp.sx - 6 * s, pp.sy, 5.5 * s, 14 * s);
        ctx.fillRect(pp.sx + 0.5 * s, pp.sy, 5.5 * s, 14 * s);

        if (config.cosmetics.enabled && pl.usePlayerCosmetics) {
          const pCol = config.cosmetics.primaryDye;
          const sCol = config.cosmetics.secondaryDye;
          if (config.cosmetics.equipped.hats) {
            ctx.fillStyle = pCol;
            ctx.fillRect(pp.sx - 7 * s, pp.sy - 30.5 * s, 14 * s, 3 * s);
            ctx.fillStyle = sCol;
            ctx.fillRect(pp.sx - 4 * s, pp.sy - 33 * s, 8 * s, 2.5 * s);
          }
          if (config.cosmetics.equipped.headAccessories) {
            const haloFloat = config.cosmetics.animationsEnabled ? Math.sin(t * 3.2) * 1.5 * s : 0;
            ctx.strokeStyle = sCol;
            ctx.lineWidth = Math.max(1.5, 2 * s);
            ctx.beginPath();
            ctx.ellipse(pp.sx, pp.sy - 34 * s + haloFloat, 7 * s, 2 * s, 0, 0, Math.PI * 2);
            ctx.stroke();
          }
          if (config.cosmetics.equipped.shoulderAccessories) {
            const bob = config.cosmetics.animationsEnabled ? Math.sin(t * 4.5) * 1.6 * s : 0;
            ctx.fillStyle = pCol;
            ctx.fillRect(pp.sx - 10 * s, pp.sy - 19 * s + bob, 4 * s, 4 * s);
            ctx.fillStyle = sCol;
            ctx.fillRect(pp.sx - 11.5 * s, pp.sy - 19 * s + bob + Math.sin(t * 9) * s, 2 * s, 1.5 * s);
          }
        }

        const tagScale = config.nametags.enabled
          ? config.nametags.size * (config.nametags.distanceScaling ? Math.max(0.65, Math.min(1.25, 13 / pl.dist)) : 1.0)
          : Math.max(0.6, 12 / pl.dist);
        const fontPx = Math.round(12 * tagScale * dpr);
        ctx.font = `600 ${fontPx}px ${config.nametags.enabled ? FONT_CSS[config.nametags.font] : 'monospace'}`;
        const healthSuffix = config.nametags.enabled && config.nametags.showHealthWhenPermitted ? ` ♥ ${pl.hp}` : '';
        const text = `${pl.name}${healthSuffix}`;
        const tw = ctx.measureText(text).width;
        const padX = 6 * dpr;
        const boxH = fontPx + 6 * dpr;
        const tagY = pp.sy - 38 * s;

        ctx.fillStyle = `rgba(5, 8, 18, ${config.nametags.enabled ? config.nametags.backgroundOpacity : 0.35})`;
        ctx.fillRect(pp.sx - tw / 2 - padX, tagY - boxH / 2, tw + padX * 2, boxH);

        if (config.nametags.enabled && config.nametags.textShadow) {
          ctx.fillStyle = 'rgba(0,0,0,0.8)';
          ctx.fillText(text, pp.sx - tw / 2 + 1, tagY + fontPx * 0.35 + 1);
        }
        ctx.fillStyle = config.nametags.enabled ? config.nametags.textColor : '#FFFFFF';
        ctx.fillText(text, pp.sx - tw / 2, tagY + fontPx * 0.35);
      });

      // 6. Decorative Particle Effects
      if (config.particles.enabled) {
        const activeCount = config.particles.performanceMode
          ? Math.min(18, Math.round(config.particles.amount * 0.5))
          : config.particles.amount;
        ctx.save();
        ctx.globalAlpha = config.particles.transparency;
        for (let i = 0; i < activeCount; i++) {
          const p = particlePool[i % particlePool.length];
          const px = (((p.x + t * p.vx * config.particles.speed) % 1) + 1) * w;
          const py =
            ((((p.y + t * p.vy * config.particles.speed * (config.particles.style === 'Ember Sparks' ? -1 : 1)) % 1) + 1) % 1) * h;
          const sz = (2.5 + (i % 3)) * config.particles.size * dpr;
          const col = i % 2 === 0 ? config.particles.primaryColor : config.particles.secondaryColor;
          ctx.fillStyle = col;
          ctx.strokeStyle = col;
          if (config.particles.style === 'Neon Rings') {
            ctx.lineWidth = 1.4 * dpr;
            ctx.beginPath();
            ctx.arc(px, py, sz * 1.4, 0, Math.PI * 2);
            ctx.stroke();
          } else if (config.particles.style === 'Sakura Petals') {
            ctx.beginPath();
            ctx.ellipse(px, py, sz * 1.4, sz * 0.75, t + p.phase, 0, Math.PI * 2);
            ctx.fill();
          } else if (config.particles.style === 'Starlight Sparkles' || config.particles.style === 'Enchant Runes') {
            ctx.fillRect(px - sz / 2, py - sz / 2, sz, sz);
          } else {
            ctx.beginPath();
            ctx.arc(px, py, sz * 0.8, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      }

      // 7. First-Person Viewmodel Hand + Held Item + Hand Aura
      const vmCfg = config.viewmodel.enabled
        ? config.viewmodel.categories[config.viewmodel.activeCategory]
        : { handX: 0, handY: 0, handZ: 0, itemX: 0, itemY: 0, itemZ: 0, scale: 1, rotX: 0, rotY: 0, rotZ: 0 };

      const drawHand = (isLeft: boolean) => {
        const sign = isLeft ? -1 : 1;
        const swing = world.pressedKeys.lmb ? Math.sin(t * 18) * 18 : Math.sin(t * 2.2) * 3;
        const baseX = (isLeft ? w * 0.16 : w * 0.84) + (vmCfg.handX + vmCfg.itemX) * w * 0.18 * sign;
        const baseY = h * 0.82 - (vmCfg.handY + vmCfg.itemY) * h * 0.22 + swing * dpr;

        ctx.save();
        ctx.translate(baseX, baseY);
        ctx.scale(vmCfg.scale, vmCfg.scale);
        ctx.rotate(((vmCfg.rotZ - 14) * sign * Math.PI) / 180);

        if (config.handAura.enabled) {
          const pulse = 0.85 + Math.sin(t * 4 * config.handAura.animationSpeed) * 0.15;
          const auraR = 64 * config.handAura.size * pulse * dpr;
          let c1 = config.handAura.primaryColor;
          let c2 = config.handAura.secondaryColor;
          if (config.handAura.style === 'Rainbow') {
            const hue = Math.round((t * 90 * config.handAura.animationSpeed) % 360);
            c1 = `hsl(${hue}, 90%, 62%)`;
            c2 = `hsl(${(hue + 70) % 360}, 90%, 58%)`;
          }
          ctx.save();
          ctx.globalAlpha = config.handAura.transparency * config.handAura.intensity;
          if (config.handAura.style === 'Minimal Outline') {
            ctx.strokeStyle = c1;
            ctx.lineWidth = 2.5 * dpr;
            ctx.strokeRect(-26 * dpr, -55 * dpr, 52 * dpr, 110 * dpr);
          } else {
            const auraGrad = ctx.createRadialGradient(0, -15 * dpr, 4, 0, -15 * dpr, auraR);
            auraGrad.addColorStop(0, c1);
            auraGrad.addColorStop(0.55, `${c2}66`);
            auraGrad.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = auraGrad;
            ctx.beginPath();
            ctx.arc(0, -15 * dpr, auraR, 0, Math.PI * 2);
            ctx.fill();
          }

          if (config.handAura.particleAmount > 0 && config.handAura.quality !== 'Low') {
            const count = Math.min(20, config.handAura.particleAmount);
            for (let k = 0; k < count; k++) {
              const ang = t * 2.5 * config.handAura.animationSpeed + (k * Math.PI * 2) / count;
              const rad = (26 + (k % 3) * 10) * config.handAura.size * dpr;
              ctx.fillStyle = k % 2 === 0 ? c1 : c2;
              ctx.fillRect(Math.cos(ang) * rad, -20 * dpr + Math.sin(ang) * rad * 0.7, 3 * dpr, 3 * dpr);
            }
          }
          ctx.restore();
        }

        ctx.fillStyle = '#E0A98C';
        ctx.fillRect(-18 * dpr, -10 * dpr, 36 * dpr, 92 * dpr);
        ctx.fillStyle = '#1E1B4B';
        ctx.fillRect(-20 * dpr, 22 * dpr, 40 * dpr, 65 * dpr);

        if (!isLeft || config.viewmodel.leftHandEnabled) {
          ctx.save();
          if (config.handAura.enabled && config.handAura.heldItemEffect) {
            ctx.shadowColor = config.handAura.primaryColor;
            ctx.shadowBlur = 16 * config.handAura.intensity * dpr;
          }
          if (world.heldItemKey === 'sword') {
            ctx.fillStyle = '#38BDF8';
            ctx.fillRect(-6 * dpr, -94 * dpr, 12 * dpr, 64 * dpr);
            ctx.fillStyle = '#78350F';
            ctx.fillRect(-18 * dpr, -32 * dpr, 36 * dpr, 8 * dpr);
          } else if (world.heldItemKey === 'pickaxe') {
            ctx.fillStyle = '#78350F';
            ctx.fillRect(-4 * dpr, -76 * dpr, 8 * dpr, 56 * dpr);
            ctx.fillStyle = '#64748B';
            ctx.fillRect(-28 * dpr, -84 * dpr, 56 * dpr, 12 * dpr);
          } else if (world.heldItemKey === 'apple') {
            ctx.fillStyle = '#FACC15';
            ctx.beginPath();
            ctx.arc(0, -48 * dpr, 18 * dpr, 0, Math.PI * 2);
            ctx.fill();
          } else if (world.heldItemKey === 'shulker') {
            ctx.fillStyle = '#9333EA';
            ctx.fillRect(-22 * dpr, -64 * dpr, 44 * dpr, 44 * dpr);
            ctx.strokeStyle = '#E9D5FF';
            ctx.lineWidth = 2 * dpr;
            ctx.strokeRect(-22 * dpr, -64 * dpr, 44 * dpr, 44 * dpr);
          } else {
            ctx.strokeStyle = '#92400E';
            ctx.lineWidth = 6 * dpr;
            ctx.beginPath();
            ctx.arc(0, -48 * dpr, 28 * dpr, -Math.PI * 0.7, Math.PI * 0.7);
            ctx.stroke();
          }
          ctx.restore();
        }
        ctx.restore();
      };

      if (!config.viewmodel.enabled || config.viewmodel.rightHandEnabled) drawHand(false);
      if (config.viewmodel.enabled && config.viewmodel.leftHandEnabled) drawHand(true);

      // 8. Motion Blur Accumulation Overlay
      if (config.motionBlur.enabled && config.motionBlur.cameraBlur) {
        const trail = trailCanvasRef.current;
        if (trail) {
          if (trail.width !== w || trail.height !== h) {
            trail.width = w;
            trail.height = h;
          }
          const tctx = trail.getContext('2d');
          if (tctx) {
            const blend = Math.min(0.88, config.motionBlur.intensity * (0.25 + camVelocity * 0.75));
            const decay = Math.max(0.12, 1 - 16 / Math.max(16, config.motionBlur.durationMs));
            if (blend > 0.04) {
              ctx.save();
              ctx.globalAlpha = blend * decay;
              ctx.drawImage(trail, -dYaw * 2.4 * dpr, dPitch * 2.0 * dpr);
              ctx.restore();
            }
            tctx.clearRect(0, 0, w, h);
            tctx.drawImage(canvas, 0, 0);
          }
        }
      }

      // 9. Color Grading Vignette & Filter
      if (config.colorGrading.enabled) {
        if (config.colorGrading.temperature !== 0) {
          ctx.fillStyle =
            config.colorGrading.temperature > 0
              ? `rgba(255, 165, 60, ${config.colorGrading.temperature * 0.22})`
              : `rgba(56, 189, 248, ${Math.abs(config.colorGrading.temperature) * 0.22})`;
          ctx.fillRect(0, 0, w, h);
        }
        if (config.colorGrading.filterStrength > 0) {
          ctx.save();
          ctx.globalAlpha = config.colorGrading.filterStrength;
          ctx.fillStyle = config.colorGrading.filterColor;
          ctx.fillRect(0, 0, w, h);
          ctx.restore();
        }
        if (config.colorGrading.vignette > 0) {
          const vig = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.72);
          vig.addColorStop(0, 'rgba(0,0,0,0)');
          vig.addColorStop(1, `rgba(0,0,0,${Math.min(0.92, config.colorGrading.vignette)})`);
          ctx.fillStyle = vig;
          ctx.fillRect(0, 0, w, h);
        }
      }

      raf = requestAnimationFrame(renderFrame);
    };

    raf = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(raf);
  }, [config, world.yaw, world.pitch, world.zoomEngaged, world.freelookYawOffset, world.freelookPitchOffset, world.heldItemKey, world.pressedKeys.lmb, activePacks, setWorld]);

  const canvasFilterCss = useMemo(() => {
    if (!config.colorGrading.enabled) return 'none';
    const b = config.colorGrading.brightness * (1 + (config.colorGrading.gamma - 1) * 0.45);
    return `brightness(${b.toFixed(2)}) contrast(${config.colorGrading.contrast.toFixed(2)}) saturate(${config.colorGrading.saturation.toFixed(2)})`;
  }, [config.colorGrading]);

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const getCardinal = (yawDeg: number) => {
    const norm = ((yawDeg % 360) + 360) % 360;
    const dirs = ['S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'];
    return dirs[Math.round(norm / 45) % 8];
  };

  const renderHudContent = (el: HudElementConfig) => {
    const nowTime = clockTick.toLocaleTimeString([], {
      hour12: !el.clock24h,
      hour: '2-digit',
      minute: '2-digit',
      ...(el.showSeconds ? { second: '2-digit' } : {}),
    });

    switch (el.id) {
      case 'fps':
        return <span>{el.format.replace('{fps}', String(world.fps))}</span>;
      case 'ping':
        return (
          <span className="flex items-center gap-1.5">
            {world.pingMs !== null ? <Wifi className="h-3 w-3 text-emerald-400" /> : <WifiOff className="h-3 w-3 text-amber-400" />}
            {el.format.replace('{ping}', world.pingMs !== null ? `${world.pingMs} ms` : el.pingUnavailableText || 'N/A')}
          </span>
        );
      case 'coordinates': {
        const p = el.precision ?? 1;
        return (
          <span>
            {el.format
              .replace('{x}', world.x.toFixed(p))
              .replace('{y}', world.y.toFixed(p))
              .replace('{z}', world.z.toFixed(p))}
          </span>
        );
      }
      case 'direction':
        return (
          <span className="flex items-center gap-1.5">
            <Compass className="h-3 w-3" />
            {el.format
              .replace('{dir}', getCardinal(world.yaw))
              .replace('{yaw}', String(Math.round(((world.yaw % 360) + 360) % 360)))}
          </span>
        );
      case 'biome':
        return <span>{el.format.replace('{biome}', world.biome)}</span>;
      case 'clock':
        return <span>{el.format.replace('{time}', nowTime)}</span>;
      case 'server':
        return <span>{el.format.replace('{addr}', world.serverAddress ?? 'Singleplayer (Local)')}</span>;
      case 'cps':
        return <span>{el.format.replace('{lmb}', String(world.lmbCps)).replace('{rmb}', String(world.rmbCps))}</span>;
      case 'session':
        return <span>{el.format.replace('{duration}', formatDuration(world.sessionSeconds))}</span>;
      case 'armor': {
        // Uku's Armor HUD faithful minimalist pixel-art armor icons + vanilla durability bars + low-durability warning badge!
        const pieces: { kind: ArmorSlotKind; label: string; pct: number; enchanted: boolean }[] = [
          { kind: 'helmet', label: 'Helm', pct: 88, enchanted: true },
          { kind: 'chestplate', label: 'Chest', pct: 62, enchanted: true },
          { kind: 'leggings', label: 'Legs', pct: 21, enchanted: true }, // Low durability triggers Uku warning!
          { kind: 'boots', label: 'Boots', pct: 95, enchanted: true },
        ];
        if (el.showOffhandSlot) {
          pieces.push({ kind: 'shield', label: 'Off', pct: 74, enchanted: false });
        }
        const thresh = el.lowDurabilityThreshold ?? 25;
        const horizontal = (el.armorOrientation ?? 'horizontal') === 'horizontal';
        const barColor = (pct: number) => (pct > 55 ? '#22C55E' : pct > thresh ? '#FACC15' : '#EF4444');

        return (
          <div className={`flex ${horizontal ? 'flex-row items-center gap-1.5' : 'flex-col gap-1.5'}`}>
            {pieces.map((pc) => {
              const isLow = pc.pct <= thresh;
              return (
                <div
                  key={pc.kind}
                  className={`relative flex flex-col items-center justify-center rounded ${
                    el.showArmorFrame ? 'border border-white/20 bg-slate-950/75 p-1' : 'px-0.5 py-0.5'
                  }`}
                >
                  <div className="relative">
                    <ArmorPixelIcon kind={pc.kind} enchanted={pc.enchanted} size={22} />
                    {el.showWarningBadge !== false && isLow && (
                      <span
                        className="absolute -top-1 -right-1 flex h-3.5 w-3.5 animate-pulse items-center justify-center rounded-full bg-rose-600 text-[9px] font-black text-white shadow"
                        title={`Low durability (${pc.pct}%)`}
                      >
                        !
                      </span>
                    )}
                  </div>
                  {/* Vanilla-style crisp durability bar under the armor sprite */}
                  <div className="mt-0.5 h-[3px] w-5 overflow-hidden bg-black/90">
                    <div className="h-full" style={{ width: `${pc.pct}%`, backgroundColor: barColor(pc.pct) }} />
                  </div>
                  {(el.armorStyle === 'uku-numbers' || el.showDurabilityPercent) && (
                    <span className={`mt-0.5 font-mono text-[9px] font-bold ${isLow ? 'text-rose-400' : 'text-slate-100'}`}>
                      {pc.pct}%
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        );
      }
      case 'musicCard': {
        if (!config.musicLyrics.enabled || !config.musicLyrics.showNowPlayingCard || !activeTrack || !musicState) {
          return null;
        }
        const pct = Math.min(100, (musicState.positionSec / Math.max(1, activeTrack.durationSec)) * 100);
        const [c1, c2] = activeTrack.coverColors;
        return (
          <div className="pointer-events-auto w-60 space-y-2">
            <div className="flex items-center gap-2.5">
              <div
                style={{ background: `linear-gradient(135deg, ${c1}, ${c2})` }}
                className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/20 shadow-lg"
              >
                <Disc3 className={`h-5 w-5 text-white ${musicState.playing ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-xs font-bold text-white">{activeTrack.title}</div>
                <div className="truncate text-[10px] text-slate-300">{activeTrack.artist}</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-emerald-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <span>{config.musicLyrics.spotifyStatus}</span>
                </div>
              </div>
              {config.musicLyrics.showEqualizer && (
                <div className="flex h-4 items-end gap-0.5">
                  {[0.6, 1.0, 0.45, 0.85].map((amp, i) => (
                    <span
                      key={i}
                      style={{
                        height: musicState.playing ? `${Math.round((0.35 + Math.abs(Math.sin(musicState.positionSec * 4 + i)) * 0.65) * amp * 16)}px` : '4px',
                        backgroundColor: c1,
                      }}
                      className="w-1 rounded-full transition-all duration-150"
                    />
                  ))}
                </div>
              )}
            </div>
            <div className="space-y-1">
              <div className="h-1 w-full overflow-hidden rounded-full bg-white/15">
                <div
                  className="h-full rounded-full transition-all duration-200"
                  style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${c1}, ${c2})` }}
                />
              </div>
              <div className="flex items-center justify-between text-[9px] font-mono text-slate-300">
                <span>{formatDuration(musicState.positionSec)}</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onStepTrack?.(-1);
                    }}
                    className="hover:text-white"
                  >
                    <SkipBack className="h-3 w-3" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onTogglePlayMusic?.();
                    }}
                    className="rounded-full bg-white/15 p-1 text-white hover:bg-white/25"
                  >
                    {musicState.playing ? <Pause className="h-2.5 w-2.5" /> : <Play className="h-2.5 w-2.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onStepTrack?.(1);
                    }}
                    className="hover:text-white"
                  >
                    <SkipForward className="h-3 w-3" />
                  </button>
                </div>
                <span>{formatDuration(activeTrack.durationSec)}</span>
              </div>
            </div>
          </div>
        );
      }
      case 'heldItem': {
        const itemLabel =
          world.heldItemKey === 'sword'
            ? 'Diamond Sword (Sharp V)'
            : world.heldItemKey === 'pickaxe'
            ? 'Netherite Pickaxe (1482/2031)'
            : world.heldItemKey === 'apple'
            ? 'Golden Apple ×12'
            : world.heldItemKey === 'shulker'
            ? 'Purple Shulker Box [9/27]'
            : 'Enchanted Bow (Power V)';
        return (
          <div className="flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5 text-violet-300" />
            <span>{itemLabel}</span>
          </div>
        );
      }
      case 'potions':
        return (
          <div className="space-y-0.5 text-[11px]">
            <div>⚡ Speed II — 01:24</div>
            <div>🔥 Fire Res — 06:45</div>
          </div>
        );
      case 'keystrokes': {
        const keyBox = (lbl: string, pressed: boolean, extraClass = '') => (
          <div
            className={`flex items-center justify-center rounded border text-[10px] font-bold transition-colors ${extraClass} ${
              pressed ? 'border-white/70 text-white shadow-inner' : 'border-white/15 bg-black/50 text-slate-200'
            }`}
            style={pressed ? { backgroundColor: el.color } : undefined}
          >
            {lbl}
          </div>
        );
        return (
          <div className="w-[104px] space-y-1 select-none">
            <div className="grid grid-cols-3 gap-1">
              <div />
              {keyBox('W', world.pressedKeys.w, 'h-7')}
              <div />
              {keyBox('A', world.pressedKeys.a, 'h-7')}
              {keyBox('S', world.pressedKeys.s, 'h-7')}
              {keyBox('D', world.pressedKeys.d, 'h-7')}
            </div>
            <div className="grid grid-cols-2 gap-1">
              {keyBox('LMB', world.pressedKeys.lmb, 'h-5')}
              {keyBox('RMB', world.pressedKeys.rmb, 'h-5')}
            </div>
            {keyBox('SPACE', world.pressedKeys.space, 'h-5 w-full')}
          </div>
        );
      }
    }
  };

  const skyLyricPosClass =
    config.musicLyrics.lyricPosition === 'top-banner'
      ? 'top-10'
      : config.musicLyrics.lyricPosition === 'above-hotbar'
      ? 'bottom-20'
      : 'top-[19%]';

  return (
    <div
      ref={containerRef}
      onContextMenu={(e) => e.preventDefault()}
      onMouseDown={(e) => {
        if (hudEditMode) return;
        if (e.button === 0 || e.button === 2) onMouseAction(e.button, true);
        if (interactiveMode) {
          camDragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
        }
      }}
      onMouseMove={(e) => {
        if (hudEditMode && draggingHudRef.current && containerRef.current && onUpdateHudPosition) {
          const rect = containerRef.current.getBoundingClientRect();
          const nx = Math.max(0, Math.min(92, ((e.clientX - rect.left - draggingHudRef.current.offsetX) / rect.width) * 100));
          const ny = Math.max(0, Math.min(92, ((e.clientY - rect.top - draggingHudRef.current.offsetY) / rect.height) * 100));
          onUpdateHudPosition(draggingHudRef.current.id, Math.round(nx * 10) / 10, Math.round(ny * 10) / 10);
          return;
        }
        if (camDragRef.current.active && interactiveMode) {
          const dx = e.clientX - camDragRef.current.lastX;
          const dy = e.clientY - camDragRef.current.lastY;
          camDragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
          const sensScale =
            config.zoom.enabled && world.zoomEngaged && config.zoom.reduceSensitivity
              ? 1 / Math.max(1.2, config.zoom.strength * 0.7)
              : 1;

          setWorld((w) => {
            if (config.freelook.enabled && world.freelookEngaged) {
              const nextYawOff = Math.max(
                -config.freelook.maxHorizontalDeg,
                Math.min(config.freelook.maxHorizontalDeg, w.freelookYawOffset + dx * 0.35 * config.freelook.horizontalSensitivity * sensScale)
              );
              const nextPitchOff = Math.max(
                -config.freelook.maxVerticalDeg,
                Math.min(config.freelook.maxVerticalDeg, w.freelookPitchOffset + dy * 0.28 * config.freelook.verticalSensitivity * sensScale)
              );
              return { ...w, freelookYawOffset: nextYawOff, freelookPitchOffset: nextPitchOff };
            }
            return {
              ...w,
              yaw: w.yaw + dx * 0.35 * sensScale,
              pitch: Math.max(-60, Math.min(60, w.pitch + dy * 0.25 * sensScale)),
            };
          });
        }
      }}
      onMouseUp={(e) => {
        if (e.button === 0 || e.button === 2) onMouseAction(e.button, false);
        camDragRef.current.active = false;
        draggingHudRef.current = null;
      }}
      onMouseLeave={() => {
        camDragRef.current.active = false;
        draggingHudRef.current = null;
      }}
      className="relative h-full w-full overflow-hidden select-none"
    >
      <canvas ref={trailCanvasRef} className="hidden" />
      <canvas ref={canvasRef} style={{ filter: canvasFilterCss }} className="block h-full w-full cursor-crosshair" />

      {/* ValenceMOD-Inspired Synced Floating Sky Lyrics */}
      {config.musicLyrics.enabled && config.musicLyrics.showSkyLyrics && lyricCursor.current && !hudEditMode && (
        <div
          style={{
            opacity: config.musicLyrics.lyricOpacity,
            fontFamily: FONT_CSS[config.musicLyrics.lyricFont],
            transform: `translateX(-50%) scale(${config.musicLyrics.lyricScale})`,
          }}
          className={`pointer-events-none absolute left-1/2 z-10 flex flex-col items-center text-center transition-all duration-300 ${skyLyricPosClass}`}
        >
          {lyricCursor.prev && (
            <span className="text-[11px] font-medium tracking-wide text-slate-300/50 drop-shadow">
              {lyricCursor.prev.text}
            </span>
          )}
          <span
            style={{
              color:
                config.musicLyrics.albumTintSync && activeTrack
                  ? activeTrack.coverColors[0]
                  : config.musicLyrics.lyricColor,
              textShadow: config.musicLyrics.lyricGlow
                ? `0 0 18px ${config.musicLyrics.albumTintSync && activeTrack ? activeTrack.coverColors[0] : config.theme.accentColor}, 0 2px 10px rgba(0,0,0,0.9)`
                : '0 2px 6px rgba(0,0,0,0.9)',
            }}
            className="mt-0.5 text-lg font-bold tracking-tight drop-shadow-xl sm:text-xl"
          >
            {lyricCursor.current.text}
          </span>
          {config.musicLyrics.showNextLine && lyricCursor.next && (
            <span className="mt-0.5 text-xs font-medium tracking-wide text-slate-200/70 drop-shadow">
              {lyricCursor.next.text}
            </span>
          )}
        </div>
      )}

      {config.freelook.enabled && world.freelookEngaged && (
        <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 rounded-full border border-sky-400/40 bg-slate-950/75 px-3 py-1 text-[11px] font-medium text-sky-200 backdrop-blur-md">
          <Eye className="mr-1.5 inline h-3.5 w-3.5" />
          Freelook Active · Body Yaw: {Math.round(((world.yaw % 360) + 360) % 360)}° | Camera Offset: {Math.round(world.freelookYawOffset)}°
        </div>
      )}

      {!hudEditMode && (
        <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          {config.crosshair.enabled ? (
            <div style={{ opacity: config.crosshair.opacity }} className="relative">
              <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, bottom: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, right: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, left: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              {config.crosshair.centerDot && (
                <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: -config.crosshair.thickness / 2, width: config.crosshair.thickness, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              )}
            </div>
          ) : (
            <div className="relative h-4 w-4">
              <div className="absolute top-0 left-1/2 h-4 w-[2px] -translate-x-1/2 bg-white/80 mix-blend-difference" />
              <div className="absolute top-1/2 left-0 h-[2px] w-4 -translate-y-1/2 bg-white/80 mix-blend-difference" />
            </div>
          )}
        </div>
      )}

      {hudEditMode && (
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              'linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
      )}

      {/* All HUD Elements */}
      {(Object.values(config.hudElements) as HudElementConfig[]).map((el) => {
        if (!el.enabled) return null;
        if (el.id === 'musicCard' && (!config.musicLyrics.enabled || !config.musicLyrics.showNowPlayingCard)) {
          return null;
        }
        const isSelected = hudEditMode && selectedHudId === el.id;
        const hideShell = el.id === 'keystrokes' || (el.id === 'armor' && !el.showArmorFrame && el.bgOpacity === 0);
        return (
          <div
            key={el.id}
            onMouseDown={(e) => {
              if (!hudEditMode || !containerRef.current) return;
              e.stopPropagation();
              onSelectHudId?.(el.id);
              if (el.locked) return;
              const box = e.currentTarget.getBoundingClientRect();
              draggingHudRef.current = {
                id: el.id,
                offsetX: e.clientX - box.left,
                offsetY: e.clientY - box.top,
              };
            }}
            style={{
              left: `${el.x}%`,
              top: `${el.y}%`,
              transform: `scale(${el.scale * config.hudScale})`,
              transformOrigin: 'top left',
              opacity: el.opacity * config.hudOpacity,
              color: el.color,
              fontFamily: FONT_CSS[el.font],
              padding: `${el.spacing}px ${el.spacing + 4}px`,
              backgroundColor: hideShell ? 'transparent' : `rgba(8, 11, 22, ${el.bgOpacity})`,
              borderRadius: `${Math.min(10, config.theme.cornerRadius)}px`,
            }}
            className={`absolute z-10 text-xs font-medium transition-shadow ${
              hudEditMode
                ? 'cursor-move border border-dashed'
                : hideShell
                ? 'pointer-events-none'
                : 'pointer-events-none border border-white/10 shadow-md backdrop-blur-sm'
            } ${isSelected ? 'ring-2 ring-violet-400' : hudEditMode ? 'border-white/35' : ''}`}
          >
            {hudEditMode && (
              <span className="mb-0.5 block text-[9px] font-bold tracking-wider uppercase opacity-75">
                {el.label} {el.locked ? '🔒' : ''}
              </span>
            )}
            {renderHudContent(el)}
          </div>
        );
      })}

      {/* Hotbar + Shulker Preview */}
      {!hudEditMode && (
        <div className="absolute bottom-3 left-1/2 z-20 flex -translate-x-1/2 flex-col items-center gap-2">
          {config.shulkerPreview.enabled && shulkerHovered && (
            <div
              style={{
                transform: `scale(${config.shulkerPreview.previewScale})`,
                transformOrigin: 'bottom center',
                backgroundColor:
                  config.shulkerPreview.backgroundStyle === 'Vanilla Classic'
                    ? 'rgba(30, 27, 46, 0.96)'
                    : config.shulkerPreview.backgroundStyle === 'Obsidian Dark'
                    ? 'rgba(5, 6, 12, 0.94)'
                    : 'rgba(13, 17, 34, 0.88)',
                borderColor:
                  config.shulkerPreview.backgroundStyle === 'Accent Border' ? config.theme.accentColor : 'rgba(192,132,252,0.45)',
              }}
              className={`rounded-xl border p-3 shadow-2xl backdrop-blur-xl ${
                config.shulkerPreview.smoothAnimation ? 'mc-animate-in' : ''
              }`}
            >
              <div className="mb-2 flex items-center justify-between gap-4 border-b border-white/10 pb-1.5 text-xs">
                <span className="font-semibold text-purple-200">Purple Shulker Box (Legit Client Preview)</span>
                <span className="font-mono text-[10px] text-slate-400">9 / 27 slots</span>
              </div>
              <div className="grid grid-cols-9 gap-1.5">
                {Array.from({ length: 27 }, (_, idx) => {
                  const item = SHULKER_CONTENTS[idx];
                  return (
                    <div
                      key={idx}
                      title={item ? `${item.name}${item.enchant ? ` (${item.enchant})` : ''}` : 'Empty Slot'}
                      className="relative flex h-8 w-8 items-center justify-center rounded border border-white/10 bg-black/50"
                    >
                      {item && (
                        <>
                          <div
                            className="h-4 w-4 rounded-sm"
                            style={{
                              backgroundColor: item.color,
                              boxShadow:
                                config.shulkerPreview.showEnchantments && item.enchant
                                  ? '0 0 8px rgba(192,132,252,0.85)'
                                  : undefined,
                            }}
                          />
                          {item.count > 1 && (
                            <span className="absolute right-0.5 bottom-0 font-mono text-[9px] font-bold text-white drop-shadow">
                              {item.count}
                            </span>
                          )}
                          {config.shulkerPreview.showDurability && item.dur !== null && (
                            <div className="absolute right-0.5 bottom-0.5 left-0.5 h-0.5 bg-black/70">
                              <div className="h-full bg-emerald-400" style={{ width: `${item.dur}%` }} />
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex items-center gap-1 rounded-lg border border-white/15 bg-black/65 p-1 backdrop-blur-md">
            {(
              [
                { key: 'sword', label: 'Sword', color: '#38BDF8' },
                { key: 'pickaxe', label: 'Pickaxe', color: '#64748B' },
                { key: 'apple', label: 'Apple', color: '#FACC15' },
                { key: 'bow', label: 'Bow', color: '#B45309' },
                { key: 'shulker', label: 'Shulker Box (Hover!)', color: '#A855F7' },
              ] as const
            ).map((slot) => {
              const active = world.heldItemKey === slot.key;
              return (
                <button
                  key={slot.key}
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, heldItemKey: slot.key }))}
                  onMouseEnter={() => slot.key === 'shulker' && setShulkerHovered(true)}
                  onMouseLeave={() => slot.key === 'shulker' && setShulkerHovered(false)}
                  className={`relative flex h-9 w-9 items-center justify-center rounded border transition-all ${
                    active ? 'border-white bg-white/15' : 'border-white/10 bg-black/40 hover:bg-white/10'
                  }`}
                  title={slot.label}
                >
                  <div className="h-4 w-4 rounded-sm" style={{ backgroundColor: slot.color }} />
                  {slot.key === 'shulker' && (
                    <span className="absolute -top-1.5 -right-1 rounded bg-purple-600 px-1 text-[8px] font-bold text-white">
                      BOX
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
