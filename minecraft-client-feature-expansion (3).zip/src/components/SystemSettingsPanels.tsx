import React, { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Cpu,
  Download,
  Keyboard,
  Palette,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import { COSMETICS_CATALOG } from '../data/cosmeticsCatalog';
import { THEME_PRESETS } from '../data/themesAndDocs';
import { formatKeyCodeLabel, LiveWorldTelemetry } from '../store/useClientStore';
import {
  ClientConfig,
  FontFamilyId,
  KeybindActionId,
  PerformancePreset,
  ThemeId,
} from '../types/client';
import { SliderRow, ToggleRow } from './SettingTooltip';

interface SystemPanelsProps {
  section: 'themes' | 'keybinds' | 'performance';
  config: ClientConfig;
  setConfig: React.Dispatch<React.SetStateAction<ClientConfig>>;
  world: LiveWorldTelemetry;
  keybindConflicts: Record<KeybindActionId, KeybindActionId[]>;
  onApplyTheme: (id: ThemeId) => void;
  onApplyPerformance: (preset: PerformancePreset) => void;
  onExportConfig: () => void;
  onImportConfig: (raw: string) => void;
  onRestoreBackup: () => void;
  onResetAll: () => void;
  onToast: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const SystemSettingsPanels: React.FC<SystemPanelsProps> = ({
  section,
  config,
  setConfig,
  world,
  keybindConflicts,
  onApplyTheme,
  onApplyPerformance,
  onExportConfig,
  onImportConfig,
  onRestoreBackup,
  onResetAll,
  onToast,
}) => {
  const [kbSearch, setKbSearch] = useState('');
  const [capturingAction, setCapturingAction] = useState<KeybindActionId | null>(null);
  const themeImportRef = useRef<HTMLInputElement | null>(null);
  const configImportRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!capturingAction) return;
    const handleKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.code === 'Escape') {
        setCapturingAction(null);
        return;
      }
      setConfig((c) => ({
        ...c,
        keybinds: {
          ...c.keybinds,
          [capturingAction]: {
            ...c.keybinds[capturingAction],
            key: e.code,
          },
        },
      }));
      setCapturingAction(null);
    };
    window.addEventListener('keydown', handleKey, true);
    return () => window.removeEventListener('keydown', handleKey, true);
  }, [capturingAction, setConfig]);

  if (section === 'themes') {
    const themeIds: ThemeId[] = [
      'midnight',
      'ocean',
      'blossom',
      'abyss',
      'arctic',
      'emerald',
      'crimson',
      'minimal',
      'custom',
    ];

    const exportTheme = () => {
      const payload = { format: 'itsm3liodas-theme-v1', theme: config.theme };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `itsm3liodas-theme-${config.theme.themeId}.json`;
      a.click();
      URL.revokeObjectURL(url);
      onToast('Theme Exported', 'Saved theme JSON preset.', 'success');
    };

    const importTheme = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(String(reader.result));
          if (!parsed.theme || !parsed.theme.accentColor) {
            onToast('Invalid Theme File', 'Theme JSON missing required color tokens.', 'error');
            return;
          }
          setConfig((c) => ({
            ...c,
            theme: { ...c.theme, ...parsed.theme, themeId: 'custom' },
          }));
          onToast('Theme Imported', 'Custom theme loaded cleanly.', 'success');
        } catch {
          onToast('Import Error', 'Could not parse theme JSON.', 'error');
        }
      };
      reader.readAsText(file);
      e.target.value = '';
    };

    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Palette className="h-4 w-4" style={{ color: config.theme.accentColor }} />
              Themes &amp; Animations Studio
            </h3>
            <p className="text-xs text-slate-400">
              Original ItsM3liodas glass themes with gradients, corner radius, typography, animation speed, and reduced motion.
            </p>
          </div>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={exportTheme}
              className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/10"
            >
              <Download className="h-3.5 w-3.5" /> Export Theme
            </button>
            <button
              type="button"
              onClick={() => themeImportRef.current?.click()}
              className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/10"
            >
              <Upload className="h-3.5 w-3.5" /> Import Theme
            </button>
            <input ref={themeImportRef} type="file" accept=".json" onChange={importTheme} className="hidden" />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
          {themeIds.map((id) => {
            const p = THEME_PRESETS[id];
            const active = config.theme.themeId === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => onApplyTheme(id)}
                className={`flex flex-col items-start rounded-xl border p-2.5 text-left transition-all ${
                  active ? 'border-white/50 bg-white/15 shadow-lg' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.07]'
                }`}
              >
                <div className="mb-1.5 flex w-full items-center gap-1.5">
                  <span className="h-4 w-4 rounded-full border border-white/20" style={{ backgroundColor: p.accentColor }} />
                  <span className="h-4 w-4 rounded-full border border-white/20" style={{ backgroundColor: p.secondaryColor }} />
                </div>
                <span className="text-xs font-semibold text-white capitalize">{id}</span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
            <div className="text-xs font-semibold text-slate-200 uppercase">Colors &amp; Surfaces</div>
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Accent Color</span>
                <input
                  type="color"
                  value={config.theme.accentColor}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, theme: { ...c.theme, themeId: 'custom', accentColor: e.target.value } }))
                  }
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">Secondary Glow</span>
                <input
                  type="color"
                  value={config.theme.secondaryColor}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, theme: { ...c.theme, themeId: 'custom', secondaryColor: e.target.value } }))
                  }
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">BG Top</span>
                <input
                  type="color"
                  value={config.theme.backgroundTop}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, theme: { ...c.theme, themeId: 'custom', backgroundTop: e.target.value } }))
                  }
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
                <span className="text-slate-300">BG Bottom</span>
                <input
                  type="color"
                  value={config.theme.backgroundBottom}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, theme: { ...c.theme, themeId: 'custom', backgroundBottom: e.target.value } }))
                  }
                  className="h-5 w-7 cursor-pointer bg-transparent"
                />
              </label>
            </div>
            <ToggleRow
              label="Background Gradient"
              description="Blends top and bottom background surfaces smoothly."
              checked={config.theme.gradientEnabled}
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, theme: { ...c.theme, gradientEnabled: v } }))}
            />
            <SliderRow
              label="Panel Transparency"
              value={config.theme.panelOpacity}
              min={0.45}
              max={0.98}
              step={0.02}
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, theme: { ...c.theme, panelOpacity: v } }))}
            />
          </div>

          <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
            <div className="text-xs font-semibold text-slate-200 uppercase">Typography &amp; Motion</div>
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-300">Interface Font</span>
              <select
                value={config.theme.fontFamily}
                onChange={(e) =>
                  setConfig((c) => ({ ...c, theme: { ...c.theme, fontFamily: e.target.value as FontFamilyId } }))
                }
                className="rounded-lg border border-white/10 bg-black/50 px-2.5 py-1.5 text-xs text-white focus:outline-none"
              >
                <option value="inter">Inter (Premium Clean)</option>
                <option value="space">Space Grotesk (Geometric)</option>
                <option value="mono">JetBrains Mono (Technical)</option>
                <option value="pixel">Pixel Crisp</option>
              </select>
            </div>
            <SliderRow
              label="Corner Radius"
              value={config.theme.cornerRadius}
              min={0}
              max={24}
              step={1}
              unit="px"
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, theme: { ...c.theme, cornerRadius: v } }))}
            />
            <SliderRow
              label="Animation Speed"
              value={config.theme.animationSpeed}
              min={0.4}
              max={2.2}
              step={0.1}
              unit="x"
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, theme: { ...c.theme, animationSpeed: v } }))}
            />
            <ToggleRow
              label="Reduced Motion (Accessibility)"
              description="Disables hover transforms, slide transitions, and animated motion."
              checked={config.theme.reducedMotion}
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, theme: { ...c.theme, reducedMotion: v } }))}
            />
          </div>
        </div>

        <div
          style={{
            borderRadius: `${config.theme.cornerRadius}px`,
            background: config.theme.gradientEnabled
              ? `linear-gradient(135deg, ${config.theme.backgroundTop}, ${config.theme.backgroundBottom})`
              : config.theme.backgroundTop,
          }}
          className="border border-white/15 p-4 shadow-xl"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-white">
                <Sparkles className="h-4 w-4" style={{ color: config.theme.accentColor }} />
                Live Theme &amp; Animation Preview
              </div>
              <p className="mt-0.5 text-[11px] text-slate-300">
                Active palette: {config.theme.themeId.toUpperCase()} · Radius {config.theme.cornerRadius}px · Motion{' '}
                {config.theme.reducedMotion ? 'Reduced' : `${config.theme.animationSpeed}x`}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onToast('Preview Toast', 'Notification animation respects theme speed & reduced motion!', 'info')}
              style={{
                background: `linear-gradient(90deg, ${config.theme.accentColor}, ${config.theme.secondaryColor})`,
                borderRadius: `${Math.max(4, config.theme.cornerRadius - 4)}px`,
              }}
              className="px-3 py-1.5 text-xs font-semibold text-white shadow transition-transform hover:scale-105"
            >
              Test Animated Notification
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (section === 'keybinds') {
    const actions = Object.values(config.keybinds).filter((kb) => {
      if (!kbSearch.trim()) return true;
      const q = kbSearch.toLowerCase();
      return kb.label.toLowerCase().includes(q) || kb.description.toLowerCase().includes(q) || kb.key.toLowerCase().includes(q);
    });

    const totalConflicts = Object.values(keybindConflicts).filter((arr) => arr.length > 0).length;

    return (
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Keyboard className="h-4 w-4" style={{ color: config.theme.accentColor }} />
              Custom Keybind Settings
            </h3>
            <p className="text-xs text-slate-400">
              Click any binding to capture a new key · Automatic conflict detection · Hold/Toggle mode support
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setConfig((c) => ({
                ...c,
                keybinds: {
                  openMenu: { ...c.keybinds.openMenu, key: 'ShiftRight' },
                  zoom: { ...c.keybinds.zoom, key: 'KeyC', mode: 'Hold' },
                  freelook: { ...c.keybinds.freelook, key: 'AltLeft', mode: 'Hold' },
                  hudEditor: { ...c.keybinds.hudEditor, key: 'KeyH' },
                  wardrobe: { ...c.keybinds.wardrobe, key: 'KeyK' },
                  toggleCrosshair: { ...c.keybinds.toggleCrosshair, key: 'KeyX' },
                  toggleColorGrading: { ...c.keybinds.toggleColorGrading, key: 'KeyG' },
                  resetCamera: { ...c.keybinds.resetCamera, key: 'KeyR' },
                },
              }));
              onToast('Keybinds Reset', 'Restored conflict-free default bindings.', 'info');
            }}
            className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-white/10"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Reset Defaults
          </button>
        </div>

        {totalConflicts > 0 && (
          <div className="flex items-center gap-2 rounded-xl border border-amber-400/40 bg-amber-500/15 px-3.5 py-2 text-xs text-amber-200">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>Keybind conflict detected! Multiple features share the same key. Rebind or clear duplicates below.</span>
          </div>
        )}

        <input
          type="text"
          value={kbSearch}
          onChange={(e) => setKbSearch(e.target.value)}
          placeholder="Search keybinds by feature or key name..."
          className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
        />

        <div className="space-y-2">
          {actions.map((kb) => {
            const conflicts = keybindConflicts[kb.id] ?? [];
            const isCapturing = capturingAction === kb.id;
            return (
              <div
                key={kb.id}
                className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border p-3 ${
                  conflicts.length > 0 ? 'border-amber-400/50 bg-amber-950/20' : 'border-white/10 bg-white/[0.03]'
                }`}
              >
                <div className="min-w-[200px] flex-1">
                  <div className="flex items-center gap-2 text-xs font-semibold text-white">
                    <span>{kb.label}</span>
                    {conflicts.length > 0 && (
                      <span className="rounded bg-amber-500/25 px-1.5 py-0.5 text-[10px] text-amber-200">
                        Conflicts with: {conflicts.map((c) => config.keybinds[c].label).join(', ')}
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 text-[11px] text-slate-400">{kb.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  {kb.supportsMode && (
                    <div className="flex overflow-hidden rounded-lg border border-white/15 bg-black/40 text-[11px]">
                      {(['Hold', 'Toggle'] as const).map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() =>
                            setConfig((c) => ({
                              ...c,
                              keybinds: { ...c.keybinds, [kb.id]: { ...c.keybinds[kb.id], mode: m } },
                              ...(kb.id === 'zoom' ? { zoom: { ...c.zoom, mode: m } } : {}),
                              ...(kb.id === 'freelook' ? { freelook: { ...c.freelook, mode: m } } : {}),
                            }))
                          }
                          className={`px-2 py-1 font-medium ${
                            kb.mode === m ? 'text-white' : 'text-slate-400 hover:text-white'
                          }`}
                          style={kb.mode === m ? { backgroundColor: config.theme.accentColor } : undefined}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setCapturingAction(kb.id)}
                    className={`min-w-[92px] rounded-lg border px-3 py-1.5 font-mono text-xs font-semibold transition-colors ${
                      isCapturing
                        ? 'animate-pulse border-sky-400 bg-sky-500/25 text-sky-200'
                        : 'border-white/15 bg-black/50 text-white hover:bg-white/10'
                    }`}
                  >
                    {isCapturing ? 'Press Key...' : formatKeyCodeLabel(kb.key)}
                  </button>

                  {kb.key && (
                    <button
                      type="button"
                      onClick={() =>
                        setConfig((c) => ({
                          ...c,
                          keybinds: { ...c.keybinds, [kb.id]: { ...c.keybinds[kb.id], key: '' } },
                        }))
                      }
                      className="rounded-lg border border-white/10 bg-white/5 p-1.5 text-slate-400 hover:text-rose-300"
                      title="Remove Keybind"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const presets: PerformancePreset[] = ['Ultra Quality', 'Balanced', 'Performance', 'Low-End Safe'];
  const activeParticleCount = config.particles.enabled
    ? config.particles.performanceMode
      ? Math.min(18, Math.round(config.particles.amount * 0.5))
      : config.particles.amount
    : 0;

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Cpu className="h-4 w-4" style={{ color: config.theme.accentColor }} />
              Performance Optimizations &amp; Telemetry
            </h3>
            <p className="text-xs text-slate-400">
              Live Web Viewport metrics below; Java JVM/LWJGL benchmarks require launching the compiled mod in MC 1.21.11.
            </p>
          </div>
          <span className="rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-0.5 font-mono text-[11px] text-emerald-300">
            {world.fps} FPS · {world.frameTimeMs} ms
          </span>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <div className="rounded-lg border border-white/10 bg-black/35 p-2.5">
            <div className="text-[10px] text-slate-400 uppercase">Viewport Frame Time</div>
            <div className="mt-0.5 font-mono text-sm font-semibold text-white">{world.frameTimeMs} ms</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-black/35 p-2.5">
            <div className="text-[10px] text-slate-400 uppercase">Active Particles</div>
            <div className="mt-0.5 font-mono text-sm font-semibold text-white">{activeParticleCount}</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-black/35 p-2.5">
            <div className="text-[10px] text-slate-400 uppercase">Cached Cosmetics</div>
            <div className="mt-0.5 font-mono text-sm font-semibold text-white">{COSMETICS_CATALOG.length} meshes</div>
          </div>
          <div className="rounded-lg border border-white/10 bg-black/35 p-2.5">
            <div className="text-[10px] text-slate-400 uppercase">Menu Blur Mode</div>
            <div className="mt-0.5 font-mono text-sm font-semibold text-white">
              {config.menuBlur.performanceFriendly ? 'Low-Cost' : 'Full Pass'}
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
        <div className="text-xs font-semibold text-slate-200 uppercase">Performance Presets</div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {presets.map((pr) => {
            const active = config.performance.preset === pr;
            return (
              <button
                key={pr}
                type="button"
                onClick={() => onApplyPerformance(pr)}
                className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                  active ? 'border-transparent text-white' : 'border-white/10 bg-black/30 text-slate-300 hover:bg-white/10'
                }`}
                style={active ? { backgroundColor: config.theme.accentColor } : undefined}
              >
                {pr}
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 gap-2 pt-2 sm:grid-cols-2">
          <ToggleRow
            label="Avoid Per-Frame Allocations"
            description="Reuses pre-allocated StringBuilder & particle pool buffers."
            checked={config.performance.avoidPerFrameAllocations}
            accentColor={config.theme.accentColor}
            onChange={(v) => setConfig((c) => ({ ...c, performance: { ...c.performance, avoidPerFrameAllocations: v } }))}
          />
          <ToggleRow
            label="Cache Cosmetic & Pack Assets"
            description="Retains parsed model geometry & validates packs once."
            checked={config.performance.cacheAssets}
            accentColor={config.theme.accentColor}
            onChange={(v) => setConfig((c) => ({ ...c, performance: { ...c.performance, cacheAssets: v } }))}
          />
          <ToggleRow
            label="Optimize Blur Passes"
            description="Caps blur kernel radius & reduces GPU fill-rate load."
            checked={config.performance.optimizeBlur}
            accentColor={config.theme.accentColor}
            onChange={(v) =>
              setConfig((c) => ({
                ...c,
                performance: { ...c.performance, optimizeBlur: v },
                menuBlur: { ...c.menuBlur, performanceFriendly: v },
              }))
            }
          />
          <ToggleRow
            label="Reduced Quality Mode (Weak Devices)"
            description="Caps canvas DPR to 1.0x and restricts heavy particle effects."
            checked={config.performance.reducedQualityMode}
            accentColor={config.theme.accentColor}
            onChange={(v) => setConfig((c) => ({ ...c, performance: { ...c.performance, reducedQualityMode: v } }))}
          />
        </div>
      </div>

      <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-white uppercase">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              Configuration Persistence &amp; Recovery (Schema v{config.schemaVersion})
            </div>
            <p className="mt-0.5 text-[11px] text-slate-400">
              Auto-saved locally with rolling backup snapshot, bounds validation, JSON import/export, and safe recovery.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={onExportConfig}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-white hover:bg-white/10"
          >
            <Download className="h-3.5 w-3.5" /> Export Full Config (.json)
          </button>
          <button
            type="button"
            onClick={() => configImportRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-white hover:bg-white/10"
          >
            <Upload className="h-3.5 w-3.5" /> Import Config (.json)
          </button>
          <input
            ref={configImportRef}
            type="file"
            accept=".json"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const r = new FileReader();
              r.onload = () => onImportConfig(String(r.result));
              r.readAsText(f);
              e.target.value = '';
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={onRestoreBackup}
            className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/30 bg-sky-500/15 px-3 py-1.5 text-xs font-medium text-sky-200 hover:bg-sky-500/25"
          >
            <RotateCcw className="h-3.5 w-3.5" /> Restore Rolling Backup
          </button>
          <button
            type="button"
            onClick={onResetAll}
            className="inline-flex items-center gap-1.5 rounded-lg border border-rose-400/30 bg-rose-500/15 px-3 py-1.5 text-xs font-medium text-rose-200 hover:bg-rose-500/25"
          >
            <Trash2 className="h-3.5 w-3.5" /> Factory Reset
          </button>
        </div>
      </div>
    </div>
  );
};
