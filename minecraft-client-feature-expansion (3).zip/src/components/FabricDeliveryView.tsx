import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  AlertTriangle,
  CheckCircle2,
  Code2,
  Download,
  FileCode2,
  FolderArchive,
  GitBranch,
  ShieldAlert,
} from 'lucide-react';
import { FABRIC_PROJECT_FILES } from '../data/fabricSources';
import { FEATURE_STATUS_REPORT } from '../data/themesAndDocs';
import { ClientConfig } from '../types/client';

interface FabricDeliveryViewProps {
  config: ClientConfig;
  onToast: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const FabricDeliveryView: React.FC<FabricDeliveryViewProps> = ({ config, onToast }) => {
  const [selectedPath, setSelectedPath] = useState(FABRIC_PROJECT_FILES[8]?.path ?? FABRIC_PROJECT_FILES[0].path);
  const [subTab, setSubTab] = useState<'checklist' | 'source' | 'compat'>('checklist');
  const [packaging, setPackaging] = useState(false);

  const selectedFile = FABRIC_PROJECT_FILES.find((f) => f.path === selectedPath) ?? FABRIC_PROJECT_FILES[0];

  const downloadProjectZip = async () => {
    setPackaging(true);
    try {
      const zip = new JSZip();
      for (const file of FABRIC_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }
      zip.file(
        'run/config/itsm3liodas/studio-exported-config.json',
        JSON.stringify(
          {
            schemaVersion: 3,
            clientVersion: config.clientVersion,
            themeId: config.theme.themeId,
            accentColor: config.theme.accentColor,
            secondaryAccentColor: config.theme.secondaryColor,
            hudScale: config.hudScale,
            hudOpacity: config.hudOpacity,
            motionBlur: config.motionBlur,
            menuBlur: config.menuBlur,
            crosshair: config.crosshair,
            blockOutline: config.blockOutline,
            itemPhysics: config.itemPhysics,
            colorGrading: config.colorGrading,
            handAura: config.handAura,
            zoom: config.zoom,
            freelook: config.freelook,
            shulkerPreview: config.shulkerPreview,
            viewmodel: config.viewmodel,
            musicLyrics: config.musicLyrics,
            cosmetics: {
              enabled: config.cosmetics.enabled,
              animationsEnabled: config.cosmetics.animationsEnabled,
              wingFlapSpeed: config.cosmetics.wingFlapSpeed,
              wingSpread: config.cosmetics.wingSpread,
              primaryDye: config.cosmetics.primaryDye,
              secondaryDye: config.cosmetics.secondaryDye,
              equippedBySlot: config.cosmetics.equipped,
            },
            particles: config.particles,
          },
          null,
          2
        )
      );
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'itsm3liodas-client-fabric-1.21.11.zip';
      a.click();
      URL.revokeObjectURL(url);
      onToast(
        'Project ZIP Downloaded',
        `Packaged ${FABRIC_PROJECT_FILES.length} Fabric 1.21.11 files into itsm3liodas-client-fabric-1.21.11.zip.`,
        'success'
      );
    } catch {
      onToast('Packaging Failed', 'Could not assemble project ZIP archive.', 'error');
    } finally {
      setPackaging(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-400/35 bg-amber-950/25 p-4">
        <div className="max-w-3xl space-y-1">
          <div className="flex items-center gap-2 text-sm font-bold text-amber-200">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            Honest Build &amp; Runtime Status — ItsM3liodas Client (MC 1.21.11 / Fabric / Java 21)
          </div>
          <p className="text-xs leading-relaxed text-amber-100/90">
            The interactive ItsM3liodas Client Web Studio is <strong>built and running</strong> in-browser, and all Java 21 / Fabric 1.21.11 source files, Mixins, Gradle scripts, JUnit 5 tests, and GitHub Actions workflow are included below. Because <strong>Java 21 and Gradle are not installed inside this browser sandbox</strong>, the Gradle build has <strong>not yet been executed</strong> and no JAR has been runtime-tested inside Minecraft 1.21.11 yet. No fake or empty JAR is provided.
          </p>
        </div>
        <button
          type="button"
          disabled={packaging}
          onClick={downloadProjectZip}
          style={{ backgroundColor: config.theme.accentColor }}
          className="inline-flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold text-white shadow-lg transition-transform hover:scale-[1.02] disabled:opacity-60"
        >
          <FolderArchive className="h-4 w-4" />
          {packaging ? 'Packaging ZIP...' : 'Download ItsM3liodas Client (.zip)'}
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          { id: 'checklist', label: `Feature Status Checklist (${FEATURE_STATUS_REPORT.length})`, icon: CheckCircle2 },
          { id: 'source', label: `Java 21 & Gradle Source Explorer (${FABRIC_PROJECT_FILES.length} files)`, icon: Code2 },
          { id: 'compat', label: 'MC 1.21.11 Compatibility & Known Limitations', icon: ShieldAlert },
        ].map((t) => {
          const Icon = t.icon;
          const active = subTab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id as 'checklist' | 'source' | 'compat')}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                active ? 'border-transparent text-white' : 'border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/10'
              }`}
              style={active ? { backgroundColor: config.theme.accentColor } : undefined}
            >
              <Icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          );
        })}
      </div>

      {subTab === 'checklist' && (
        <div className="overflow-hidden rounded-xl border border-white/10 bg-white/[0.02]">
          <div className="max-h-[520px] overflow-y-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 bg-slate-950/95 text-[11px] text-slate-400 uppercase backdrop-blur-md">
                <tr>
                  <th className="px-3.5 py-2.5">Feature</th>
                  <th className="px-3.5 py-2.5">Group</th>
                  <th className="px-3.5 py-2.5">Report Status</th>
                  <th className="px-3.5 py-2.5">Notes &amp; Remaining Work</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {FEATURE_STATUS_REPORT.map((row) => (
                  <tr key={row.feature} className="hover:bg-white/[0.03]">
                    <td className="px-3.5 py-2.5 font-semibold text-white">{row.feature}</td>
                    <td className="px-3.5 py-2.5 text-slate-400">{row.category}</td>
                    <td className="px-3.5 py-2.5">
                      <span
                        className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                          row.status === 'Implemented and tested'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : row.status === 'Implemented but not fully tested'
                            ? 'bg-sky-500/20 text-sky-200'
                            : 'bg-amber-500/20 text-amber-200'
                        }`}
                      >
                        {row.status}
                      </span>
                    </td>
                    <td className="px-3.5 py-2.5 text-[11px] text-slate-300">{row.fabric12111Note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {subTab === 'source' && (
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-12">
          <div className="max-h-[520px] space-y-1 overflow-y-auto rounded-xl border border-white/10 bg-black/40 p-2.5 lg:col-span-4">
            <div className="mb-1.5 px-2 text-[10px] font-bold tracking-wider text-slate-400 uppercase">
              fabric-project/ Tree
            </div>
            {FABRIC_PROJECT_FILES.map((file) => {
              const active = file.path === selectedFile.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedPath(file.path)}
                  className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left font-mono text-[11px] transition-colors ${
                    active ? 'bg-white/15 text-white' : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <FileCode2 className="h-3.5 w-3.5 shrink-0 text-violet-300" />
                  <span className="truncate">{file.path}</span>
                </button>
              );
            })}
          </div>
          <div className="flex max-h-[520px] flex-col overflow-hidden rounded-xl border border-white/10 bg-[#05070E] lg:col-span-8">
            <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.03] px-3.5 py-2">
              <span className="font-mono text-xs font-semibold text-white">{selectedFile.path}</span>
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([selectedFile.content], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = selectedFile.path.split('/').pop() || 'file.txt';
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="inline-flex items-center gap-1 rounded border border-white/15 bg-white/5 px-2 py-1 text-[11px] text-slate-200 hover:bg-white/10"
              >
                <Download className="h-3 w-3" /> Save File
              </button>
            </div>
            <pre className="flex-1 overflow-auto p-3.5 font-mono text-[11px] leading-relaxed text-slate-200">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      )}

      {subTab === 'compat' && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="space-y-2.5 rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <GitBranch className="h-4 w-4 text-sky-400" />
              Minecraft 1.21.11 Compatibility Matrix
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li><strong>Target Version:</strong> Minecraft Java Edition <code className="text-sky-300">1.21.11</code></li>
              <li><strong>Java Toolchain:</strong> <code className="text-sky-300">Java 21</code> (`options.release = 21`)</li>
              <li><strong>Fabric Loader:</strong> <code className="text-sky-300">0.18.4</code> (`{'>='}0.18.1`)</li>
              <li><strong>Fabric Loom:</strong> <code className="text-sky-300">1.14.10</code></li>
              <li><strong>Fabric API:</strong> <code className="text-sky-300">0.141.4+1.21.11</code></li>
              <li><strong>Mappings:</strong> Yarn <code className="text-sky-300">1.21.11+build.6</code></li>
              <li><strong>HUD Rendering Hook:</strong> 1.21.11 <code className="text-emerald-300">HudElementRegistry.attachElementAfter(VanillaHudElements.HOTBAR, ...)</code>.</li>
              <li><strong>Keybinds API:</strong> 1.21.9+ <code className="text-emerald-300">KeyBinding.Category.create(Identifier.of(...))</code>.</li>
              <li><strong>Shulker Contents:</strong> Reads 1.21+ <code className="text-emerald-300">DataComponentTypes.CONTAINER</code>.</li>
              <li><strong>Item Physics Hook:</strong> Targets 1.21.11 <code className="text-emerald-300">ItemEntityRenderState</code> pipeline.</li>
            </ul>
          </div>

          <div className="space-y-2.5 rounded-xl border border-white/10 bg-white/[0.03] p-4">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <ShieldAlert className="h-4 w-4 text-amber-400" />
              Known Issues &amp; Scope Notes
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li><strong>Gradle / JVM Pending:</strong> Compile-time mixin checks must be verified by running `./gradlew build test` in GitHub Actions or local JDK 21.</li>
              <li><strong>Spotify &amp; Synced Sky Lyrics:</strong> Inspired by ValenceMod; uses local Web Audio / LRC / async LRCLIB in Studio and supports optional Spotify OAuth PKCE Client ID without embedded web browsers.</li>
              <li><strong>Shaders / Iris Interop:</strong> Disable ItsM3liodas Motion Blur &amp; Color Grading when external shaderpacks already run post-processing.</li>
              <li><strong>Fair-Play Guarantees:</strong> Zero X-ray, hidden-player ESP, reach hacks, auto-clickers, or combat automation exist.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
