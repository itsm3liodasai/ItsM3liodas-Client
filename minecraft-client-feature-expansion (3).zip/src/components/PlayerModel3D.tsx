import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Camera,
  Grid,
  Play,
  RefreshCw,
  RotateCcw,
  Square,
  Video,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { COSMETICS_CATALOG } from '../data/cosmeticsCatalog';
import { CosmeticCategory, CosmeticItem } from '../types/client';

interface PlayerModel3DProps {
  equipped: Partial<Record<CosmeticCategory, string>>;
  primaryDye: string;
  secondaryDye: string;
  cosmeticsEnabled: boolean;
  animationsEnabled: boolean;
  wingFlapSpeed: number;
  wingSpread: number;
  accentColor: string;
  pose: 'idle' | 'walk' | 'glide' | 'wave';
  onCycleNextWing?: () => void;
  onToast?: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

function createMinecraftSkinTextures(accentColor: string): {
  headTex: THREE.CanvasTexture;
  torsoTex: THREE.CanvasTexture;
  limbTex: THREE.CanvasTexture;
} {
  // Crisp pixelated head texture
  const hc = document.createElement('canvas');
  hc.width = 16;
  hc.height = 16;
  const hctx = hc.getContext('2d')!;
  hctx.fillStyle = '#E8B89A';
  hctx.fillRect(0, 0, 16, 16);
  // Subtle pixel skin shading
  hctx.fillStyle = '#DCA382';
  hctx.fillRect(0, 13, 16, 3);
  hctx.fillRect(0, 0, 2, 16);
  hctx.fillRect(14, 0, 2, 16);
  // Hair bangs
  hctx.fillStyle = '#191830';
  hctx.fillRect(0, 0, 16, 5);
  hctx.fillRect(0, 5, 3, 3);
  hctx.fillRect(13, 5, 3, 3);
  hctx.fillRect(5, 5, 2, 1);
  // Crisp Minecraft eyes
  hctx.fillStyle = '#FFFFFF';
  hctx.fillRect(3, 8, 3, 2);
  hctx.fillRect(10, 8, 3, 2);
  hctx.fillStyle = accentColor;
  hctx.fillRect(4, 8, 2, 2);
  hctx.fillRect(10, 8, 2, 2);
  hctx.fillStyle = '#0F172A';
  hctx.fillRect(5, 9, 1, 1);
  hctx.fillRect(10, 9, 1, 1);
  // Mouth / subtle smile
  hctx.fillStyle = '#B87C64';
  hctx.fillRect(6, 13, 4, 1);

  const headTex = new THREE.CanvasTexture(hc);
  headTex.magFilter = THREE.NearestFilter;
  headTex.minFilter = THREE.NearestFilter;
  headTex.colorSpace = THREE.SRGBColorSpace;

  // Crisp Minecraft hoodie torso texture
  const tc = document.createElement('canvas');
  tc.width = 16;
  tc.height = 24;
  const tctx = tc.getContext('2d')!;
  tctx.fillStyle = '#1E293B';
  tctx.fillRect(0, 0, 16, 24);
  tctx.fillStyle = '#0F172A';
  tctx.fillRect(0, 0, 2, 24);
  tctx.fillRect(14, 0, 2, 24);
  tctx.fillRect(0, 20, 16, 4);
  // Zipper & glowing chest emblem
  tctx.fillStyle = '#475569';
  tctx.fillRect(7, 2, 2, 20);
  tctx.fillStyle = accentColor;
  tctx.fillRect(10, 6, 3, 3);

  const torsoTex = new THREE.CanvasTexture(tc);
  torsoTex.magFilter = THREE.NearestFilter;
  torsoTex.minFilter = THREE.NearestFilter;
  torsoTex.colorSpace = THREE.SRGBColorSpace;

  // Limb texture
  const lc = document.createElement('canvas');
  lc.width = 8;
  lc.height = 24;
  const lctx = lc.getContext('2d')!;
  lctx.fillStyle = '#273449';
  lctx.fillRect(0, 0, 8, 18);
  lctx.fillStyle = '#E8B89A';
  lctx.fillRect(0, 18, 8, 6);
  lctx.fillStyle = accentColor;
  lctx.fillRect(0, 16, 8, 2);

  const limbTex = new THREE.CanvasTexture(lc);
  limbTex.magFilter = THREE.NearestFilter;
  limbTex.minFilter = THREE.NearestFilter;
  limbTex.colorSpace = THREE.SRGBColorSpace;

  return { headTex, torsoTex, limbTex };
}

function createFeatherPatternTexture(primary: string, secondary: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 32, 32);
  grad.addColorStop(0, primary);
  grad.addColorStop(0.65, primary);
  grad.addColorStop(1, secondary);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 32, 32);
  // Crisp pixel feather striations
  ctx.fillStyle = 'rgba(255,255,255,0.16)';
  for (let y = 2; y < 32; y += 5) {
    ctx.fillRect(2, y, 28, 2);
  }
  ctx.fillStyle = 'rgba(0,0,0,0.22)';
  for (let y = 4; y < 32; y += 5) {
    ctx.fillRect(0, y, 32, 1);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export const PlayerModel3D: React.FC<PlayerModel3DProps> = ({
  equipped,
  primaryDye,
  secondaryDye,
  cosmeticsEnabled,
  animationsEnabled,
  wingFlapSpeed,
  wingSpread,
  accentColor,
  pose,
  onCycleNextWing,
  onToast,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [yawDeg, setYawDeg] = useState(145);
  const [pitchDeg, setPitchDeg] = useState(12);
  const [zoom, setZoom] = useState(1.0);
  const [autoSpin, setAutoSpin] = useState(true);
  const [autoReel, setAutoReel] = useState(false);
  const [recording, setRecording] = useState(false);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const draggingRef = useRef<{ active: boolean; x: number; y: number }>({ active: false, x: 0, y: 0 });

  const stateRef = useRef({
    equipped,
    primaryDye,
    secondaryDye,
    cosmeticsEnabled,
    animationsEnabled,
    wingFlapSpeed,
    wingSpread,
    accentColor,
    pose,
    yawDeg,
    pitchDeg,
    zoom,
    autoSpin,
  });
  stateRef.current = {
    equipped,
    primaryDye,
    secondaryDye,
    cosmeticsEnabled,
    animationsEnabled,
    wingFlapSpeed,
    wingSpread,
    accentColor,
    pose,
    yawDeg,
    pitchDeg,
    zoom,
    autoSpin,
  };

  // Auto-cycle showcase reel timer
  useEffect(() => {
    if (!autoReel || !onCycleNextWing) return;
    const id = window.setInterval(() => {
      onCycleNextWing();
    }, 2400);
    return () => window.clearInterval(id);
  }, [autoReel, onCycleNextWing]);

  // Real Three.js WebGL 3D Engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true, // Needed for instant crisp PNG screenshots & video frames
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100);

    // 3-Point Studio Lighting
    const hemi = new THREE.HemisphereLight(0xdbeafe, 0x0f172a, 1.15);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.55);
    keyLight.position.set(4.5, 7.5, 5.5);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x7c5cff, 1.25);
    rimLight.position.set(-5.0, 4.0, -5.0);
    scene.add(rimLight);

    // Subtle Pedestal Ring
    const pedestalGeo = new THREE.RingGeometry(0.95, 1.25, 48);
    const pedestalMat = new THREE.MeshBasicMaterial({
      color: accentColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45,
    });
    const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
    pedestal.rotation.x = -Math.PI / 2;
    pedestal.position.y = -1.36;
    scene.add(pedestal);

    const shadowDisc = new THREE.Mesh(
      new THREE.CircleGeometry(1.0, 32),
      new THREE.MeshBasicMaterial({ color: 0x020617, transparent: true, opacity: 0.55 })
    );
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = -1.37;
    scene.add(shadowDisc);

    // Root Player Rig (Minecraft unit: 16 pixels = 1.0 Three.js unit => 1px = 0.0625)
    const PX = 0.0625;
    const playerRoot = new THREE.Group();
    scene.add(playerRoot);

    const { headTex, torsoTex, limbTex } = createMinecraftSkinTextures(accentColor);

    const skinSideMat = new THREE.MeshStandardMaterial({ color: 0xe8b89a, roughness: 0.72 });
    const headFrontMat = new THREE.MeshStandardMaterial({ map: headTex, roughness: 0.68 });
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x191830, roughness: 0.8 });
    const headMats = [skinSideMat, skinSideMat, hairMat, skinSideMat, headFrontMat, hairMat];

    const torsoMat = new THREE.MeshStandardMaterial({ map: torsoTex, roughness: 0.7 });
    const limbMat = new THREE.MeshStandardMaterial({ map: limbTex, roughness: 0.72 });
    const pantsMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.78 });

    // Body Rig Pivots
    const bodyGroup = new THREE.Group();
    playerRoot.add(bodyGroup);

    const headPivot = new THREE.Group();
    headPivot.position.set(0, 12 * PX, 0);
    bodyGroup.add(headPivot);
    const headMesh = new THREE.Mesh(new THREE.BoxGeometry(8 * PX, 8 * PX, 8 * PX), headMats);
    headMesh.position.y = 4 * PX;
    headPivot.add(headMesh);

    const torsoMesh = new THREE.Mesh(new THREE.BoxGeometry(8 * PX, 12 * PX, 4 * PX), torsoMat);
    torsoMesh.position.set(0, 6 * PX, 0);
    bodyGroup.add(torsoMesh);

    const leftArmPivot = new THREE.Group();
    leftArmPivot.position.set(-6 * PX, 11 * PX, 0);
    bodyGroup.add(leftArmPivot);
    const leftArmMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), limbMat);
    leftArmMesh.position.y = -5 * PX;
    leftArmPivot.add(leftArmMesh);

    const rightArmPivot = new THREE.Group();
    rightArmPivot.position.set(6 * PX, 11 * PX, 0);
    bodyGroup.add(rightArmPivot);
    const rightArmMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), limbMat);
    rightArmMesh.position.y = -5 * PX;
    rightArmPivot.add(rightArmMesh);

    const leftLegPivot = new THREE.Group();
    leftLegPivot.position.set(-2 * PX, 0, 0);
    bodyGroup.add(leftLegPivot);
    const leftLegMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), pantsMat);
    leftLegMesh.position.y = -6 * PX;
    leftLegPivot.add(leftLegMesh);

    const rightLegPivot = new THREE.Group();
    rightLegPivot.position.set(2 * PX, 0, 0);
    bodyGroup.add(rightLegPivot);
    const rightLegMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), pantsMat);
    rightLegMesh.position.y = -6 * PX;
    rightLegPivot.add(rightLegMesh);

    // Center vertically so player stands cleanly on pedestal (-1.36)
    bodyGroup.position.y = -0.6;

    // Cosmetic Mount Containers
    const cosmeticRoot = new THREE.Group();
    bodyGroup.add(cosmeticRoot);

    // Animated references updated each frame
    interface AnimRig {
      leftWingRoot?: THREE.Group;
      leftWingOuter?: THREE.Group;
      rightWingRoot?: THREE.Group;
      rightWingOuter?: THREE.Group;
      capeSegs: THREE.Group[];
      haloGroup?: THREE.Group;
      orbitItems: THREE.Object3D[];
      shoulderGroup?: THREE.Group;
      shoulderMiniWings?: [THREE.Object3D, THREE.Object3D];
      backSpinRing?: THREE.Group;
      tailGroup?: THREE.Group[];
      leftFootBoot?: THREE.Group;
      rightFootBoot?: THREE.Group;
      ankleWinglets: [THREE.Object3D, THREE.Object3D][];
      leftSleeveOverlay?: THREE.Object3D;
      rightSleeveOverlay?: THREE.Object3D;
      wingVariant: number;
      wingAnimType: CosmeticItem['animationType'];
    }

    let animRig: AnimRig = {
      capeSegs: [],
      orbitItems: [],
      ankleWinglets: [],
      wingVariant: 0,
      wingAnimType: 'Flutter',
    };

    let lastCosmeticSig = '';

    const rebuildCosmetics = () => {
      while (cosmeticRoot.children.length > 0) {
        cosmeticRoot.remove(cosmeticRoot.children[0]);
      }
      // Clear foot/sleeve children on limb pivots
      [leftLegPivot, rightLegPivot, leftArmPivot, rightArmPivot, headPivot].forEach((piv) => {
        for (let i = piv.children.length - 1; i >= 1; i--) {
          piv.remove(piv.children[i]);
        }
      });

      animRig = {
        capeSegs: [],
        orbitItems: [],
        ankleWinglets: [],
        wingVariant: 0,
        wingAnimType: 'Flutter',
      };

      const st = stateRef.current;
      if (!st.cosmeticsEnabled) return;

      const lookup = (cat: CosmeticCategory) => {
        const id = st.equipped[cat];
        return id ? COSMETICS_CATALOG.find((c) => c.id === id) : undefined;
      };

      const makeMat = (hex: string, glow = false, transparent = false, opacity = 1.0) =>
        new THREE.MeshStandardMaterial({
          color: new THREE.Color(hex),
          roughness: glow ? 0.35 : 0.65,
          metalness: glow ? 0.25 : 0.1,
          emissive: glow ? new THREE.Color(hex) : new THREE.Color(0x000000),
          emissiveIntensity: glow ? 0.55 : 0,
          transparent,
          opacity,
        });

      // 1. Outfit Overlay
      const outfit = lookup('outfitOverlays');
      if (outfit) {
        const p = st.primaryDye || outfit.defaultPrimary;
        const s = st.secondaryDye || outfit.defaultSecondary;
        const v = outfit.shapeVariant;
        const chest = new THREE.Mesh(
          new THREE.BoxGeometry(8.6 * PX, 11.6 * PX, 4.6 * PX),
          makeMat(p, false, true, 0.96)
        );
        chest.position.set(0, 6 * PX, 0);
        cosmeticRoot.add(chest);

        const trim = new THREE.Mesh(
          new THREE.BoxGeometry((v % 2 === 0 ? 2.4 : 6.4) * PX, (v % 3 === 0 ? 10.4 : 2.2) * PX, 4.9 * PX),
          makeMat(s, outfit.animationType === 'Pulse')
        );
        trim.position.set(0, 6 * PX, 0);
        cosmeticRoot.add(trim);

        if (v >= 2) {
          const slMat = makeMat(s, outfit.animationType === 'Pulse');
          const lSl = new THREE.Mesh(new THREE.BoxGeometry(4.4 * PX, 9.2 * PX, 4.4 * PX), slMat);
          lSl.position.y = -4 * PX;
          leftArmPivot.add(lSl);
          const rSl = new THREE.Mesh(new THREE.BoxGeometry(4.4 * PX, 9.2 * PX, 4.4 * PX), slMat);
          rSl.position.y = -4 * PX;
          rightArmPivot.add(rSl);
        }
      }

      // 2. Footwear (mounted directly on leg pivots + moving ankle winglets!)
      const foot = lookup('footwear');
      if (foot) {
        const p = st.primaryDye || foot.defaultPrimary;
        const s = st.secondaryDye || foot.defaultSecondary;
        const v = foot.shapeVariant;
        const addBoot = (legPiv: THREE.Group, side: -1 | 1) => {
          const boot = new THREE.Mesh(new THREE.BoxGeometry(4.6 * PX, 4.4 * PX, 4.8 * PX), makeMat(p));
          boot.position.y = -10.1 * PX;
          legPiv.add(boot);

          const sole = new THREE.Mesh(new THREE.BoxGeometry(4.8 * PX, 1.1 * PX, 5.1 * PX), makeMat(s, foot.animationType === 'Pulse'));
          sole.position.y = -11.9 * PX;
          legPiv.add(sole);

          if (v === 0 || v === 8 || v === 12) {
            // Articulated flapping ankle wings!
            const wMat = makeMat(s, true);
            const wingL = new THREE.Mesh(new THREE.BoxGeometry(0.6 * PX, 2.8 * PX, 3.6 * PX), wMat);
            wingL.position.set(side * 2.7 * PX, -9.2 * PX, -0.6 * PX);
            legPiv.add(wingL);
            const wingR = new THREE.Mesh(new THREE.BoxGeometry(0.6 * PX, 2.2 * PX, 2.8 * PX), wMat);
            wingR.position.set(side * 2.9 * PX, -7.8 * PX, -1.2 * PX);
            legPiv.add(wingR);
            animRig.ankleWinglets.push([wingL, wingR]);
          }
        };
        addBoot(leftLegPivot, -1);
        addBoot(rightLegPivot, 1);
      }

      // 3. Hats (mounted on headPivot)
      const hat = lookup('hats');
      if (hat) {
        const p = st.primaryDye || hat.defaultPrimary;
        const s = st.secondaryDye || hat.defaultSecondary;
        const v = hat.shapeVariant;
        const hatGroup = new THREE.Group();
        hatGroup.position.set(0, 8.2 * PX, 0);
        if (v === 0 || v === 6 || v === 13 || v === 17) {
          const ring = new THREE.Mesh(new THREE.BoxGeometry(8.8 * PX, 1.8 * PX, 8.8 * PX), makeMat(p));
          hatGroup.add(ring);
          [-3, 0, 3].forEach((px, idx) => {
            const spire = new THREE.Mesh(
              new THREE.BoxGeometry(1.4 * PX, (idx === 1 ? 3.2 : 2.3) * PX, 1.4 * PX),
              makeMat(s, true)
            );
            spire.position.set(px * PX, (idx === 1 ? 2.2 : 1.7) * PX, 3.7 * PX);
            hatGroup.add(spire);
          });
        } else if (v === 1 || v === 10) {
          const brim = new THREE.Mesh(new THREE.BoxGeometry(13.5 * PX, 0.9 * PX, 13.5 * PX), makeMat(p));
          const mid = new THREE.Mesh(new THREE.BoxGeometry(7.6 * PX, 3.8 * PX, 7.6 * PX), makeMat(p));
          mid.position.y = 2.0 * PX;
          const tip = new THREE.Mesh(new THREE.BoxGeometry(4.4 * PX, 3.4 * PX, 4.4 * PX), makeMat(p));
          tip.position.set(0, 5.2 * PX, -0.8 * PX);
          tip.rotation.x = -0.22;
          const buckle = new THREE.Mesh(new THREE.BoxGeometry(2.4 * PX, 1.3 * PX, 0.6 * PX), makeMat(s, true));
          buckle.position.set(0, 1.4 * PX, 3.9 * PX);
          hatGroup.add(brim, mid, tip, buckle);
        } else if (v === 4 || v === 5) {
          const brim = new THREE.Mesh(new THREE.BoxGeometry(12.8 * PX, 0.9 * PX, 12.8 * PX), makeMat(p));
          const crown = new THREE.Mesh(new THREE.BoxGeometry(8.2 * PX, 3.2 * PX, 8.2 * PX), makeMat(p));
          crown.position.y = 1.8 * PX;
          const ribbon = new THREE.Mesh(new THREE.BoxGeometry(8.6 * PX, 0.9 * PX, 8.6 * PX), makeMat(s));
          ribbon.position.y = 0.9 * PX;
          hatGroup.add(brim, crown, ribbon);
        } else if (v === 2 || v === 9) {
          const dome = new THREE.Mesh(new THREE.BoxGeometry(9.2 * PX, 3.2 * PX, 9.2 * PX), makeMat(p));
          dome.position.y = 0.4 * PX;
          const hornL = new THREE.Mesh(new THREE.BoxGeometry(1.5 * PX, 4.0 * PX, 2.4 * PX), makeMat(s, true));
          hornL.position.set(-4.8 * PX, 2.2 * PX, 1.0 * PX);
          hornL.rotation.z = 0.35;
          const hornR = new THREE.Mesh(new THREE.BoxGeometry(1.5 * PX, 4.0 * PX, 2.4 * PX), makeMat(s, true));
          hornR.position.set(4.8 * PX, 2.2 * PX, 1.0 * PX);
          hornR.rotation.z = -0.35;
          hatGroup.add(dome, hornL, hornR);
        } else {
          const cap = new THREE.Mesh(new THREE.BoxGeometry(8.8 * PX, (v === 7 ? 5.2 : 2.8) * PX, 8.8 * PX), makeMat(p));
          cap.position.y = 1.0 * PX;
          const accent = new THREE.Mesh(new THREE.BoxGeometry(8.4 * PX, 0.9 * PX, 3.0 * PX), makeMat(s, true));
          accent.position.set(0, 0.2 * PX, 5.1 * PX);
          hatGroup.add(cap, accent);
        }
        headPivot.add(hatGroup);
      }

      // 4. Head Accessories (Halos, Orbiting Crystals, Horns, Ears, Headsets)
      const headAcc = lookup('headAccessories');
      if (headAcc) {
        const p = st.primaryDye || headAcc.defaultPrimary;
        const s = st.secondaryDye || headAcc.defaultSecondary;
        const v = headAcc.shapeVariant;
        if (v === 0 || v === 2 || v === 8 || v === 12) {
          const halo = new THREE.Group();
          halo.position.set(0, 11.4 * PX, 0);
          const ring = new THREE.Mesh(
            new THREE.TorusGeometry(5.6 * PX, 0.55 * PX, 8, 28),
            makeMat(p, true)
          );
          ring.rotation.x = Math.PI / 2;
          halo.add(ring);
          if (v === 12) {
            const ring2 = new THREE.Mesh(new THREE.TorusGeometry(4.2 * PX, 0.4 * PX, 8, 24), makeMat(s, true));
            ring2.rotation.x = Math.PI / 2;
            ring2.position.y = 1.2 * PX;
            halo.add(ring2);
          }
          headPivot.add(halo);
          animRig.haloGroup = halo;
        } else if (v === 6 || v === 14) {
          const orbitCenter = new THREE.Group();
          orbitCenter.position.set(0, 9.6 * PX, 0);
          for (let i = 0; i < 3; i++) {
            const prism = new THREE.Mesh(
              new THREE.OctahedronGeometry(1.4 * PX, 0),
              makeMat(i % 2 === 0 ? p : s, true)
            );
            const ang = (i * Math.PI * 2) / 3;
            prism.position.set(Math.cos(ang) * 7.2 * PX, 0, Math.sin(ang) * 7.2 * PX);
            orbitCenter.add(prism);
            animRig.orbitItems.push(prism);
          }
          headPivot.add(orbitCenter);
          animRig.haloGroup = orbitCenter;
        } else if (v === 11) {
          const cupL = new THREE.Mesh(new THREE.BoxGeometry(1.6 * PX, 4.4 * PX, 4.4 * PX), makeMat(p));
          cupL.position.set(-4.8 * PX, 4.0 * PX, 0);
          const cupR = new THREE.Mesh(new THREE.BoxGeometry(1.6 * PX, 4.4 * PX, 4.4 * PX), makeMat(p));
          cupR.position.set(4.8 * PX, 4.0 * PX, 0);
          const band = new THREE.Mesh(new THREE.BoxGeometry(9.8 * PX, 1.0 * PX, 1.5 * PX), makeMat(s, true));
          band.position.set(0, 8.6 * PX, 0);
          headPivot.add(cupL, cupR, band);
        } else {
          // Fox/Cat ears or Curved Horns
          const earL = new THREE.Mesh(new THREE.BoxGeometry(1.8 * PX, 3.8 * PX, 1.8 * PX), makeMat(p));
          earL.position.set(-3.2 * PX, 9.6 * PX, 0.5 * PX);
          earL.rotation.z = 0.2;
          const earR = new THREE.Mesh(new THREE.BoxGeometry(1.8 * PX, 3.8 * PX, 1.8 * PX), makeMat(p));
          earR.position.set(3.2 * PX, 9.6 * PX, 0.5 * PX);
          earR.rotation.z = -0.2;
          const tipL = new THREE.Mesh(new THREE.BoxGeometry(1.2 * PX, 1.6 * PX, 1.2 * PX), makeMat(s, true));
          tipL.position.set(-3.6 * PX, 11.4 * PX, 0.5 * PX);
          const tipR = new THREE.Mesh(new THREE.BoxGeometry(1.2 * PX, 1.6 * PX, 1.2 * PX), makeMat(s, true));
          tipR.position.set(3.6 * PX, 11.4 * PX, 0.5 * PX);
          headPivot.add(earL, earR, tipL, tipR);
        }
      }

      // 5. Masks
      const mask = lookup('masks');
      if (mask) {
        const p = st.primaryDye || mask.defaultPrimary;
        const s = st.secondaryDye || mask.defaultSecondary;
        const v = mask.shapeVariant;
        if (v === 6 || v === 7 || v === 14) {
          const strap = new THREE.Mesh(new THREE.BoxGeometry(8.4 * PX, 1.2 * PX, 8.4 * PX), makeMat(p));
          strap.position.set(0, 4.4 * PX, 0);
          const lensL = new THREE.Mesh(new THREE.BoxGeometry(2.8 * PX, 2.2 * PX, 0.7 * PX), makeMat(s, true));
          lensL.position.set(-2.0 * PX, 4.4 * PX, 4.25 * PX);
          const lensR = new THREE.Mesh(new THREE.BoxGeometry(2.8 * PX, 2.2 * PX, 0.7 * PX), makeMat(s, true));
          lensR.position.set(2.0 * PX, 4.4 * PX, 4.25 * PX);
          headPivot.add(strap, lensL, lensR);
        } else {
          const plate = new THREE.Mesh(new THREE.BoxGeometry(8.2 * PX, (v % 2 === 0 ? 3.8 : 2.6) * PX, 0.8 * PX), makeMat(p));
          plate.position.set(0, 2.8 * PX, 4.2 * PX);
          const accentL = new THREE.Mesh(new THREE.BoxGeometry(1.6 * PX, 1.0 * PX, 0.4 * PX), makeMat(s, true));
          accentL.position.set(-2.2 * PX, 3.0 * PX, 4.55 * PX);
          const accentR = new THREE.Mesh(new THREE.BoxGeometry(1.6 * PX, 1.0 * PX, 0.4 * PX), makeMat(s, true));
          accentR.position.set(2.2 * PX, 3.0 * PX, 4.55 * PX);
          headPivot.add(plate, accentL, accentR);
        }
      }

      // 6. Articulated Flowing Capes (3 hinged cloth panels!)
      const cape = lookup('capes');
      if (cape) {
        const p = st.primaryDye || cape.defaultPrimary;
        const s = st.secondaryDye || cape.defaultSecondary;
        const capeTex = createFeatherPatternTexture(p, s);
        const capeMat = new THREE.MeshStandardMaterial({ map: capeTex, roughness: 0.75 });
        const crestMat = makeMat(s, true);
        let parent: THREE.Object3D = cosmeticRoot;
        for (let i = 0; i < 3; i++) {
          const segPivot = new THREE.Group();
          segPivot.position.set(0, i === 0 ? 11.5 * PX : -5.3 * PX, i === 0 ? -2.4 * PX : 0);
          const panel = new THREE.Mesh(new THREE.BoxGeometry(9.4 * PX, 5.4 * PX, 0.55 * PX), capeMat);
          panel.position.y = -2.7 * PX;
          segPivot.add(panel);
          if (i === 1) {
            const emblem = new THREE.Mesh(new THREE.BoxGeometry(3.8 * PX, 3.8 * PX, 0.25 * PX), crestMat);
            emblem.position.set(0, -2.7 * PX, -0.35 * PX);
            segPivot.add(emblem);
          }
          parent.add(segPivot);
          animRig.capeSegs.push(segPivot);
          parent = segPivot;
        }
      }

      // 7. ARTICULATED 3D MOVING WINGS (24 Unique Visual Styles!)
      const wing = lookup('wings');
      if (wing) {
        const p = st.primaryDye || wing.defaultPrimary;
        const s = st.secondaryDye || wing.defaultSecondary;
        const v = wing.shapeVariant;
        animRig.wingVariant = v;
        animRig.wingAnimType = wing.animationType;

        const wingTex = createFeatherPatternTexture(p, s);
        const primaryMat = new THREE.MeshStandardMaterial({
          map: wingTex,
          roughness: 0.45,
          metalness: 0.15,
          emissive: new THREE.Color(p),
          emissiveIntensity: wing.rarity === 'Signature' ? 0.24 : 0.08,
        });
        const accentMat = makeMat(s, wing.rarity === 'Signature' || wing.rarity === 'Mythic');
        const translucentMat = makeMat(s, true, true, 0.68);

        const buildWingSide = (side: -1 | 1) => {
          const rootPivot = new THREE.Group();
          rootPivot.position.set(side * 2.2 * PX, 9.5 * PX, -2.4 * PX);
          cosmeticRoot.add(rootPivot);

          const outerPivot = new THREE.Group();
          outerPivot.position.set(side * 7.8 * PX * st.wingSpread, 1.5 * PX, 0);
          rootPivot.add(outerPivot);

          if (v === 2 || v === 4 || v === 13) {
            // Butterfly / Fairy / Lunar Moth double-lobe translucent wings
            const upperLobe = new THREE.Mesh(
              new THREE.BoxGeometry(10.5 * PX * st.wingSpread, 6.8 * PX * st.wingSpread, 0.35 * PX),
              v === 4 ? translucentMat : primaryMat
            );
            upperLobe.position.set(side * 5.2 * PX * st.wingSpread, 2.2 * PX, 0);
            upperLobe.rotation.z = side * 0.22;
            const lowerLobe = new THREE.Mesh(
              new THREE.BoxGeometry(7.8 * PX * st.wingSpread, (v === 13 ? 8.2 : 5.6) * PX * st.wingSpread, 0.35 * PX),
              accentMat
            );
            lowerLobe.position.set(side * 4.2 * PX * st.wingSpread, -3.4 * PX, 0);
            lowerLobe.rotation.z = side * -0.18;
            rootPivot.add(upperLobe, lowerLobe);
          } else if (v === 3 || v === 14 || v === 15 || v === 19) {
            // Cyber Mech Thrusters / Holo-Grid / Storm Lightning / Valkyrie Blade-Wings
            for (let b = 0; b < 3; b++) {
              const blade = new THREE.Mesh(
                new THREE.BoxGeometry((9.5 - b * 1.4) * PX * st.wingSpread, 2.0 * PX * st.wingSpread, 0.65 * PX),
                b % 2 === 0 ? primaryMat : accentMat
              );
              blade.position.set(side * (4.8 + b * 1.1) * PX * st.wingSpread, (3.2 - b * 3.1) * PX, -0.3 * PX);
              blade.rotation.z = side * (0.28 - b * 0.24);
              (b === 0 ? rootPivot : outerPivot).add(blade);
            }
          } else if (v === 10 || v === 17 || v === 22 || v === 23) {
            // Floating Astral Pinions / Constellation / Solar Halo / Nebula Ribbons
            for (let seg = 0; seg < 4; seg++) {
              const shard = new THREE.Mesh(
                new THREE.BoxGeometry(3.2 * PX * st.wingSpread, (4.8 - seg * 0.5) * PX * st.wingSpread, 0.55 * PX),
                seg % 2 === 0 ? primaryMat : accentMat
              );
              shard.position.set(side * (3.6 + seg * 3.2) * PX * st.wingSpread, (2.2 - seg * 1.3) * PX, -0.4 * PX);
              shard.rotation.z = side * (0.35 - seg * 0.14);
              (seg < 2 ? rootPivot : outerPivot).add(shard);
            }
          } else {
            // Articulated Multi-Feather / Dragon Membrane Wings
            const boneStrut = new THREE.Mesh(
              new THREE.BoxGeometry(8.5 * PX * st.wingSpread, 1.3 * PX, 0.9 * PX),
              makeMat(p)
            );
            boneStrut.position.set(side * 4.0 * PX * st.wingSpread, 1.6 * PX, 0);
            boneStrut.rotation.z = side * 0.22;
            rootPivot.add(boneStrut);

            for (let f = 0; f < 3; f++) {
              const plume = new THREE.Mesh(
                new THREE.BoxGeometry(3.0 * PX * st.wingSpread, (6.5 - f * 0.8) * PX * st.wingSpread, 0.45 * PX),
                f === 2 ? accentMat : primaryMat
              );
              plume.position.set(side * (2.6 + f * 2.2) * PX * st.wingSpread, (-1.6 - f * 0.4) * PX, -0.1 * PX);
              plume.rotation.z = side * (0.12 - f * 0.08);
              rootPivot.add(plume);
            }

            // Outer articulated wingtip feathers
            const tipStrut = new THREE.Mesh(
              new THREE.BoxGeometry(7.2 * PX * st.wingSpread, 1.1 * PX, 0.75 * PX),
              accentMat
            );
            tipStrut.position.set(side * 3.4 * PX * st.wingSpread, 0.6 * PX, 0);
            tipStrut.rotation.z = side * -0.15;
            outerPivot.add(tipStrut);

            for (let tIdx = 0; tIdx < 3; tIdx++) {
              const tipFeather = new THREE.Mesh(
                new THREE.BoxGeometry(2.6 * PX * st.wingSpread, (7.4 - tIdx * 1.2) * PX * st.wingSpread, 0.4 * PX),
                tIdx % 2 === 0 ? primaryMat : accentMat
              );
              tipFeather.position.set(side * (1.8 + tIdx * 2.1) * PX * st.wingSpread, (-2.6 - tIdx * 0.2) * PX, 0);
              tipFeather.rotation.z = side * (-0.1 - tIdx * 0.14);
              outerPivot.add(tipFeather);
            }
          }
          return { rootPivot, outerPivot };
        };

        const left = buildWingSide(-1);
        const right = buildWingSide(1);
        animRig.leftWingRoot = left.rootPivot;
        animRig.leftWingOuter = left.outerPivot;
        animRig.rightWingRoot = right.rootPivot;
        animRig.rightWingOuter = right.outerPivot;
      }

      // 8. Shoulder Accessories (Animated Dragonet/Bird/Gear companions!)
      const shoulder = lookup('shoulderAccessories');
      if (shoulder) {
        const p = st.primaryDye || shoulder.defaultPrimary;
        const s = st.secondaryDye || shoulder.defaultSecondary;
        const shGroup = new THREE.Group();
        shGroup.position.set(-7.6 * PX, 13.5 * PX, 0);
        const petBody = new THREE.Mesh(new THREE.BoxGeometry(3.2 * PX, 3.0 * PX, 3.4 * PX), makeMat(p));
        const petEye = new THREE.Mesh(new THREE.BoxGeometry(1.5 * PX, 1.1 * PX, 0.5 * PX), makeMat(s, true));
        petEye.position.set(0, 0.4 * PX, 1.75 * PX);
        const miniWL = new THREE.Mesh(new THREE.BoxGeometry(2.2 * PX, 0.5 * PX, 2.0 * PX), makeMat(s, true));
        miniWL.position.set(-2.2 * PX, 0.6 * PX, -0.2 * PX);
        const miniWR = new THREE.Mesh(new THREE.BoxGeometry(2.2 * PX, 0.5 * PX, 2.0 * PX), makeMat(s, true));
        miniWR.position.set(2.2 * PX, 0.6 * PX, -0.2 * PX);
        shGroup.add(petBody, petEye, miniWL, miniWR);
        cosmeticRoot.add(shGroup);
        animRig.shoulderGroup = shGroup;
        animRig.shoulderMiniWings = [miniWL, miniWR];
      }

      // 9. Back Accessories (Spinning Chakra Rings, Kitsune 9-Tail Fan, Crossed Swords)
      const back = lookup('backAccessories');
      if (back) {
        const p = st.primaryDye || back.defaultPrimary;
        const s = st.secondaryDye || back.defaultSecondary;
        const v = back.shapeVariant;
        if (v === 4 || v === 10 || v === 16) {
          const ring = new THREE.Group();
          ring.position.set(0, 7.5 * PX, -3.5 * PX);
          for (let i = 0; i < 6; i++) {
            const ang = (i * Math.PI) / 3;
            const orb = new THREE.Mesh(new THREE.BoxGeometry(2.0 * PX, 2.0 * PX, 0.9 * PX), makeMat(i % 2 === 0 ? p : s, true));
            orb.position.set(Math.cos(ang) * 7.2 * PX, Math.sin(ang) * 7.2 * PX, 0);
            orb.rotation.z = ang;
            ring.add(orb);
          }
          cosmeticRoot.add(ring);
          animRig.backSpinRing = ring;
        } else if (v === 12) {
          const tails: THREE.Group[] = [];
          for (let ti = -2; ti <= 2; ti++) {
            const tg = new THREE.Group();
            tg.position.set(0, 1.5 * PX, -2.5 * PX);
            const tail = new THREE.Mesh(new THREE.BoxGeometry(2.0 * PX, 9.5 * PX, 1.6 * PX), makeMat(ti === 0 ? s : p, ti === 0));
            tail.position.set(ti * 2.1 * PX, 2.2 * PX, -3.4 * PX);
            tail.rotation.x = -0.55;
            tail.rotation.z = ti * 0.25;
            tg.add(tail);
            cosmeticRoot.add(tg);
            tails.push(tg);
          }
          animRig.tailGroup = tails;
        } else {
          const blade = new THREE.Mesh(new THREE.BoxGeometry(2.4 * PX, 14.5 * PX, 1.0 * PX), makeMat(p));
          blade.position.set(0, 6.8 * PX, -3.4 * PX);
          blade.rotation.z = 0.52;
          const core = new THREE.Mesh(new THREE.BoxGeometry(4.4 * PX, 5.5 * PX, 1.5 * PX), makeMat(s, back.animationType === 'Pulse'));
          core.position.set(-1.6 * PX, 6.5 * PX, -3.6 * PX);
          cosmeticRoot.add(blade, core);
        }
      }
    };

    const handleResize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(10, Math.round(rect.width));
      const h = Math.max(10, Math.round(rect.height));
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    handleResize();

    const ro = new ResizeObserver(handleResize);
    ro.observe(canvas);

    let raf = 0;
    const start = performance.now();
    let prevTime = start;

    const animate = (now: number) => {
      const st = stateRef.current;
      const dt = Math.min(0.05, (now - prevTime) * 0.001);
      prevTime = now;

      const sig = JSON.stringify([
        st.cosmeticsEnabled,
        st.equipped,
        st.primaryDye,
        st.secondaryDye,
        st.wingSpread,
      ]);
      if (sig !== lastCosmeticSig) {
        lastCosmeticSig = sig;
        rebuildCosmetics();
      }

      pedestalMat.color.set(st.accentColor);
      rimLight.color.set(st.accentColor);

      if (st.autoSpin && !draggingRef.current.active && st.animationsEnabled) {
        setYawDeg((y) => (y + dt * 24) % 360);
      }

      const t = st.animationsEnabled ? (now - start) * 0.001 : 0;
      const flapT = t * st.wingFlapSpeed;

      // Body & Limb Poses
      const walkRad = st.pose === 'walk' ? Math.sin(t * 6.0) * 0.58 : 0;
      const breathe = st.animationsEnabled ? Math.sin(t * 2.3) * 0.02 : 0;
      bodyGroup.position.y = -0.58 + breathe + (st.pose === 'glide' ? 0.14 : 0);
      bodyGroup.rotation.x = st.pose === 'glide' ? 0.34 : 0;

      leftArmPivot.rotation.x = walkRad * 0.85;
      leftArmPivot.rotation.z = st.pose === 'glide' ? 0.35 : 0.08;
      rightArmPivot.rotation.x = st.pose === 'wave' ? -2.35 + Math.sin(t * 7.2) * 0.35 : -walkRad * 0.85;
      rightArmPivot.rotation.z = st.pose === 'wave' ? -0.35 : st.pose === 'glide' ? -0.35 : -0.08;

      leftLegPivot.rotation.x = st.pose === 'glide' ? 0.18 : -walkRad;
      rightLegPivot.rotation.x = st.pose === 'glide' ? 0.32 : walkRad;

      // Articulated Wings Animation (inner + phase-lagged outer joint!)
      if (animRig.leftWingRoot && animRig.rightWingRoot) {
        const isGlide = st.pose === 'glide';
        const isWalk = st.pose === 'walk';
        const freq = isWalk ? 4.8 : isGlide ? 3.8 : 3.2;
        const amp = isGlide ? 0.34 : isWalk ? 0.42 : 0.36;
        const baseRest = (isGlide ? 0.25 : 0.44) * (2.0 - Math.min(1.4, st.wingSpread));

        const beat = st.animationsEnabled ? Math.sin(flapT * freq) * amp : 0;
        const outerLag = st.animationsEnabled ? Math.sin(flapT * freq - 0.85) * (amp * 0.72) : 0;

        animRig.leftWingRoot.rotation.y = baseRest + beat;
        animRig.rightWingRoot.rotation.y = -(baseRest + beat);
        if (animRig.leftWingOuter && animRig.rightWingOuter) {
          animRig.leftWingOuter.rotation.y = outerLag;
          animRig.rightWingOuter.rotation.y = -outerLag;
        }
      }

      // Flowing 3-segment Cape Swing
      animRig.capeSegs.forEach((seg, idx) => {
        const base = st.pose === 'glide' ? -0.68 : st.pose === 'walk' ? -0.34 : -0.14;
        const wave = st.animationsEnabled ? Math.sin(t * 3.2 - idx * 0.7) * 0.12 : 0;
        seg.rotation.x = (idx === 0 ? base : wave) + wave * 0.45;
      });

      // Halos & Orbiting Prisms
      if (animRig.haloGroup) {
        animRig.haloGroup.rotation.y = st.animationsEnabled ? t * 1.1 : 0;
        animRig.haloGroup.position.y = 10.6 * PX + (st.animationsEnabled ? Math.sin(t * 3.0) * 0.04 : 0);
      }

      // Shoulder Companion + Mini Flapping Wings
      if (animRig.shoulderGroup) {
        animRig.shoulderGroup.position.y = 13.5 * PX + (st.animationsEnabled ? Math.sin(t * 3.8) * 0.045 : 0);
        if (animRig.shoulderMiniWings) {
          const mf = st.animationsEnabled ? Math.sin(flapT * 7.5) * 0.55 : 0;
          animRig.shoulderMiniWings[0].rotation.z = -mf;
          animRig.shoulderMiniWings[1].rotation.z = mf;
        }
      }

      // Ankle Winglets Flap
      animRig.ankleWinglets.forEach(([wL, wR]) => {
        const af = st.animationsEnabled ? Math.sin(flapT * 6.5) * 0.45 : 0;
        wL.rotation.y = 0.35 + af;
        wR.rotation.y = -0.35 - af;
      });

      // Back Spinning Chakra / Portal Ring
      if (animRig.backSpinRing) {
        animRig.backSpinRing.rotation.z = st.animationsEnabled ? t * 1.45 : 0;
      }

      // Kitsune Tails
      if (animRig.tailGroup) {
        animRig.tailGroup.forEach((tg, idx) => {
          tg.rotation.y = st.animationsEnabled ? Math.sin(t * 3.0 + idx * 0.6) * 0.18 : 0;
        });
      }

      // Camera Orbit Position
      const radYaw = (st.yawDeg * Math.PI) / 180;
      const radPitch = (st.pitchDeg * Math.PI) / 180;
      const dist = 4.35 / st.zoom;
      camera.position.set(
        Math.sin(radYaw) * Math.cos(radPitch) * dist,
        0.15 + Math.sin(radPitch) * dist,
        Math.cos(radYaw) * Math.cos(radPitch) * dist
      );
      camera.lookAt(0, 0.05, 0);

      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };

    raf = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      headTex.dispose();
      torsoTex.dispose();
      limbTex.dispose();
      renderer.dispose();
    };
  }, [accentColor]);

  // Real PNG Screenshot Exporter
  const handleScreenshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `itsm3liodas-cosmetic-showcase-${Date.now()}.png`;
    a.click();
    onToast?.('Screenshot Saved (.png)', 'Captured crisp 3D WebGL showcase image.', 'success');
  };

  // Real 60fps WebM Video Recorder using MediaRecorder + canvas.captureStream
  const handleToggleRecord = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (recording && recorderRef.current) {
      recorderRef.current.stop();
      setRecording(false);
      return;
    }

    if (typeof MediaRecorder === 'undefined' || !('captureStream' in canvas)) {
      onToast?.('Recording Unsupported', 'Your browser does not support MediaRecorder canvas capture.', 'warning');
      return;
    }

    try {
      const stream = canvas.captureStream(60);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm';
      const rec = new MediaRecorder(stream, { mimeType });
      recordedChunksRef.current = [];
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };
      rec.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `itsm3liodas-wings-showcase-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
        onToast?.('Video Saved (.webm)', 'Downloaded 3D showcase video clip!', 'success');
      };
      rec.start();
      recorderRef.current = rec;
      setRecording(true);
      onToast?.('Recording Started', 'Spin or cycle wings, then click Stop to save .webm video.', 'info');
    } catch {
      onToast?.('Record Error', 'Could not start WebM canvas recorder.', 'error');
    }
  };

  // Contact Sheet Screenshot (captures multi-angle PNG sheet of current outfit)
  const handleMultiAngleSheet = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const sheet = document.createElement('canvas');
    sheet.width = canvas.width * 2;
    sheet.height = canvas.height + 64;
    const ctx = sheet.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#070A14';
    ctx.fillRect(0, 0, sheet.width, sheet.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 20px Inter, sans-serif';
    ctx.fillText('ItsM3liodas Client — 3D Cosmetic Showcase Snapshot', 24, 38);
    ctx.drawImage(canvas, 0, 56);
    ctx.drawImage(canvas, canvas.width, 56);
    const a = document.createElement('a');
    a.href = sheet.toDataURL('image/png');
    a.download = `itsm3liodas-showcase-card-${Date.now()}.png`;
    a.click();
    onToast?.('Showcase Card Saved (.png)', 'Exported wide showcase card.', 'success');
  };

  return (
    <div
      ref={containerRef}
      className="relative flex h-full w-full flex-col overflow-hidden rounded-xl border border-white/10 bg-gradient-to-b from-slate-900/80 via-[#090D1C] to-slate-950"
    >
      <canvas
        ref={canvasRef}
        onMouseDown={(e) => {
          draggingRef.current = { active: true, x: e.clientX, y: e.clientY };
        }}
        onMouseMove={(e) => {
          if (!draggingRef.current.active) return;
          const dx = e.clientX - draggingRef.current.x;
          const dy = e.clientY - draggingRef.current.y;
          draggingRef.current = { active: true, x: e.clientX, y: e.clientY };
          setYawDeg((y) => y - dx * 0.75);
          setPitchDeg((p) => Math.max(-42, Math.min(48, p + dy * 0.45)));
        }}
        onMouseUp={() => (draggingRef.current.active = false)}
        onMouseLeave={() => (draggingRef.current.active = false)}
        onWheel={(e) => {
          e.preventDefault();
          setZoom((z) => Math.max(0.65, Math.min(1.85, z - e.deltaY * 0.001)));
        }}
        className="h-full min-h-[360px] w-full cursor-grab active:cursor-grabbing"
      />

      {/* Top Capture & Reel Controls */}
      <div className="absolute top-3 right-3 left-3 flex flex-wrap items-center justify-between gap-2">
        <span className="pointer-events-none rounded-md border border-white/10 bg-black/55 px-2.5 py-1 text-[11px] font-medium text-slate-200 backdrop-blur-md">
          WebGL 3D · Drag Rotate · Scroll Zoom
        </span>

        <div className="flex flex-wrap items-center gap-1.5">
          {onCycleNextWing && (
            <button
              type="button"
              onClick={() => setAutoReel((r) => !r)}
              className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-medium backdrop-blur-md ${
                autoReel ? 'border-sky-400/50 bg-sky-500/25 text-sky-100' : 'border-white/15 bg-black/60 text-slate-200 hover:bg-white/15'
              }`}
              title="Automatically cycle through all 24 animated wings"
            >
              <Play className="h-3 w-3" /> {autoReel ? 'Cycling Wings...' : 'Auto-Cycle Wings'}
            </button>
          )}
          <button
            type="button"
            onClick={handleScreenshot}
            className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/60 px-2 py-1 text-[11px] font-medium text-slate-100 backdrop-blur-md hover:bg-white/15"
            title="Download crisp PNG screenshot"
          >
            <Camera className="h-3 w-3" /> PNG
          </button>
          <button
            type="button"
            onClick={handleMultiAngleSheet}
            className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/60 px-2 py-1 text-[11px] font-medium text-slate-100 backdrop-blur-md hover:bg-white/15"
            title="Download wide Showcase Card PNG"
          >
            <Grid className="h-3 w-3" /> Card
          </button>
          <button
            type="button"
            onClick={handleToggleRecord}
            className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-semibold backdrop-blur-md ${
              recording
                ? 'animate-pulse border-rose-400/60 bg-rose-600/80 text-white'
                : 'border-white/15 bg-black/60 text-slate-100 hover:bg-white/15'
            }`}
            title="Record live 60fps WebM showcase video"
          >
            {recording ? <Square className="h-3 w-3 fill-white" /> : <Video className="h-3 w-3" />}
            {recording ? 'Stop & Save' : 'Rec Video'}
          </button>
        </div>
      </div>

      {/* Bottom Camera Controls */}
      <div className="absolute right-3 bottom-3 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => setAutoSpin((s) => !s)}
          className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1.5 text-[11px] font-medium backdrop-blur-md ${
            autoSpin ? 'border-emerald-400/40 bg-emerald-500/20 text-emerald-200' : 'border-white/15 bg-black/60 text-slate-300 hover:bg-white/15'
          }`}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${autoSpin && animationsEnabled ? 'animate-spin' : ''}`} />
          Spin
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.min(1.85, z + 0.15))}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
          title="Zoom In"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.max(0.65, z - 0.15))}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
          title="Zoom Out"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            setYawDeg(145);
            setPitchDeg(12);
            setZoom(1.0);
          }}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
          title="Reset Camera"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};
