import {
  Eye,
  FolderArchive,
  Layers,
  LayoutGrid,
  Maximize2,
  Minimize2,
  Crown,
  Search,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { FabricDeliveryView } from './components/FabricDeliveryView';
import { HudEditorPanel } from './components/HudEditorPanel';
import { MinecraftViewport } from './components/MinecraftViewport';
import { ModulesWorkspace } from './components/ModulesWorkspace';
import { StylesWardrobe } from './components/StylesWardrobe';
import { formatKeyCodeLabel, useClientStore } from './store/useClientStore';
import { FontFamilyId } from './types/client';

const APP_FONT: Record<FontFamilyId, string> = {
  inter: "'Inter', system-ui, sans-serif",
  space: "'Space Grotesk', system-ui, sans-serif",
  mono: "'JetBrains Mono', monospace",
  pixel: "'JetBrains Mono', monospace",
};

export function App() {
  const {
    config,
    setConfig,
    world,
    setWorld,
    musicState,
    togglePlayMusic,
    stepTrack,
    selectTrack,
    loadLocalAudioTrack,
    attachLrcToCurrentTrack,
    lookupOnlineLyrics,
    menuOpen,
    setMenuOpen,
    activeTab,
    setActiveTab,
    toasts,
    pushToast,
    recordMouseClick,
    recordSettingChange,
    applyThemePreset,
    applyMotionBlurPreset,
    applyColorGradingPreset,
    applyPerformancePreset,
    toggleFavoriteModule,
    updateHudElement,
    resetAllHudElements,
    equipCosmetic,
    toggleVisualPack,
    importVisualPackJson,
    keybindConflicts,
    exportFullConfig,
    importFullConfig,
    restoreBackupConfig,
    resetAllConfig,
  } = useClientStore();

  const menuBlurPx =
    config.menuBlur.enabled && config.menuBlur.blurClientMenu
      ? config.menuBlur.performanceFriendly
        ? Math.min(8, config.menuBlur.strength)
        : config.menuBlur.strength
      : 0;

  const menuDimAlpha = config.menuBlur.enabled && config.menuBlur.blurClientMenu ? config.menuBlur.dimming : 0.15;

  const panelBg = config.theme.gradientEnabled
    ? `linear-gradient(155deg, ${config.theme.backgroundTop}, ${config.theme.backgroundBottom})`
    : config.theme.backgroundTop;

  return (
    <div
      style={{ fontFamily: APP_FONT[config.theme.fontFamily] }}
      className="relative h-screen w-screen overflow-hidden bg-[#060810] text-slate-100"
    >
      {/* Always-live 3D Minecraft 1.21.11 Simulation Viewport + HUD Overlay */}
      <div className="absolute inset-0">
        <MinecraftViewport
          config={config}
          world={world}
          setWorld={setWorld}
          musicState={musicState}
          onTogglePlayMusic={togglePlayMusic}
          onStepTrack={stepTrack}
          onMouseAction={recordMouseClick}
          interactiveMode={!menuOpen}
        />
      </div>

      {/* Top Floating Quick Play Bar when Client Menu is Minimized */}
      {!menuOpen && (
        <div className="absolute top-3 left-1/2 z-30 flex -translate-x-1/2 flex-wrap items-center gap-2 rounded-full border border-white/15 bg-black/65 px-3.5 py-1.5 text-xs shadow-2xl backdrop-blur-md">
          <span className="font-semibold text-white">ItsM3liodas Client</span>
          <span className="text-slate-400">·</span>
          <span className="text-[11px] text-slate-300">
            WASD/Space = Keystrokes · Drag = Look · <strong className="font-mono text-sky-300">{formatKeyCodeLabel(config.keybinds.zoom.key)}</strong> = Zoom ·{' '}
            <strong className="font-mono text-sky-300">{formatKeyCodeLabel(config.keybinds.freelook.key)}</strong> = Freelook
          </span>
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            style={{ backgroundColor: config.theme.accentColor }}
            className="ml-1 inline-flex items-center gap-1 rounded-full px-3 py-1 text-[11px] font-semibold text-white shadow"
          >
            <Maximize2 className="h-3 w-3" /> Open Menu ({formatKeyCodeLabel(config.keybinds.openMenu.key)})
          </button>
        </div>
      )}

      {/* Client Menu Overlay with Independent Menu Blur */}
      {menuOpen && (
        <div
          style={{
            backdropFilter: `blur(${menuBlurPx}px)`,
            WebkitBackdropFilter: `blur(${menuBlurPx}px)`,
            backgroundColor: `rgba(4, 6, 14, ${menuDimAlpha})`,
          }}
          className={`absolute inset-0 z-30 flex items-center justify-center p-2 sm:p-4 ${
            config.menuBlur.smoothTransitions ? 'transition-all duration-200' : ''
          }`}
        >
          <div
            style={{
              background: panelBg,
              opacity: config.menuBlur.enabled ? config.menuBlur.opacity : config.theme.panelOpacity,
              borderRadius: `${config.theme.cornerRadius}px`,
            }}
            className="mc-animate-in flex h-full max-h-[92vh] w-full max-w-[1440px] flex-col overflow-hidden border border-white/15 shadow-[0_24px_80px_rgba(0,0,0,0.75)]"
          >
            <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-3">
              <div className="flex items-center gap-3">
                <div
                  style={{
                    background: `linear-gradient(135deg, ${config.theme.accentColor}, ${config.theme.secondaryColor})`,
                  }}
                  className="flex h-9 w-9 items-center justify-center rounded-xl shadow-lg"
                >
                  <Crown className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-sm font-bold tracking-tight text-white sm:text-base">
                      ITSM3LIODAS CLIENT
                    </h1>
                    <span className="rounded-md border border-white/15 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-slate-300">
                      v2.5.0 · MC 1.21.11 · Fabric
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Visuals · Uku Armor HUD · Valence Sky Lyrics · ItsM3liodas Styles (168 Cosmetics &amp; Moving Wings)
                  </p>
                </div>
              </div>

              <nav className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'studio', label: 'Client Modules', icon: LayoutGrid },
                  { id: 'hud', label: 'HUD Editor', icon: Layers },
                  { id: 'wardrobe', label: '3D Cosmetics & Wings', icon: Sparkles },
                  { id: 'delivery', label: 'Fabric 1.21.11 & ZIP', icon: FolderArchive },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const active = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveTab(tab.id as typeof activeTab)}
                      style={active ? { backgroundColor: config.theme.accentColor } : undefined}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
                        active ? 'text-white shadow-md' : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>

              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, zoomEngaged: !w.zoomEngaged }))}
                  className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium ${
                    world.zoomEngaged ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-200' : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <Search className="h-3 w-3" /> Zoom
                </button>
                <button
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, freelookEngaged: !w.freelookEngaged }))}
                  className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-[11px] font-medium ${
                    world.freelookEngaged ? 'border-sky-400/50 bg-sky-500/20 text-sky-200' : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                  }`}
                >
                  <Eye className="h-3 w-3" /> Freelook
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setWorld((w) => ({
                      ...w,
                      pingMs: w.pingMs === null ? 24 : null,
                      serverAddress: w.serverAddress === null ? 'play.itsm3liodas.net' : null,
                    }))
                  }
                  className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-[11px] text-slate-300 hover:bg-white/10"
                >
                  {world.pingMs !== null ? <Wifi className="h-3 w-3 text-emerald-400" /> : <WifiOff className="h-3 w-3 text-amber-400" />}
                  {world.pingMs !== null ? '24ms' : 'Singleplayer'}
                </button>
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/10 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-white/20"
                >
                  <Minimize2 className="h-3.5 w-3.5" /> Play Viewport
                </button>
              </div>
            </header>

            <main className="min-h-0 flex-1 overflow-y-auto p-4">
              {activeTab === 'studio' && (
                <ModulesWorkspace
                  config={config}
                  setConfig={setConfig}
                  world={world}
                  setWorld={setWorld}
                  musicState={musicState}
                  onTogglePlayMusic={togglePlayMusic}
                  onStepTrack={stepTrack}
                  onSelectTrack={selectTrack}
                  onLoadAudioFile={loadLocalAudioTrack}
                  onAttachLrc={attachLrcToCurrentTrack}
                  onLookupOnlineLyrics={lookupOnlineLyrics}
                  keybindConflicts={keybindConflicts}
                  onApplyTheme={applyThemePreset}
                  onApplyMotionBlurPreset={applyMotionBlurPreset}
                  onApplyColorGradingPreset={applyColorGradingPreset}
                  onApplyPerformance={applyPerformancePreset}
                  onToggleFavorite={toggleFavoriteModule}
                  onRecordSetting={recordSettingChange}
                  onToggleVisualPack={toggleVisualPack}
                  onImportVisualPack={importVisualPackJson}
                  onExportConfig={exportFullConfig}
                  onImportConfig={importFullConfig}
                  onRestoreBackup={restoreBackupConfig}
                  onResetAll={resetAllConfig}
                  onToast={pushToast}
                />
              )}

              {activeTab === 'hud' && (
                <HudEditorPanel
                  config={config}
                  setConfig={setConfig}
                  world={world}
                  setWorld={setWorld}
                  musicState={musicState}
                  onUpdateElement={updateHudElement}
                  onResetAll={resetAllHudElements}
                  onMouseAction={recordMouseClick}
                  onToast={pushToast}
                />
              )}

              {activeTab === 'wardrobe' && (
                <StylesWardrobe
                  config={config}
                  setConfig={setConfig}
                  onEquip={equipCosmetic}
                  onToast={pushToast}
                />
              )}

              {activeTab === 'delivery' && <FabricDeliveryView config={config} onToast={pushToast} />}
            </main>
          </div>
        </div>
      )}

      {/* Animated Toast Notifications */}
      <div className="pointer-events-none fixed right-4 bottom-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            style={{ borderRadius: `${Math.max(8, config.theme.cornerRadius - 2)}px` }}
            className={`mc-animate-in pointer-events-auto max-w-xs border px-3.5 py-2.5 text-xs shadow-2xl backdrop-blur-xl ${
              t.tone === 'error'
                ? 'border-rose-400/40 bg-rose-950/90 text-rose-100'
                : t.tone === 'warning'
                ? 'border-amber-400/40 bg-amber-950/90 text-amber-100'
                : t.tone === 'success'
                ? 'border-emerald-400/40 bg-emerald-950/90 text-emerald-100'
                : 'border-white/20 bg-slate-950/90 text-slate-100'
            }`}
          >
            <div className="font-semibold">{t.title}</div>
            {t.detail && <div className="mt-0.5 text-[11px] opacity-85">{t.detail}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
