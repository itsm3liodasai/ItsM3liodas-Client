import { decompressFrames, parseGIF, ParsedFrame } from 'gifuct-js';
import { CosmeticItem, SkinPresetId } from '../types/client';

/**
 * Generates an authentic Minecraft-style pixel-art skin texture set (head front/sides/top/back, torso, limb)
 * or reads from an uploaded 64x64 Minecraft skin PNG!
 */
export function buildMinecraftSkinCanvases(
  preset: SkinPresetId,
  accentColor: string,
  customSkinImg: HTMLImageElement | null
): {
  headFront: HTMLCanvasElement;
  headBack: HTMLCanvasElement;
  headSide: HTMLCanvasElement;
  headTop: HTMLCanvasElement;
  torsoFront: HTMLCanvasElement;
  torsoBack: HTMLCanvasElement;
  armTex: HTMLCanvasElement;
  legTex: HTMLCanvasElement;
} {
  const make = (w: number, h: number) => {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  };

  // If user uploaded a real 64x64 Minecraft skin PNG, crop standard vanilla UV regions!
  if (preset === 'custom' && customSkinImg && customSkinImg.width >= 64) {
    const crop = (sx: number, sy: number, sw: number, sh: number, ox?: number, oy?: number) => {
      const c = make(sw, sh);
      const ctx = c.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(customSkinImg, sx, sy, sw, sh, 0, 0, sw, sh);
      if (ox !== undefined && oy !== undefined) {
        ctx.drawImage(customSkinImg, ox, oy, sw, sh, 0, 0, sw, sh);
      }
      return c;
    };
    return {
      headFront: crop(8, 8, 8, 8, 40, 8),
      headBack: crop(24, 8, 8, 8, 56, 8),
      headSide: crop(0, 8, 8, 8, 32, 8),
      headTop: crop(8, 0, 8, 8, 40, 0),
      torsoFront: crop(20, 20, 8, 12, 20, 36),
      torsoBack: crop(32, 20, 8, 12, 32, 36),
      armTex: crop(44, 20, 4, 12, 44, 36),
      legTex: crop(4, 20, 4, 12, 4, 36),
    };
  }

  const palettes: Record<
    Exclude<SkinPresetId, 'custom'>,
    { skin: string; skinShade: string; hair: string; hairHi: string; eyes: string; jacket: string; jacketDark: string; trim: string; pants: string }
  > = {
    m3liodas: {
      skin: '#ECC1A1',
      skinShade: '#D49E7A',
      hair: '#171528',
      hairHi: '#2E294E',
      eyes: accentColor,
      jacket: '#1E2438',
      jacketDark: '#121624',
      trim: accentColor,
      pants: '#0E121D',
    },
    knight: {
      skin: '#E6B999',
      skinShade: '#C89270',
      hair: '#334155',
      hairHi: '#64748B',
      eyes: '#38BDF8',
      jacket: '#475569',
      jacketDark: '#334155',
      trim: '#FACC15',
      pants: '#1E293B',
    },
    blossom: {
      skin: '#F5D0BC',
      skinShade: '#DFAC92',
      hair: '#3B1D36',
      hairHi: '#F472B6',
      eyes: '#F472B6',
      jacket: '#FDF2F8',
      jacketDark: '#FBCFE8',
      trim: '#EC4899',
      pants: '#2D1A2B',
    },
    cyber: {
      skin: '#D6B098',
      skinShade: '#B6886E',
      hair: '#0F172A',
      hairHi: '#22D3EE',
      eyes: '#22D3EE',
      jacket: '#0F172A',
      jacketDark: '#020617',
      trim: '#06B6D4',
      pants: '#090D16',
    },
  };

  const pal = palettes[preset === 'custom' ? 'm3liodas' : preset];

  // Head Front (8x8)
  const headFront = make(8, 8);
  const hfc = headFront.getContext('2d')!;
  hfc.fillStyle = pal.skin;
  hfc.fillRect(0, 0, 8, 8);
  hfc.fillStyle = pal.skinShade;
  hfc.fillRect(0, 7, 8, 1);
  hfc.fillRect(0, 3, 1, 4);
  hfc.fillRect(7, 3, 1, 4);
  // Hair bangs
  hfc.fillStyle = pal.hair;
  hfc.fillRect(0, 0, 8, 3);
  hfc.fillRect(0, 3, 1, 2);
  hfc.fillRect(7, 3, 1, 2);
  hfc.fillStyle = pal.hairHi;
  hfc.fillRect(1, 1, 2, 1);
  hfc.fillRect(5, 1, 2, 1);
  // Crisp 2x1 Minecraft Eyes
  hfc.fillStyle = '#FFFFFF';
  hfc.fillRect(1, 4, 2, 1);
  hfc.fillRect(5, 4, 2, 1);
  hfc.fillStyle = pal.eyes;
  hfc.fillRect(2, 4, 1, 1);
  hfc.fillRect(5, 4, 1, 1);
  // Mouth
  hfc.fillStyle = '#B87860';
  hfc.fillRect(3, 6, 2, 1);

  const headBack = make(8, 8);
  const hbc = headBack.getContext('2d')!;
  hbc.fillStyle = pal.hair;
  hbc.fillRect(0, 0, 8, 7);
  hbc.fillStyle = pal.hairHi;
  hbc.fillRect(2, 2, 4, 1);
  hbc.fillStyle = pal.skinShade;
  hbc.fillRect(0, 7, 8, 1);

  const headSide = make(8, 8);
  const hsc = headSide.getContext('2d')!;
  hsc.fillStyle = pal.skin;
  hsc.fillRect(0, 0, 8, 8);
  hsc.fillStyle = pal.hair;
  hsc.fillRect(0, 0, 8, 3);
  hsc.fillRect(0, 3, 5, 3);
  hsc.fillRect(0, 6, 3, 1);

  const headTop = make(8, 8);
  const htc = headTop.getContext('2d')!;
  htc.fillStyle = pal.hair;
  htc.fillRect(0, 0, 8, 8);
  htc.fillStyle = pal.hairHi;
  htc.fillRect(2, 2, 4, 4);

  // Torso Front (8x12)
  const torsoFront = make(8, 12);
  const tfc = torsoFront.getContext('2d')!;
  tfc.fillStyle = pal.jacket;
  tfc.fillRect(0, 0, 8, 12);
  tfc.fillStyle = pal.jacketDark;
  tfc.fillRect(0, 0, 1, 12);
  tfc.fillRect(7, 0, 1, 12);
  tfc.fillRect(0, 10, 8, 2);
  // Collar & Trim
  tfc.fillStyle = pal.trim;
  tfc.fillRect(3, 1, 2, 9);
  tfc.fillRect(1, 10, 6, 1);
  tfc.fillStyle = pal.skin;
  tfc.fillRect(3, 0, 2, 1);

  const torsoBack = make(8, 12);
  const tbc = torsoBack.getContext('2d')!;
  tbc.fillStyle = pal.jacket;
  tbc.fillRect(0, 0, 8, 12);
  tbc.fillStyle = pal.jacketDark;
  tbc.fillRect(0, 10, 8, 2);
  tbc.fillStyle = pal.trim;
  tbc.fillRect(2, 2, 4, 4);

  // Arm (4x12)
  const armTex = make(4, 12);
  const ac = armTex.getContext('2d')!;
  ac.fillStyle = pal.jacket;
  ac.fillRect(0, 0, 4, 9);
  ac.fillStyle = pal.trim;
  ac.fillRect(0, 8, 4, 1);
  ac.fillStyle = pal.skin;
  ac.fillRect(0, 9, 4, 3);

  // Leg (4x12)
  const legTex = make(4, 12);
  const lc = legTex.getContext('2d')!;
  lc.fillStyle = pal.pants;
  lc.fillRect(0, 0, 4, 10);
  lc.fillStyle = pal.jacketDark;
  lc.fillRect(0, 9, 4, 3);
  lc.fillStyle = pal.trim;
  lc.fillRect(0, 11, 4, 1);

  return { headFront, headBack, headSide, headTop, torsoFront, torsoBack, armTex, legTex };
}

/**
 * Generates crisp pixel-cutout Minecraft wing sprites (left/right symmetric) with real feathers,
 * dragon membrane ribs, butterfly stained-glass cells, or mechanical plasma thruster blades!
 */
export function buildWingSpriteCanvas(
  wing: CosmeticItem,
  primary: string,
  secondary: string
): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = 48;
  c.height = 48;
  const ctx = c.getContext('2d')!;
  ctx.clearRect(0, 0, 48, 48);

  const v = wing.shapeVariant;

  if (v === 2 || v === 4 || v === 13) {
    // Butterfly / Crystal Fairy / Lunar Moth stained-glass veined lobes
    ctx.fillStyle = primary;
    ctx.beginPath();
    ctx.moveTo(2, 20);
    ctx.bezierCurveTo(10, 4, 38, 2, 45, 14);
    ctx.bezierCurveTo(46, 22, 34, 27, 2, 24);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = secondary;
    ctx.beginPath();
    ctx.moveTo(2, 25);
    ctx.bezierCurveTo(16, 23, 36, 28, v === 13 ? 38 : 32, v === 13 ? 46 : 41);
    ctx.bezierCurveTo(22, 44, 10, 38, 2, 29);
    ctx.closePath();
    ctx.fill();

    // Dark stained-glass veins & glowing spots
    ctx.strokeStyle = 'rgba(10, 12, 22, 0.72)';
    ctx.lineWidth = 2;
    ctx.strokeRect(1, 1, 0, 0);
    ctx.beginPath();
    ctx.moveTo(3, 21);
    ctx.lineTo(39, 12);
    ctx.moveTo(4, 23);
    ctx.lineTo(33, 20);
    ctx.moveTo(4, 27);
    ctx.lineTo(28, 36);
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.globalAlpha = 0.65;
    ctx.fillRect(32, 11, 5, 4);
    ctx.fillRect(24, 32, 4, 4);
    ctx.globalAlpha = 1;
  } else if (v === 1 || v === 6 || v === 21) {
    // Dragon Membrane / Bat / Bone-Wing with skeletal ribs & scalloped lower edge
    ctx.fillStyle = primary;
    ctx.beginPath();
    ctx.moveTo(2, 20);
    ctx.lineTo(22, 7);
    ctx.lineTo(44, 12);
    ctx.lineTo(38, 28);
    ctx.quadraticCurveTo(30, 22, 25, 34);
    ctx.quadraticCurveTo(16, 26, 10, 36);
    ctx.lineTo(2, 26);
    ctx.closePath();
    ctx.fill();

    // Glowing inner energy veins & bone struts
    ctx.strokeStyle = secondary;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(2, 21);
    ctx.lineTo(22, 8);
    ctx.lineTo(44, 12);
    ctx.moveTo(22, 8);
    ctx.lineTo(38, 28);
    ctx.moveTo(15, 13);
    ctx.lineTo(25, 34);
    ctx.moveTo(9, 17);
    ctx.lineTo(10, 36);
    ctx.stroke();

    // Wingtip claw spike
    ctx.fillStyle = secondary;
    ctx.fillRect(20, 4, 4, 5);
  } else if (v === 3 || v === 14 || v === 15 || v === 19) {
    // Cyber Mech / Holo-Grid / Storm Lightning / Valkyrie Blade-Wings
    for (let b = 0; b < 4; b++) {
      const y = 7 + b * 9;
      const len = 43 - b * 5;
      ctx.fillStyle = b % 2 === 0 ? primary : secondary;
      ctx.beginPath();
      ctx.moveTo(2, y + 3);
      ctx.lineTo(len, y);
      ctx.lineTo(len - 5, y + 6);
      ctx.lineTo(2, y + 7);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = 'rgba(255,255,255,0.45)';
      ctx.fillRect(6, y + 2, len - 14, 1.5);
    }
  } else {
    // Layered Realistic Pixel-Art Feathered Wing (Seraph, Phoenix, Sakura, Fallen Ash, Peacock)
    // Top covert shoulder arc
    ctx.fillStyle = primary;
    ctx.beginPath();
    ctx.moveTo(2, 21);
    ctx.quadraticCurveTo(18, 6, 44, 11);
    ctx.lineTo(38, 24);
    ctx.lineTo(2, 26);
    ctx.closePath();
    ctx.fill();

    // Individual cascading long flight feathers
    for (let i = 0; i < 6; i++) {
      const fx = 6 + i * 6.5;
      const fy = 15 + i * 1.4;
      const fLen = 24 - i * 1.6;
      ctx.fillStyle = i >= 4 ? secondary : primary;
      ctx.beginPath();
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx + 5.5, fy + 1);
      ctx.lineTo(fx + 3, fy + fLen);
      ctx.lineTo(fx - 1, fy + fLen - 2);
      ctx.closePath();
      ctx.fill();

      // Feather shaft & highlight
      ctx.fillStyle = 'rgba(255,255,255,0.28)';
      ctx.fillRect(fx + 1.5, fy + 2, 1.2, fLen - 5);
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.fillRect(fx + 4.5, fy + 2, 1, fLen - 4);
    }

    // Glowing tip highlight
    ctx.fillStyle = secondary;
    ctx.fillRect(36, 10, 7, 4);
  }

  return c;
}

/**
 * Draws a crisp 44x34 animated procedural cape onto an offscreen canvas for any catalog cape OR custom pixel grid!
 */
export function drawAnimatedCapeFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  t: number,
  variant: number,
  primary: string,
  secondary: string,
  customPixelGrid?: string[]
) {
  ctx.clearRect(0, 0, width, height);

  if (customPixelGrid && customPixelGrid.length === 11 * 17) {
    const cw = width / 11;
    const ch = height / 17;
    for (let r = 0; r < 17; r++) {
      for (let col = 0; col < 11; col++) {
        ctx.fillStyle = customPixelGrid[r * 11 + col] || '#1E1B4B';
        ctx.fillRect(Math.floor(col * cw), Math.floor(r * ch), Math.ceil(cw), Math.ceil(ch));
      }
    }
    return;
  }

  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, primary);
  grad.addColorStop(1, secondary);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Border frame
  ctx.strokeStyle = secondary;
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, width - 2, height - 2);

  if (variant === 0 || variant === 10 || variant === 13) {
    // Parallax starfield nebula cape
    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 16; i++) {
      const sx = (i * 17) % (width - 4);
      const sy = ((i * 23 + Math.round(t * 9)) % (height - 4));
      ctx.fillRect(sx + 2, sy + 2, i % 3 === 0 ? 2 : 1, i % 3 === 0 ? 2 : 1);
    }
    // Central glowing crescent / M emblem
    ctx.fillStyle = secondary;
    ctx.fillRect(width / 2 - 5, height / 2 - 5, 10, 10);
    ctx.fillStyle = primary;
    ctx.fillRect(width / 2 - 2, height / 2 - 3, 5, 6);
  } else if (variant === 2 || variant === 15) {
    // Blossom falling petals cape
    ctx.fillStyle = '#FFF1F2';
    for (let i = 0; i < 12; i++) {
      const px = ((i * 9 + Math.round(Math.sin(t + i) * 3)) % (width - 4)) + 2;
      const py = ((i * 11 + Math.round(t * 10)) % (height - 4)) + 2;
      ctx.fillRect(px, py, 2, 2);
    }
  } else if (variant === 9 || variant === 16) {
    // Cyber Matrix / Storm Arc vertical energy pulse
    ctx.fillStyle = secondary;
    for (let col = 4; col < width - 4; col += 6) {
      const yOff = ((Math.round(t * 24) + col * 5) % (height + 10)) - 10;
      ctx.fillRect(col, yOff, 2, 9);
    }
  } else {
    // Royal crest chevron
    ctx.fillStyle = secondary;
    ctx.beginPath();
    ctx.moveTo(width / 2, 8);
    ctx.lineTo(width - 8, height / 2);
    ctx.lineTo(width / 2, height - 8);
    ctx.lineTo(8, height / 2);
    ctx.closePath();
    ctx.fill();
  }
}

export interface DecodedGifData {
  width: number;
  height: number;
  frames: { imageData: ImageData; delayMs: number }[];
}

/**
 * Decodes any animated GIF file into playable ImageData frames using gifuct-js!
 */
export async function decodeAnimatedGifFile(file: File): Promise<DecodedGifData | null> {
  try {
    const buffer = await file.arrayBuffer();
    const gif = parseGIF(buffer);
    const frames: ParsedFrame[] = decompressFrames(gif, true);
    if (!frames || frames.length === 0) return null;

    const width = gif.lsd.width;
    const height = gif.lsd.height;
    const compCanvas = document.createElement('canvas');
    compCanvas.width = width;
    compCanvas.height = height;
    const compCtx = compCanvas.getContext('2d')!;

    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d')!;

    const outFrames: { imageData: ImageData; delayMs: number }[] = [];

    for (const frame of frames) {
      const { dims, patch, delay, disposalType } = frame;
      const savedBefore = disposalType === 3 ? compCtx.getImageData(0, 0, width, height) : null;

      tempCanvas.width = dims.width;
      tempCanvas.height = dims.height;
      const patchImg = tempCtx.createImageData(dims.width, dims.height);
      patchImg.data.set(patch);
      tempCtx.putImageData(patchImg, 0, 0);

      compCtx.drawImage(tempCanvas, dims.left, dims.top);
      outFrames.push({
        imageData: compCtx.getImageData(0, 0, width, height),
        delayMs: Math.max(25, (delay || 8) * 10),
      });

      if (disposalType === 2) {
        compCtx.clearRect(dims.left, dims.top, dims.width, dims.height);
      } else if (disposalType === 3 && savedBefore) {
        compCtx.putImageData(savedBefore, 0, 0);
      }
    }

    return { width, height, frames: outFrames };
  } catch {
    return null;
  }
}

/**
 * Creates a crisp 11x17 default custom pixel cape grid with a clean gradient & center diamond crest.
 */
export function createDefaultPixelCapeGrid(primary = '#7C5CFF', secondary = '#38BDF8'): string[] {
  const grid: string[] = [];
  for (let r = 0; r < 17; r++) {
    for (let c = 0; c < 11; c++) {
      if (r === 0 || r === 16 || c === 0 || c === 10) {
        grid.push(secondary);
      } else if (Math.abs(r - 8) + Math.abs(c - 5) <= 2) {
        grid.push('#F8FAFC');
      } else if (Math.abs(r - 8) + Math.abs(c - 5) === 3) {
        grid.push(secondary);
      } else {
        grid.push(r < 8 ? '#1E1B4B' : primary);
      }
    }
  }
  return grid;
}
