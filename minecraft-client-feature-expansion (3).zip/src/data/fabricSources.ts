import gradleProperties from '../../fabric-project/gradle.properties?raw';
import settingsGradle from '../../fabric-project/settings.gradle?raw';
import buildGradle from '../../fabric-project/build.gradle?raw';
import workflowYml from '../../fabric-project/.github/workflows/build.yml?raw';
import licenseTxt from '../../fabric-project/LICENSE?raw';
import readmeMd from '../../fabric-project/README.md?raw';
import fabricModJson from '../../fabric-project/src/main/resources/fabric.mod.json?raw';
import mixinsJson from '../../fabric-project/src/main/resources/itsm3liodas.mixins.json?raw';
import clientEntryJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/ItsM3liodasClient.java?raw';
import clientConfigJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/config/ClientConfig.java?raw';
import hudManagerJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/hud/HudManager.java?raw';
import clientModulesJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/module/ClientModules.java?raw';
import clientCosmeticsJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/cosmetic/ClientCosmetics.java?raw';
import clientMenuScreenJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/gui/ClientMenuScreen.java?raw';
import cameraMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/CameraMixin.java?raw';
import gameRendererMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/GameRendererMixin.java?raw';
import inGameHudMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/InGameHudMixin.java?raw';
import worldRendererMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/WorldRendererMixin.java?raw';
import heldItemRendererMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/HeldItemRendererMixin.java?raw';
import itemEntityRendererMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/ItemEntityRendererMixin.java?raw';
import playerRendererMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/PlayerEntityRendererMixin.java?raw';
import screenBlurMixinJava from '../../fabric-project/src/client/java/com/itsm3liodas/client/mixin/ScreenBlurMixin.java?raw';
import clientConfigTestJava from '../../fabric-project/src/test/java/com/itsm3liodas/client/ClientConfigTest.java?raw';

export interface FabricProjectFile {
  path: string;
  language: 'java' | 'groovy' | 'json' | 'yaml' | 'markdown' | 'properties' | 'text';
  content: string;
}

export const FABRIC_PROJECT_FILES: FabricProjectFile[] = [
  { path: 'gradle.properties', language: 'properties', content: gradleProperties },
  { path: 'settings.gradle', language: 'groovy', content: settingsGradle },
  { path: 'build.gradle', language: 'groovy', content: buildGradle },
  { path: '.github/workflows/build.yml', language: 'yaml', content: workflowYml },
  { path: 'README.md', language: 'markdown', content: readmeMd },
  { path: 'LICENSE', language: 'text', content: licenseTxt },
  { path: 'src/main/resources/fabric.mod.json', language: 'json', content: fabricModJson },
  { path: 'src/main/resources/itsm3liodas.mixins.json', language: 'json', content: mixinsJson },
  { path: 'src/client/java/com/itsm3liodas/client/ItsM3liodasClient.java', language: 'java', content: clientEntryJava },
  { path: 'src/client/java/com/itsm3liodas/client/config/ClientConfig.java', language: 'java', content: clientConfigJava },
  { path: 'src/client/java/com/itsm3liodas/client/hud/HudManager.java', language: 'java', content: hudManagerJava },
  { path: 'src/client/java/com/itsm3liodas/client/module/ClientModules.java', language: 'java', content: clientModulesJava },
  { path: 'src/client/java/com/itsm3liodas/client/cosmetic/ClientCosmetics.java', language: 'java', content: clientCosmeticsJava },
  { path: 'src/client/java/com/itsm3liodas/client/gui/ClientMenuScreen.java', language: 'java', content: clientMenuScreenJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/CameraMixin.java', language: 'java', content: cameraMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/GameRendererMixin.java', language: 'java', content: gameRendererMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/InGameHudMixin.java', language: 'java', content: inGameHudMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/WorldRendererMixin.java', language: 'java', content: worldRendererMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/HeldItemRendererMixin.java', language: 'java', content: heldItemRendererMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/ItemEntityRendererMixin.java', language: 'java', content: itemEntityRendererMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/PlayerEntityRendererMixin.java', language: 'java', content: playerRendererMixinJava },
  { path: 'src/client/java/com/itsm3liodas/client/mixin/ScreenBlurMixin.java', language: 'java', content: screenBlurMixinJava },
  { path: 'src/test/java/com/itsm3liodas/client/ClientConfigTest.java', language: 'java', content: clientConfigTestJava },
];
