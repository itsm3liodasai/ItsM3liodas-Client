import { FontFamilyId } from '../types/client';

export const FONT_OPTIONS: { id: FontFamilyId; label: string; css: string }[] = [
  { id: 'inter', label: 'Inter (Clean UI)', css: "'Inter', system-ui, sans-serif" },
  { id: 'space', label: 'Space Grotesk (Modern)', css: "'Space Grotesk', system-ui, sans-serif" },
  { id: 'outfit', label: 'Outfit (Rounded Bold)', css: "'Outfit', system-ui, sans-serif" },
  { id: 'minecraft', label: 'Minecraft Pixel (Blocky)', css: "'Press Start 2P', monospace" },
  { id: 'pixel', label: 'Silkscreen (Crisp Pixel)', css: "'Silkscreen', monospace" },
  { id: 'display', label: 'Bebas Neue (Tall Cinema)', css: "'Bebas Neue', sans-serif" },
  { id: 'serif', label: 'Cinzel (Mythic Serif)', css: "'Cinzel', serif" },
  { id: 'mono', label: 'JetBrains Mono (Code)', css: "'JetBrains Mono', monospace" },
];

export const FONT_CSS_MAP: Record<FontFamilyId, string> = FONT_OPTIONS.reduce(
  (acc, cur) => {
    acc[cur.id] = cur.css;
    return acc;
  },
  {} as Record<FontFamilyId, string>
);
