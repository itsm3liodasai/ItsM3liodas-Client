# ItsM3liodas Client (Minecraft 1.21.11 / Fabric)

**ItsM3liodas Client** is a client-side visual customization, HUD, camera utility, music lyrics HUD, and 3D cosmetic mod for **Minecraft Java Edition 1.21.11** built on **Fabric Loader** and **Java 21**.

## Scope & Fair-Play Guarantees
- **Strictly Client-Side Visual & QoL:** No combat automation, aim assist, X-ray, hidden-player ESP, reach modification, or artificial rotation/movement packets.
- **No In-Game Web Browser:** No embedded browser or web tabs are included.
- **Safe Pack Handling:** Visual packs and ItsM3liodas Style packs are validated JSON/asset bundles only; executable scripts or code payloads are rejected.

## Target Environment
- **Minecraft:** 1.21.11
- **Java:** 21
- **Fabric Loader:** >= 0.18.1 (built against `0.18.4`)
- **Fabric API:** >= 0.139.3+1.21.11 (built against `0.141.4+1.21.11`)
- **Fabric Loom:** `1.14.10`
- **Mappings:** Yarn `1.21.11+build.6` (Note: Fabric will discontinue Yarn after 1.21.11 in favor of Mojang Mappings for 26.1+)

## Build Instructions (Local or GitHub Actions)
> **Honest Build Notice:** This repository was prepared in a web sandbox where JDK 21 and Gradle are not present. Compilation and runtime verification must be completed via GitHub Actions or a local Java 21 + Gradle installation.

1. Ensure **Java 21** and **Gradle 8.10+** (or Gradle Wrapper `./gradlew`) are installed.
2. Run:
   ```bash
   gradle build test
   ```
   (or `./gradlew build test` if using the Gradle wrapper).
3. Compiled JAR artifacts are emitted to `build/libs/itsm3liodas-client-2.5.0+1.21.11.jar`.
4. Place the compiled JAR alongside `fabric-api-0.141.4+1.21.11.jar` inside `.minecraft/mods/`.

## Included Modules
- **Preserved & Enhanced HUD:** FPS, Ping, Coordinates, Direction, Local Clock, **Uku-Style Armor Icons & Durability Warning HUD**, Held Item, Biome, Potion Effects, Server Address, Keystrokes, plus **Valence-Inspired Music & Synced Sky Lyrics HUD**.
- **Visual & Camera Modules:** Motion Blur, Menu Blur, Custom Nametags, Custom Crosshair, Custom Block Outlines, Item Physics, Color Grading & Presets, Visual Packs Manager, Hand Aura / Hand Glow, Zoom, Free Look, Shulker Preview, Viewmodel Editor, **ItsM3liodas Styles (168 free cosmetics including 24 articulated animated wings)**, Particle Effects, Advanced HUD Editor, 9+ Themes & Animations, Custom Keybinds with conflict detection, Performance Optimizations.
