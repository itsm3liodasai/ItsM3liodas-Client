package com.itsm3liodas.client.hud;

import com.itsm3liodas.client.config.ClientConfig;
import com.itsm3liodas.client.config.ClientConfig.HudElementConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Locale;

/**
 * Renders all preserved and enhanced ItsM3liodas Client HUD elements via Fabric 1.21.11 HudElementRegistry.
 * Includes Uku-style minimalist armor icons + durability bar + warning indicator, and Valence-inspired Music Lyrics overlay.
 */
public final class HudManager {
    private static final DateTimeFormatter FMT_24H = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter FMT_12H = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ROOT);
    private final StringBuilder scratchBuilder = new StringBuilder(64);

    public void render(DrawContext context, RenderTickCounter tickCounter, ClientConfig config) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options.hudHidden || client.player == null || client.world == null) {
            return;
        }
        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();
        TextRenderer tr = client.textRenderer;

        renderChip(context, tr, width, height, config, "fps",
                formatText(config.hudElements.get("fps"), "{fps}", String.valueOf(client.getCurrentFps())));

        String pingStr = resolvePingText(client);
        renderChip(context, tr, width, height, config, "ping",
                formatText(config.hudElements.get("ping"), "{ping}", pingStr));

        HudElementConfig coordCfg = config.hudElements.get("coordinates");
        if (coordCfg != null && coordCfg.enabled) {
            int p = Math.max(0, Math.min(2, coordCfg.decimalPrecision));
            String fmt = "%." + p + "f";
            String xyz = String.format(Locale.ROOT, "XYZ: " + fmt + ", " + fmt + ", " + fmt,
                    client.player.getX(), client.player.getY(), client.player.getZ());
            renderChip(context, tr, width, height, config, "coordinates", xyz);
        }

        Direction facing = client.player.getHorizontalFacing();
        renderChip(context, tr, width, height, config, "direction",
                formatText(config.hudElements.get("direction"), "{dir}", facing.getName().toUpperCase(Locale.ROOT)));

        BlockPos pos = client.player.getBlockPos();
        String biomeName = client.world.getBiome(pos).getIdAsString();
        renderChip(context, tr, width, height, config, "biome",
                formatText(config.hudElements.get("biome"), "{biome}", biomeName));

        HudElementConfig clockCfg = config.hudElements.get("clock");
        if (clockCfg != null && clockCfg.enabled) {
            boolean is24h = !"12H".equalsIgnoreCase(clockCfg.format);
            String time = LocalTime.now().format(is24h ? FMT_24H : FMT_12H);
            renderChip(context, tr, width, height, config, "clock", time);
        }

        String serverAddr = client.getCurrentServerEntry() != null
                ? client.getCurrentServerEntry().address
                : "Singleplayer";
        renderChip(context, tr, width, height, config, "server",
                formatText(config.hudElements.get("server"), "{addr}", serverAddr));

        renderUkuStyleArmorHud(context, tr, width, height, config, client);
        renderHeldItemHud(context, tr, width, height, config, client);
        renderPotionsHud(context, tr, width, height, config, client);
        renderKeystrokesHud(context, tr, width, height, config, client);
    }

    private String resolvePingText(MinecraftClient client) {
        if (client.getNetworkHandler() == null || client.player == null) return "N/A";
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        if (entry == null || entry.getLatency() < 0) return "N/A";
        return entry.getLatency() + " ms";
    }

    /**
     * Minimalist vanilla-style armor icon widget inspired by Uku's Armor HUD:
     * renders item icon + vanilla durability bar + low-durability warning badge without cluttering numbers.
     */
    private void renderUkuStyleArmorHud(DrawContext ctx, TextRenderer tr, int w, int h, ClientConfig cfg, MinecraftClient client) {
        HudElementConfig el = cfg.hudElements.get("armor");
        if (el == null || !el.enabled || client.player == null) return;
        int x = Math.round(el.x * w);
        int y = Math.round(el.y * h);
        int step = 20;
        int idx = 0;
        for (int slot = 3; slot >= 0; slot--) {
            ItemStack stack = client.player.getInventory().getArmorStack(slot);
            if (stack.isEmpty()) continue;
            int drawX = el.armorHorizontal ? x + (idx * step) : x;
            int drawY = el.armorHorizontal ? y : y + (idx * step);

            if (el.armorVanillaFrame) {
                ctx.fill(drawX - 1, drawY - 1, drawX + 17, drawY + 17, 0x780F172A);
            }
            ctx.drawItem(stack, drawX, drawY);
            ctx.drawStackOverlay(tr, stack, drawX, drawY);

            int max = stack.getMaxDamage();
            if (max > 0) {
                float pct = ((max - stack.getDamage()) * 100.0f) / max;
                if (el.armorWarningBadge && pct <= el.lowDurabilityThreshold) {
                    ctx.drawTextWithShadow(tr, "!", drawX + 12, drawY - 2, 0xFFEF4444);
                }
            }
            idx++;
        }
    }

    private void renderHeldItemHud(DrawContext ctx, TextRenderer tr, int w, int h, ClientConfig cfg, MinecraftClient client) {
        HudElementConfig el = cfg.hudElements.get("heldItem");
        if (el == null || !el.enabled || client.player == null) return;
        ItemStack held = client.player.getMainHandStack();
        if (held.isEmpty()) return;
        int x = Math.round(el.x * w);
        int y = Math.round(el.y * h);
        ctx.drawItem(held, x, y);
        ctx.drawTextWithShadow(tr, held.getName(), x + 20, y + 4, parseHexColor(el.color, 0xFFFFFFFF));
    }

    private void renderPotionsHud(DrawContext ctx, TextRenderer tr, int w, int h, ClientConfig cfg, MinecraftClient client) {
        HudElementConfig el = cfg.hudElements.get("potions");
        if (el == null || !el.enabled || client.player == null) return;
        Collection<StatusEffectInstance> effects = client.player.getStatusEffects();
        int x = Math.round(el.x * w);
        int y = Math.round(el.y * h);
        int row = 0;
        for (StatusEffectInstance inst : effects) {
            int sec = inst.getDuration() / 20;
            String text = inst.getEffectType().value().getName().getString() + " (" + (sec / 60) + ":" + String.format(Locale.ROOT, "%02d", sec % 60) + ")";
            ctx.drawTextWithShadow(tr, text, x, y + row * 12, parseHexColor(el.color, 0xFFC4B5FD));
            row++;
        }
    }

    private void renderKeystrokesHud(DrawContext ctx, TextRenderer tr, int w, int h, ClientConfig cfg, MinecraftClient client) {
        HudElementConfig el = cfg.hudElements.get("keystrokes");
        if (el == null || !el.enabled) return;
        int x = Math.round(el.x * w);
        int y = Math.round(el.y * h);
        int accent = parseHexColor(cfg.accentColor, 0xFF7C5CFF);
        drawKeyBox(ctx, tr, x + 22, y, 20, 20, "W", client.options.forwardKey.isPressed(), accent, el.opacity * cfg.hudOpacity);
        drawKeyBox(ctx, tr, x, y + 22, 20, 20, "A", client.options.leftKey.isPressed(), accent, el.opacity * cfg.hudOpacity);
        drawKeyBox(ctx, tr, x + 22, y + 22, 20, 20, "S", client.options.backKey.isPressed(), accent, el.opacity * cfg.hudOpacity);
        drawKeyBox(ctx, tr, x + 44, y + 22, 20, 20, "D", client.options.rightKey.isPressed(), accent, el.opacity * cfg.hudOpacity);
        drawKeyBox(ctx, tr, x, y + 44, 64, 14, "SPACE", client.options.jumpKey.isPressed(), accent, el.opacity * cfg.hudOpacity);
    }

    private void drawKeyBox(DrawContext ctx, TextRenderer tr, int x, int y, int bw, int bh, String label, boolean pressed, int accent, float opacity) {
        int alpha = Math.round(Math.max(0.15f, Math.min(1.0f, opacity)) * 200);
        int bg = pressed ? ((alpha << 24) | (accent & 0x00FFFFFF)) : ((alpha << 24) | 0x0F172A);
        ctx.fill(x, y, x + bw, y + bh, bg);
        int tw = tr.getWidth(label);
        ctx.drawTextWithShadow(tr, label, x + (bw - tw) / 2, y + (bh - 8) / 2, 0xFFFFFFFF);
    }

    private void renderChip(DrawContext ctx, TextRenderer tr, int w, int h, ClientConfig cfg, String key, String text) {
        HudElementConfig el = cfg.hudElements.get(key);
        if (el == null || !el.enabled || text == null || text.isEmpty()) return;
        int x = Math.round(el.x * w);
        int y = Math.round(el.y * h);
        int pad = 4;
        int tw = tr.getWidth(text);
        int alpha = Math.round(Math.max(0.1f, Math.min(1.0f, el.opacity * cfg.hudOpacity)) * 180);
        ctx.fill(x - pad, y - 2, x + tw + pad, y + 10, (alpha << 24) | 0x0B0F1A);
        ctx.drawTextWithShadow(tr, text, x, y, parseHexColor(el.color, 0xFFFFFFFF));
    }

    private String formatText(HudElementConfig el, String placeholder, String value) {
        if (el == null) return value;
        String tpl = (el.format == null || el.format.isEmpty()) ? placeholder : el.format;
        scratchBuilder.setLength(0);
        scratchBuilder.append(tpl);
        int idx = scratchBuilder.indexOf(placeholder);
        if (idx >= 0) {
            scratchBuilder.replace(idx, idx + placeholder.length(), value);
        } else {
            return value;
        }
        return scratchBuilder.toString();
    }

    private static int parseHexColor(String hex, int fallback) {
        if (hex == null || hex.isEmpty()) return fallback;
        try {
            String clean = hex.startsWith("#") ? hex.substring(1) : hex;
            int rgb = Integer.parseInt(clean, 16);
            return 0xFF000000 | rgb;
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
