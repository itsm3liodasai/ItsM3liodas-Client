package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies first-person Viewmodel offsets/scale/rotation while preserving vanilla item animations.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void itsm3liodas$applyViewmodelTransform(
            AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
            float swingProgress, ItemStack item, float equipProgress,
            MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.viewmodel.enabled) return;

        float sign = (hand == Hand.OFF_HAND && cfg.viewmodel.mirrorLeftHand) ? -1.0f : 1.0f;
        matrices.translate(cfg.viewmodel.itemX * sign, cfg.viewmodel.itemY, cfg.viewmodel.itemZ);
        matrices.scale(cfg.viewmodel.scale, cfg.viewmodel.scale, cfg.viewmodel.scale);
        if (cfg.viewmodel.rotX != 0.0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cfg.viewmodel.rotX));
        if (cfg.viewmodel.rotY != 0.0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(cfg.viewmodel.rotY * sign));
        if (cfg.viewmodel.rotZ != 0.0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(cfg.viewmodel.rotZ * sign));
    }
}
