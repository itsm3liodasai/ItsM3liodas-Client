package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * Customizes the RGBA color of the standard block-selection outline without altering visibility rules.
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @ModifyArgs(
        method = "drawBlockOutline",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexRendering;drawOutline(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;Lnet/minecraft/util/shape/VoxelShape;DDDI)V"),
        require = 0
    )
    private void itsm3liodas$recolorBlockOutline(Args args) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.blockOutline.enabled) return;
        int alpha = Math.round(cfg.blockOutline.opacity * 255.0f);
        int rgb = 0x7C5CFF;
        try {
            String hex = cfg.blockOutline.color.startsWith("#") ? cfg.blockOutline.color.substring(1) : cfg.blockOutline.color;
            rgb = Integer.parseInt(hex, 16) & 0x00FFFFFF;
        } catch (Exception ignored) {}
        int lastIdx = args.size() - 1;
        args.set(lastIdx, (alpha << 24) | rgb);
    }
}
