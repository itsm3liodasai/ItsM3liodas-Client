package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import com.itsm3liodas.client.module.ClientModules;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies client-only Freelook camera rotation without altering player entity yaw/pitch
 * or sending artificial rotation packets to the server.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow public abstract float getYaw();
    @Shadow public abstract float getPitch();

    @Inject(method = "update", at = @At("TAIL"))
    private void itsm3liodas$applyFreelookOffset(BlockView area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        ClientModules modules = ItsM3liodasClient.getModules();
        if (cfg == null || !cfg.freelook.enabled || !modules.hasActiveFreelookOffset()) {
            return;
        }
        if (thirdPerson && !cfg.freelook.allowThirdPerson) {
            return;
        }
        float yaw = this.getYaw() + modules.getFreelookYawOffset();
        float pitch = Math.max(-90.0f, Math.min(90.0f, this.getPitch() + modules.getFreelookPitchOffset()));
        this.setRotation(yaw, pitch);
    }
}
