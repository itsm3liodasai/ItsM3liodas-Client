package dev.itsm3liodas.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent client-side appearance and HUD settings. */
public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("itsm3liodas-client.json");
    private static Data data = new Data();

    private ClientConfig() {}
    public static Data get() { return data; }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Data loaded = GSON.fromJson(Files.readString(FILE), Data.class);
                if (loaded != null) data = loaded;
            }
        } catch (Exception exception) {
            System.err.println("[ItsM3liodas Client] Could not load settings: " + exception.getMessage());
            data = new Data();
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(data));
        } catch (IOException exception) {
            System.err.println("[ItsM3liodas Client] Could not save settings: " + exception.getMessage());
        }
    }

    public static void reset() { data = new Data(); save(); }

    public static final class Data {
        public String theme = "DARK";
        public int accent = 0x45B7FF;
        public float hudScale = 1.0f;
        public float hudOpacity = 0.90f;
        public boolean showFps = true;
        public boolean showPing = true;
        public boolean showCoordinates = true;
        public boolean showDirection = true;
        public boolean showClock = true;
        public boolean showArmor = true;
        public boolean showEffects = true;
        public boolean showArmorDurability = true;
        public boolean showHeldItem = true;
        public boolean showBiome = true;
        public boolean showStatusEffectNames = true;
        public boolean showWelcomeBrand = true;
        public boolean compactHud = false;
    }
}
