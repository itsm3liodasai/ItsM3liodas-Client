package dev.itsm3liodas.client.hud;

import dev.itsm3liodas.client.ItsM3liodasClient;
import dev.itsm3liodas.client.config.ClientConfig;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Read-only information HUD. It never automates or modifies gameplay. */
public final class HudOverlay {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private HudOverlay() {}

    public static void register() {
        HudElementRegistry.addLast(ItsM3liodasClient.id("information_hud"), HudOverlay::render);
    }

    private static void render(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        ClientConfig.Data cfg = ClientConfig.get();
        if (mc.player == null || mc.options.hideGui) return;

        List<String> lines = new ArrayList<>();
        if (cfg.showFps) lines.add("FPS  " + mc.getFps());
        if (cfg.showPing && mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) lines.add("PING  " + info.getLatency() + " ms");
        }
        if (cfg.showCoordinates) {
            lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (cfg.showDirection) lines.add("FACING  " + mc.player.getDirection().getName().toUpperCase(Locale.ROOT));
        if (cfg.showClock) lines.add("TIME  " + LocalTime.now().format(CLOCK));
        if (cfg.showArmor) {
            long count = 0;
            for (int slot = 0; slot < 4; slot++) {
                if (!mc.player.getInventory().getArmor(slot).isEmpty()) count++;
            }
            lines.add("ARMOR  " + count + "/4");
        }
        if (cfg.showEffects) lines.add("EFFECTS  " + mc.player.getActiveEffects().size());
        if (lines.isEmpty()) return;

        float scale = Math.max(0.75f, Math.min(1.5f, cfg.hudScale));
        int alpha = Math.max(0, Math.min(255, Math.round(cfg.hudOpacity * 255)));
        int bg = (alpha << 24) | 0x00101722;
        int accent = 0xFF000000 | (cfg.accent & 0xFFFFFF);
        int x = 8, y = 8;
        int rowHeight = cfg.compactHud ? 10 : 12;
        int width = 0;
        for (String line : lines) width = Math.max(width, mc.font.width(line));

        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        graphics.fill(x - 4, y - 4, x + width + 10, y + lines.size() * rowHeight + 4, bg);
        graphics.fill(x - 4, y - 4, x - 2, y + lines.size() * rowHeight + 4, accent);
        for (String line : lines) {
            graphics.drawString(mc.font, line, x + 1, y, 0xFFF2F5FA, true);
            y += rowHeight;
        }
        graphics.pose().popMatrix();
    }
}
