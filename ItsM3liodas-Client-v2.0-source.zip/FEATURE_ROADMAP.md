# ItsM3liodas Client — requested feature roadmap

Target: Fabric, Minecraft 1.21.11, Java 21.

This document records requested features. It is **not a claim that these features are implemented**. The source currently contains the initial HUD/settings implementation only; compile and test it before use.

## Music player request

Featured library/search entries:
- Misery
- Heat Waves
- Love Nwantiti

No copyrighted song audio or lyrics are bundled. A no-account player can only play audio the user is entitled to play locally or from a service that explicitly supports unauthenticated playback. Spotify playback cannot be made account-free through the official Spotify player. Future integration should support local files and permitted stream URLs, plus optional Spotify deep-links/system-media-session metadata where available. Do not scrape Spotify or bypass its login/DRM.

## Requested modules — not implemented yet

- Shulker preview
- HUD: FPS, ping, coordinates, direction, clock, keystrokes, server address, nametags, crosshair
- Visuals: motion blur, block outline, item physics, menu blur, hand aura/glow, hitbox display
- Camera: zoom and free look
- Viewmodel editor
- Color grading: saturation, hue, brightness, contrast, vibrance, temperature, gamma, sharpness
- Texture/style editor inspired by Bauloo Styles: custom item/block textures, categories, presets, import/export
- Optional in-game browser (requires an embedded browser engine and careful dependency/licensing review)
- Optional music UI and synchronized lyrics for content the user is authorized to play

## Safety and compatibility

Keep all modules client-side and cosmetic or informational. Do not add combat automation, movement automation, x-ray, ESP/tracking, packet manipulation, anti-cheat bypasses, or other unfair gameplay features. Respect server rules; hitbox visuals should be limited to ordinary debug-style outlines and must not become entity tracking or ESP.

## Build verification

No successful Gradle build is claimed for this package. Run the repository GitHub Actions workflow or `gradle --no-daemon --no-configuration-cache clean build` with JDK 21. Fix any compiler errors before installing the resulting JAR.
