# ItsM3liodas Client

A client-side Fabric mod source project targeting Minecraft Java Edition **1.21.11** and **Java 21**.

## Current source status

This package is the latest available GUI-overhaul source snapshot. It contains the initial configurable HUD and settings menu. It is **not** a complete implementation of every feature discussed in chat. See [FEATURE_ROADMAP.md](FEATURE_ROADMAP.md) for the full requested feature list and music integration limitations.

## Existing controls and features

- Right Shift opens the client settings menu.
- HUD elements include FPS, ping, coordinates, direction, local clock, armor count, active-effect count, armor durability, held item, biome and potion names, with available toggles in the source.
- Appearance settings include theme/accent options.
- Fabric client-side entrypoint; no server plugin required.

## Build

- Minecraft: 1.21.11
- Loader: Fabric
- Java: 21
- Run `gradle --no-daemon --no-configuration-cache clean build` from this project directory with Gradle 9.2.0 or a compatible wrapper installation.
- The output JAR should appear under `build/libs/` if compilation succeeds.

A successful build has **not** been verified for this ZIP. Do not treat ZIP integrity as proof of compilation or runtime compatibility.
