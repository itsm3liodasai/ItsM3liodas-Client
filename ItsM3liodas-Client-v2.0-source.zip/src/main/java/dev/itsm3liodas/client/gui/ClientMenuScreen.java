package dev.itsm3liodas.client.gui;

import dev.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.Util;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** A compact, client-side settings interface. */
public final class ClientMenuScreen extends Screen {
    private int page = 0;
    private static final int ACCENT_DEFAULT = 0x45B7FF;

    public ClientMenuScreen() { super(Component.literal("ItsM3liodas Client")); }

    @Override protected void init() { rebuild(); }

    private int panelLeft() { return width / 2 - 200; }
    private int panelTop() { return height / 2 - 145; }

    private void rebuild() {
        clearWidgets();
        int left = panelLeft();
        int top = panelTop();
        int navX = left + 14;
        int contentX = left + 126;
        int contentW = 244;

        addRenderableWidget(nav("HUD", 0, navX, top + 67, page == 0));
        addRenderableWidget(nav("Appearance", 1, navX, top + 94, page == 1));
        addRenderableWidget(nav("Crosshair", 2, navX, top + 121, page == 2));
        addRenderableWidget(nav("Extras", 3, navX, top + 148, page == 3));
        addRenderableWidget(nav("Spotify", 4, navX, top + 175, page == 4));
        addRenderableWidget(nav("HUD Editor", 5, navX, top + 202, page == 5));
        addRenderableWidget(nav("Reset", 6, navX, top + 229, page == 6));
        addRenderableWidget(nav("Visual Mods", 7, navX, top + 256, page == 7));
        addRenderableWidget(nav("Module Settings", 8, navX, top + 283, page == 8));
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + 14, top + 310, 96, 20).build());

        if (page == 0) {
            addRenderableWidget(Button.builder(Component.literal("FPS  " + state("showFps")), b -> flip("showFps"))
                    .bounds(contentX, top + 68, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Ping  " + state("showPing")), b -> flip("showPing"))
                    .bounds(contentX, top + 96, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Coordinates  " + state("showCoordinates")), b -> flip("showCoordinates"))
                    .bounds(contentX, top + 124, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Direction  " + state("showDirection")), b -> flip("showDirection"))
                    .bounds(contentX, top + 152, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Clock  " + state("showClock")), b -> flip("showClock"))
                    .bounds(contentX, top + 180, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Armor  " + state("showArmor")), b -> flip("showArmor"))
                    .bounds(contentX, top + 208, 116, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Effects  " + state("showEffects")), b -> flip("showEffects"))
                    .bounds(contentX + 122, top + 208, 122, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Gear %  " + state("showArmorDurability")), b -> flip("showArmorDurability"))
                    .bounds(contentX, top + 236, 78, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Held item  " + state("showHeldItem")), b -> flip("showHeldItem"))
                    .bounds(contentX + 82, top + 236, 80, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Biome  " + state("showBiome")), b -> flip("showBiome"))
                    .bounds(contentX + 166, top + 236, 78, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Potion names  " + state("showStatusEffectNames")), b -> flip("showStatusEffectNames"))
                    .bounds(contentX, top + 260, contentW, 20).build());
        } else if (page == 1) {
            addRenderableWidget(Button.builder(Component.literal("Theme  ·  " + ClientConfig.get().theme), b -> {
                String[] themes = {"DARK", "MIDNIGHT", "OCEAN", "PURPLE", "EMERALD", "SUNSET", "ROSE", "LIGHT", "BLUE", "CUSTOM", "CRIMSON", "GOLD", "MONOCHROME", "MINT", "GRAPHITE"};
                int i = 0; for (; i < themes.length; i++) if (themes[i].equals(ClientConfig.get().theme)) break;
                ClientConfig.get().theme = themes[(i + 1) % themes.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Accent  ·  " + String.format("#%06X", ClientConfig.get().accent)), b -> {
                int[] colors = {0x00B2FF, 0x9B7BFF, 0x35D49A, 0xFF9D45, 0xFF6FAE};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().accent) break;
                ClientConfig.get().accent = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD scale  ·  " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD opacity  ·  " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 171, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Compact HUD  ·  " + state("compactHud")), b -> flip("compactHud"))
                    .bounds(contentX, top + 203, contentW, 24).build());
        } else if (page == 2) {
            addRenderableWidget(Button.builder(Component.literal("Custom crosshair  ·  " + state("customCrosshair")), b -> flip("customCrosshair"))
                    .bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Style  ·  " + ClientConfig.get().crosshairStyle), b -> {
                String[] styles = {"PLUS", "DOT", "RING"};
                int i = 0; for (; i < styles.length; i++) if (styles[i].equals(ClientConfig.get().crosshairStyle)) break;
                ClientConfig.get().crosshairStyle = styles[(i + 1) % styles.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Size  ·  " + ClientConfig.get().crosshairSize), b -> {
                ClientConfig.get().crosshairSize = ClientConfig.get().crosshairSize >= 16 ? 4 : ClientConfig.get().crosshairSize + 2;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Gap  ·  " + ClientConfig.get().crosshairGap), b -> {
                ClientConfig.get().crosshairGap = ClientConfig.get().crosshairGap >= 10 ? 0 : ClientConfig.get().crosshairGap + 2;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 171, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Thickness  ·  " + ClientConfig.get().crosshairThickness), b -> {
                ClientConfig.get().crosshairThickness = ClientConfig.get().crosshairThickness >= 5 ? 1 : ClientConfig.get().crosshairThickness + 1;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 203, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Color  ·  " + String.format("#%06X", ClientConfig.get().crosshairColor)), b -> {
                int[] colors = {0x00B2FF, 0xFFFFFF, 0xFF5555, 0x55FF77, 0xFFD34E, 0xC77DFF};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().crosshairColor) break;
                ClientConfig.get().crosshairColor = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 235, contentW, 24).build());
        } else if (page == 3) {
            addRenderableWidget(Button.builder(Component.literal("Server address HUD  " + state("showServerAddress")), b -> flip("showServerAddress"))
                    .bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Keystrokes HUD  " + state("showKeystrokes")), b -> flip("showKeystrokes"))
                    .bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Client brand  " + state("showWelcomeBrand")), b -> flip("showWelcomeBrand"))
                    .bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Zoom key  ·  C  ·  Hold"), b -> {})
                    .bounds(contentX, top + 171, contentW, 24).build());
        } else if (page == 4) {
            addRenderableWidget(Button.builder(Component.literal("Open Spotify search: Misery"), b -> openSpotifySearch("Misery Maroon 5"))
                    .bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Open Spotify search: Heat Waves"), b -> openSpotifySearch("Heat Waves Glass Animals"))
                    .bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Open Spotify search: Love Nwantiti"), b -> openSpotifySearch("Love Nwantiti CKay"))
                    .bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Spotify opens outside Minecraft"), b -> {})
                    .bounds(contentX, top + 181, contentW, 24).build());
        } else if (page == 5) {
            addRenderableWidget(Button.builder(Component.literal("HUD position  ·  " + ClientConfig.get().hudPosition), b -> {
                String[] positions = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"};
                int i = 0; for (; i < positions.length; i++) if (positions[i].equals(ClientConfig.get().hudPosition)) break;
                ClientConfig.get().hudPosition = positions[(i + 1) % positions.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD background  ·  " + state("hudBackground")), b -> flip("hudBackground"))
                    .bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Accent bar  ·  " + state("hudAccentBar")), b -> flip("hudAccentBar"))
                    .bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Text shadow  ·  " + state("hudTextShadow")), b -> flip("hudTextShadow"))
                    .bounds(contentX, top + 171, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD scale  ·  " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 203, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD opacity  ·  " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 235, contentW, 24).build());
        } else if (page == 7) {
            String[][] modules = {
                {"Motion Blur", "motionBlur"}, {"Hand Aura", "handAura"},
                {"Free Look", "freeLook"}, {"Nametags", "nametags"},
                {"Item Physics", "itemPhysics"}, {"Block Outlines", "customBlockOutlines"},
                {"Color Grading", "colorGrading"}, {"Texture Editor", "textureEditor"},
                {"Shulker Preview", "shulkerPreview"}, {"Viewmodel Editor", "viewmodelEditor"},
                {"Cosmetics", "cosmetics"}, {"Spotify Lyrics Overlay", "spotifyLyricsOverlay"}
            };
            for (int i = 0; i < modules.length; i++) {
                final String field = modules[i][1];
                int col = i / 6, row = i % 6;
                addRenderableWidget(Button.builder(Component.literal(modules[i][0] + "  " + state(field)), b -> flip(field))
                    .bounds(contentX + col * 126, top + 75 + row * 29, 120, 23).build());
            }
            addRenderableWidget(Button.builder(Component.literal("Configure selected modules →"), b -> { page = 8; rebuild(); })
                    .bounds(contentX, top + 254, contentW, 23).build());
        } else if (page == 8) {
            addRenderableWidget(Button.builder(Component.literal("Motion blur strength · " + ClientConfig.get().motionBlurStrength), b -> cycleInt("motionBlurStrength", 1, 10, 1))
                    .bounds(contentX, top + 72, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Hand Aura intensity · " + ClientConfig.get().handAuraIntensity), b -> cycleInt("handAuraIntensity", 1, 10, 1))
                    .bounds(contentX, top + 98, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Nametag scale · " + ClientConfig.get().nametagScale + "%"), b -> cycleInt("nametagScale", 75, 150, 25))
                    .bounds(contentX, top + 124, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Outline width · " + ClientConfig.get().blockOutlineWidth), b -> cycleInt("blockOutlineWidth", 1, 5, 1))
                    .bounds(contentX, top + 150, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Saturation · " + ClientConfig.get().saturation + "%"), b -> cycleInt("saturation", 0, 200, 25))
                    .bounds(contentX, top + 176, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Brightness · " + ClientConfig.get().brightness + "%"), b -> cycleInt("brightness", 50, 150, 10))
                    .bounds(contentX, top + 202, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Contrast · " + ClientConfig.get().contrast + "%"), b -> cycleInt("contrast", 50, 150, 10))
                    .bounds(contentX, top + 228, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Temperature · " + ClientConfig.get().temperature), b -> cycleInt("temperature", -100, 100, 25))
                    .bounds(contentX, top + 254, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Texture preset · " + ClientConfig.get().texturePreset), b -> cycleString("texturePreset", new String[]{"DEFAULT", "CRISP", "SOFT", "VIBRANT", "CLASSIC"}))
                    .bounds(contentX, top + 280, contentW, 22).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Restore default settings"), b -> { ClientConfig.reset(); rebuild(); })
                    .bounds(contentX, top + 90, contentW, 26).build());
        }
    }

    private void cycleInt(String field, int min, int max, int step) {
        try {
            java.lang.reflect.Field f = ClientConfig.Data.class.getField(field);
            int value = f.getInt(ClientConfig.get()) + step;
            if (value > max) value = min;
            if (field.equals("temperature") && value > max) value = min;
            f.setInt(ClientConfig.get(), value);
            ClientConfig.save(); rebuild();
        } catch (ReflectiveOperationException ignored) { }
    }

    private void cycleString(String field, String[] values) {
        try {
            java.lang.reflect.Field f = ClientConfig.Data.class.getField(field);
            String current = (String) f.get(ClientConfig.get());
            int i = 0; for (; i < values.length; i++) if (values[i].equals(current)) break;
            f.set(ClientConfig.get(), values[(i + 1) % values.length]);
            ClientConfig.save(); rebuild();
        } catch (ReflectiveOperationException ignored) { }
    }

    private void openSpotifySearch(String query) {
        String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8).replace("+", "%20");
        Util.getPlatform().openUri("https://open.spotify.com/search/" + encoded);
    }

    private Button nav(String label, int target, int x, int y, boolean selected) {
        return Button.builder(Component.literal((selected ? "◆  " : "   ") + label), b -> { page = target; rebuild(); })
                .bounds(x, y, 96, 22).build();
    }

    private String state(String field) { return readBoolean(field) ? "ON" : "OFF"; }
    private void flip(String field) { writeBoolean(field, !readBoolean(field)); rebuild(); }
    private boolean readBoolean(String field) {
        try { return ClientConfig.Data.class.getField(field).getBoolean(ClientConfig.get()); }
        catch (ReflectiveOperationException ignored) { return false; }
    }
    private void writeBoolean(String field, boolean value) {
        try { ClientConfig.Data.class.getField(field).setBoolean(ClientConfig.get(), value); ClientConfig.save(); }
        catch (ReflectiveOperationException ignored) { }
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int x = panelLeft(), y = panelTop();
        String theme = ClientConfig.get().theme;
        boolean light = theme.equals("LIGHT");
        int panel = switch (theme) {
            case "LIGHT" -> 0xF0F3F6FA;
            case "BLUE", "OCEAN" -> 0xF0122038;
            case "PURPLE" -> 0xF0191428;
            case "EMERALD", "MINT" -> 0xF011211D;
            case "SUNSET", "GOLD" -> 0xF0261A17;
            case "ROSE", "CRIMSON" -> 0xF0251721;
            case "MONOCHROME", "GRAPHITE" -> 0xF0181A1E;
            default -> 0xF0111722;
        };
        int sidebar = light ? 0xFFe7ebf1 : 0xFF090F19;
        int mainText = light ? 0xFF18202C : 0xFFF2F6FC;
        int muted = light ? 0xFF657184 : 0xFF91A0B4;
        int themeAccent = switch (theme) {
            case "MIDNIGHT" -> 0xFF6E9DFF;
            case "OCEAN", "BLUE" -> 0xFF25BFFF;
            case "PURPLE" -> 0xFFB18CFF;
            case "EMERALD" -> 0xFF45D6A0;
            case "SUNSET" -> 0xFFFF9A62;
            case "ROSE" -> 0xFFFF78B7;
            case "LIGHT" -> 0xFF287BC1;
            case "CRIMSON" -> 0xFFFF526B;
            case "GOLD" -> 0xFFFFC857;
            case "MONOCHROME", "GRAPHITE" -> 0xFFD5D9E0;
            case "MINT" -> 0xFF70E0C0;
            default -> ClientConfig.get().accent;
        };
        int accent = 0xFF000000 | (theme.equals("CUSTOM") ? ClientConfig.get().accent : themeAccent) & 0x00FFFFFF;
        int edge = light ? 0xFFD8DEE8 : 0xFF26364B;
        int card = light ? 0xFFE8EDF4 : 0xFF172333;
        // Layered shell and accent rail give the screen a distinct client-style frame.
        g.fill(x - 5, y - 5, x + 405, y + 370, 0x70000000);
        g.fill(x, y, x + 400, y + 365, 0xFF05080E);
        g.fill(x + 1, y + 1, x + 399, y + 364, panel);
        g.fill(x + 1, y + 1, x + 399, y + 4, accent);
        g.fill(x + 2, y + 49, x + 398, y + 50, edge);
        g.fill(x + 2, y + 51, x + 118, y + 363, sidebar);
        g.fill(x + 117, y + 51, x + 118, y + 363, edge);
        // Small brand mark and status chip.
        g.fill(x + 13, y + 11, x + 34, y + 32, accent);
        g.drawString(font, "✦", x + 19, y + 17, 0xFFFFFFFF, false);
        g.drawString(font, "ITSM3LIODAS", x + 42, y + 12, mainText, false);
        g.drawString(font, "CLIENT  /  FABRIC 1.21.11", x + 42, y + 27, muted, false);
        g.fill(x + 323, y + 13, x + 386, y + 34, light ? 0xFFDDEFE7 : 0xFF102D2B);
        g.fill(x + 331, y + 21, x + 336, y + 26, 0xFF45D69A);
        g.drawString(font, "LEGIT MODE", x + 340, y + 20, light ? 0xFF176B50 : 0xFF75E6B7, false);
        String heading = page == 8 ? "MODULE SETTINGS" : page == 7 ? "VISUAL MODULES" : page == 0 ? "HUD MODULES" : page == 1 ? "CLIENT STYLE" : page == 2 ? "CROSSHAIR EDITOR" : page == 3 ? "EXTRA MODULES" : page == 4 ? "SPOTIFY QUICK LAUNCH" : page == 5 ? "ADVANCED HUD EDITOR" : "CONFIGURATION";
        String sub = page == 8 ? "Adjust each module's saved options" : page == 7 ? "Experimental client-side visual modules" : page == 0 ? "Toggle the information displayed in-game" : page == 1 ? "Personalise colours and interface behaviour" : page == 2 ? "Shape, size and colour of your crosshair" : page == 3 ? "Additional HUD switches and quality-of-life controls" : page == 4 ? "Launch your requested tracks in Spotify" : page == 5 ? "Position, background, accent and typography" : "Restore the default client configuration";
        g.drawString(font, heading, x + 132, y + 14, mainText, false);
        g.drawString(font, sub, x + 132, y + 31, muted, false);
        // Content card surfaces sit behind the interactive controls.
        if (page == 0) {
            g.fill(x + 126, y + 61, x + 390, y + 284, card);
            g.fill(x + 126, y + 61, x + 129, y + 284, accent);
            g.drawString(font, "ON-SCREEN WIDGETS", x + 136, y + 54, muted, false);
        } else if (page == 1) {
            g.fill(x + 126, y + 67, x + 390, y + 245, card);
            g.fill(x + 126, y + 67, x + 129, y + 245, accent);
            g.drawString(font, "APPEARANCE OPTIONS", x + 136, y + 54, muted, false);
        } else if (page == 2) {
            g.fill(x + 126, y + 67, x + 390, y + 276, card);
            g.fill(x + 126, y + 67, x + 129, y + 276, accent);
            g.drawString(font, "CROSSHAIR SETTINGS", x + 136, y + 54, muted, false);
        } else if (page == 3) {
            g.fill(x + 126, y + 67, x + 390, y + 245, card);
            g.fill(x + 126, y + 67, x + 129, y + 245, accent);
            g.drawString(font, "QUALITY OF LIFE", x + 136, y + 54, muted, false);
        } else if (page == 4 || page == 5 || page == 7 || page == 8) {
            g.fill(x + 126, y + 67, x + 390, y + 276, card);
            g.fill(x + 126, y + 67, x + 129, y + 245, accent);
            g.drawString(font, "YOUR PLAYLIST SHORTCUTS", x + 136, y + 54, muted, false);
            g.drawString(font, "Spotify account / app may be required", x + 136, y + 218, muted, false);
        } else {
            g.fill(x + 126, y + 82, x + 390, y + 145, card);
            g.fill(x + 126, y + 82, x + 129, y + 145, accent);
        }
        g.drawString(font, "RIGHT SHIFT  ·  MENU     C  ·  HOLD TO ZOOM", x + 13, y + 345, muted, false);
        g.drawString(font, "ITS M3LIODAS CLIENT  /  v2.0", x + 252, y + 350, muted, false);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
