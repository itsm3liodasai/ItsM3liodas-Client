package dev.itsm3liodas.client.hud;

import dev.itsm3liodas.client.ItsM3liodasClient;
import dev.itsm3liodas.client.config.ClientConfig;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Read-only information HUD. It never automates or modifies gameplay. */
public final class HudOverlay {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private HudOverlay() {}

    public static void register() {
        HudElementRegistry.addLast(ItsM3liodasClient.id("information_hud"), HudOverlay::render);
        HudElementRegistry.addLast(ItsM3liodasClient.id("custom_crosshair"), HudOverlay::renderCrosshair);
    }


    private static void renderCrosshair(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        ClientConfig.Data cfg = ClientConfig.get();
        if (!cfg.customCrosshair || mc.player == null || mc.options.hideGui
                || mc.screen != null || !mc.options.getCameraType().isFirstPerson()) return;

        int cx = mc.getWindow().getGuiScaledWidth() / 2;
        int cy = mc.getWindow().getGuiScaledHeight() / 2;
        int size = Math.max(2, Math.min(18, cfg.crosshairSize));
        int gap = Math.max(0, Math.min(12, cfg.crosshairGap));
        int t = Math.max(1, Math.min(5, cfg.crosshairThickness));
        int color = 0xFF000000 | (cfg.crosshairColor & 0xFFFFFF);
        String style = cfg.crosshairStyle;

        if ("DOT".equals(style)) {
            graphics.fill(cx - t, cy - t, cx + t + 1, cy + t + 1, color);
        } else if ("RING".equals(style)) {
            int outer = size;
            int inner = Math.max(1, size - t);
            graphics.fill(cx - outer, cy - outer, cx + outer + 1, cy - inner + 1, color);
            graphics.fill(cx - outer, cy + inner, cx + outer + 1, cy + outer + 1, color);
            graphics.fill(cx - outer, cy - inner + 1, cx - inner + 1, cy + inner, color);
            graphics.fill(cx + inner, cy - inner + 1, cx + outer + 1, cy + inner, color);
        } else {
            graphics.fill(cx - size - gap, cy - t / 2, cx - gap, cy - t / 2 + t, color);
            graphics.fill(cx + gap + 1, cy - t / 2, cx + size + gap + 1, cy - t / 2 + t, color);
            graphics.fill(cx - t / 2, cy - size - gap, cx - t / 2 + t, cy - gap, color);
            graphics.fill(cx - t / 2, cy + gap + 1, cx - t / 2 + t, cy + size + gap + 1, color);
        }
    }

    private static void render(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        ClientConfig.Data cfg = ClientConfig.get();
        if (mc.player == null || mc.options.hideGui) return;

        List<String> lines = new ArrayList<>();
        if (cfg.showFps) lines.add("FPS  " + mc.getFps());
        if (cfg.showPing && mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) lines.add("PING  " + info.getLatency() + " ms");
        }
        if (cfg.showCoordinates) {
            lines.add(String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (cfg.showDirection) lines.add("FACING  " + mc.player.getDirection().getName().toUpperCase(Locale.ROOT));
        if (cfg.showClock) lines.add("TIME  " + LocalTime.now().format(CLOCK));
        if (cfg.showServerAddress) {
            var server = mc.getCurrentServer();
            lines.add("SERVER  " + (server == null ? "Singleplayer" : server.ip));
        }
        if (cfg.showKeystrokes) {
            var keys = mc.options;
            lines.add("KEYS  " + (keys.keyUp.isDown() ? "W" : "·") + " "
                    + (keys.keyLeft.isDown() ? "A" : "·") + " "
                    + (keys.keyDown.isDown() ? "S" : "·") + " "
                    + (keys.keyRight.isDown() ? "D" : "·") + "  "
                    + (keys.keyJump.isDown() ? "SPACE" : "")
                    + (keys.keyShift.isDown() ? " SHIFT" : "")
                    + (keys.keySprint.isDown() ? " SPRINT" : ""));
        }
        if (cfg.showWelcomeBrand) lines.add("✦  ITSM3LIODAS CLIENT");
        if (cfg.showArmor) {
            long count = 0;
            EquipmentSlot[] armorSlots = { EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                    EquipmentSlot.LEGS, EquipmentSlot.FEET };
            for (EquipmentSlot slot : armorSlots) {
                if (!mc.player.getItemBySlot(slot).isEmpty()) count++;
            }
            lines.add("ARMOR  " + count + "/4");
        }
        if (cfg.showArmorDurability) {
            EquipmentSlot[] armorSlots = { EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                    EquipmentSlot.LEGS, EquipmentSlot.FEET };
            StringBuilder durability = new StringBuilder("GEAR  ");
            boolean first = true;
            for (EquipmentSlot slot : armorSlots) {
                var stack = mc.player.getItemBySlot(slot);
                if (!stack.isEmpty() && stack.isDamageableItem()) {
                    if (!first) durability.append("  ");
                    int remaining = Math.max(0, 100 - Math.round(stack.getDamageValue() * 100f / stack.getMaxDamage()));
                    durability.append(slot.name().substring(0, 1)).append(remaining).append('%');
                    first = false;
                }
            }
            if (!first) lines.add(durability.toString());
        }
        if (cfg.showHeldItem && !mc.player.getMainHandItem().isEmpty()) {
            lines.add("HELD  " + mc.player.getMainHandItem().getHoverName().getString());
        }
        if (cfg.showBiome && mc.level != null) {
            String biome = mc.level.getBiome(mc.player.blockPosition())
                    .unwrapKey()
                    .map(key -> key.identifier().getPath())
                    .orElse("unknown");
            lines.add("BIOME  " + biome);
        }
        if (cfg.showEffects) lines.add("EFFECTS  " + mc.player.getActiveEffects().size());
        if (cfg.showStatusEffectNames && !mc.player.getActiveEffects().isEmpty()) {
            for (var effect : mc.player.getActiveEffects()) {
                lines.add("POTION  " + effect.getEffect().value().getDisplayName().getString());
            }
        }
        if (lines.isEmpty()) return;

        float scale = Math.max(0.75f, Math.min(1.5f, cfg.hudScale));
        int alpha = Math.max(0, Math.min(255, Math.round(cfg.hudOpacity * 255)));
        int bg = (alpha << 24) | 0x00101722;
        int accent = 0xFF000000 | (cfg.accent & 0xFFFFFF);
        int x = 10, y = 10;
        int rowHeight = cfg.compactHud ? 13 : 16;
        int padX = cfg.compactHud ? 6 : 8;
        int maxTextWidth = 0;
        for (String line : lines) maxTextWidth = Math.max(maxTextWidth, mc.font.width(line));
        int cardWidth = maxTextWidth + padX * 2 + 3;
        int cardHeight = lines.size() * rowHeight + 10;
        int scaledWidth = Math.round(cardWidth * scale);
        int scaledHeight = Math.round(cardHeight * scale);
        int screenWidth = mc.getWindow().getGuiScaledWidth();
        int screenHeight = mc.getWindow().getGuiScaledHeight();
        String position = cfg.hudPosition == null ? "TOP_LEFT" : cfg.hudPosition;
        if (position.contains("RIGHT")) x = Math.max(4, Math.round(screenWidth / scale) - cardWidth - 10);
        if (position.startsWith("BOTTOM")) y = Math.max(4, Math.round(screenHeight / scale) - cardHeight - 10);

        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        if (cfg.hudBackground) graphics.fill(x, y, x + cardWidth, y + cardHeight, bg);
        if (cfg.hudAccentBar) graphics.fill(x, y, x + 2, y + cardHeight, accent);
        if (cfg.hudBackground) graphics.fill(x + 2, y, x + cardWidth, y + 1, 0x553F6B91);
        int rowY = y + 6;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            int rowColor = 0xFFF0F4FA;
            if (i == 0) rowColor = 0xFFFFFFFF;
            graphics.drawString(mc.font, line, x + padX + 2, rowY, rowColor, cfg.hudTextShadow);
            rowY += rowHeight;
        }
        graphics.pose().popMatrix();
    }
}
