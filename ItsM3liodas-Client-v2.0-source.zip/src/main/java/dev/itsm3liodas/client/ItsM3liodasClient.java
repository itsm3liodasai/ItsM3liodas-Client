package dev.itsm3liodas.client;

import dev.itsm3liodas.client.config.ClientConfig;
import dev.itsm3liodas.client.gui.ClientMenuScreen;
import dev.itsm3liodas.client.hud.HudOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ItsM3liodasClient implements ClientModInitializer {
    public static final String MOD_ID = "itsm3liodas_client";
    private static KeyMapping openMenuKey;
    private static KeyMapping zoomKey;
    private static int previousFov = -1;

    @Override
    public void onInitializeClient() {
        ClientConfig.load();
        HudOverlay.register();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.itsm3liodas_client.open_menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.itsm3liodas_client.zoom",
                GLFW.GLFW_KEY_C,
                KeyMapping.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new ClientMenuScreen());
            }
            if (client.options != null) {
                if (zoomKey.isDown() && client.player != null && client.screen == null) {
                    if (previousFov < 0) previousFov = client.options.fov().get();
                    client.options.fov().set(Math.max(15, Math.min(previousFov, 30)));
                } else if (previousFov >= 0) {
                    client.options.fov().set(previousFov);
                    previousFov = -1;
                }
            }
        });
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }
}
