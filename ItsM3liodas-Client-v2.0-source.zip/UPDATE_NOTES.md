# v1.8 update

- Fixed the theme selector so all 15 advertised themes are actually selectable.
- Added distinct panel palettes and accent colors for the theme choices.
- Updated the in-menu version label.
- No browser or cheat features added.

Build status: source/archive validation only; Gradle compilation not verified.

## v1.9 — Advanced HUD editor
- Added a dedicated HUD Editor page.
- Added four-corner HUD positioning.
- Added independent background, accent-bar and text-shadow controls.
- Reused persistent HUD scale and opacity controls.
- No in-game browser or gameplay cheats added.
- Motion blur, Hand Aura, Free Look, nametags, item physics, custom block outlines, color grading, texture editing, Shulker Preview, viewmodel editing, cosmetics, Spotify playback and synced lyrics remain unimplemented.
