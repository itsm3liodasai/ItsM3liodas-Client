# Feature status (source audit)

## Implemented in source
- FPS, ping, coordinates, direction, local clock
- Armor count and durability
- Held item and biome display
- Potion effect count and names
- Server address, keystrokes, and client-brand HUD toggles
- Client menu with HUD, Appearance, Crosshair, Extras, Spotify, and Reset pages
- Theme cycling with 15 actual palette choices: Dark, Midnight, Ocean, Purple, Emerald, Sunset, Rose, Light, Blue, Custom, Crimson, Gold, Monochrome, Mint, Graphite
- Accent presets, HUD scale/opacity, compact HUD, reset
- Advanced HUD editor: four-corner positioning, background toggle, accent-bar toggle, text-shadow toggle, scale and opacity controls; settings persist in the client config
- Custom crosshair: toggle, PLUS/DOT/RING styles, size, gap, thickness, selectable colors
- Hold-to-zoom keybind (C), restoring the user's previous FOV on release
- Spotify quick-launch links for Misery, Heat Waves, and Love Nwantiti (external search only)

## Still not implemented
- Motion blur and menu blur
- Nametags
- Custom block outlines
- Item physics
- Color grading suite (saturation, hue, brightness, contrast, vibrance, temperature, gamma, sharpness)
- Custom texture editor / visual packs
- Hand Aura / Hand Glow
- Free Look
- Shulker Preview
- Viewmodel editor
- Cosmetics, wings, capes and particle cosmetics
- Drag-and-drop HUD editor (current editor provides corner presets and style controls, not freeform dragging)
- Spotify playback and synchronized lyrics
- Additional animation and performance systems

No in-game browser, combat cheats, gameplay automation, or anti-cheat bypass features are included.

## Build verification
This source update has not been compile-verified in this environment.
