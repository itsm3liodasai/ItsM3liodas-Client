# ItsM3liodas Client

A client-side **Fabric-only** Minecraft visual/QoL mod project. The current source implementation targets **Minecraft 26.3**. The intended release targets are 1.21.1, 1.21.4, 1.21.8, 1.21.11, 26.1, 26.2 and 26.3; these require separate version-specific source/build adaptations because Minecraft APIs and Java requirements change between releases.

## Current implementation

- Right Shift opens the client settings menu.
- Persistent configuration in `.minecraft/config/itsm3liodasclient.json`.
- Read-only HUD: FPS, ping, coordinates, direction, local clock, armor-piece count and active-effect count.
- Individual HUD visibility switches.
- HUD opacity and scale settings.
- Dark, Light and Blue themes, accent-color cycling, and reset-to-defaults.
- Client-only behavior; no server-side installation required.
- No combat automation, movement automation, x-ray, entity/player tracking, packet manipulation, exploits or anti-cheat bypasses.

## Requested release matrix

The requested main-version targets are:

| Minecraft | Loader | Java runtime | Status in this ZIP |
|---|---|---:|---|
| 1.21.1 | Fabric | 21 | Planned; not yet ported/tested |
| 1.21.4 | Fabric | 21 | Planned; not yet ported/tested |
| 1.21.8 | Fabric | 21 | Planned; not yet ported/tested |
| 1.21.11 | Fabric | 21 | Planned; not yet ported/tested |
| 26.1 | Fabric | 25 | Planned; not yet ported/tested |
| 26.2 | Fabric | 25 | Planned; not yet ported/tested |
| 26.3 | Fabric | 25 | Current source target; build not verified here |

A single universal JAR is not promised. The source/API differences require a separately compiled artifact for each target. The GitHub workflow currently builds the 26.3 target only; it must not be treated as evidence that the other targets are ready.

## Not implemented yet

The following requested features are not included as working features in this starter: a full draggable HUD editor, keystrokes/CPS widgets, detailed potion timers, screenshot manager, resource-pack manager, server-list customization, custom chat/tab-list/hotbar/scoreboard styling, custom crosshair, custom fonts, custom main-menu background/music, named config profiles, dedicated FPS optimization controls, Sodium integration, and the angel-style name/TAB icon. These need implementation and per-version testing; this project does not claim otherwise. In particular, a client-side icon cannot force other players to see it on multiplayer servers.

## Build locally (26.3 target)

1. Install **JDK 25** and verify `java -version` reports 25.
2. Extract or clone this repository.
3. On Linux/macOS run `chmod +x gradlew` once, then `./gradlew build`.
4. On Windows run `gradlew.bat build`.
5. If the build succeeds, the mod JAR is written to `build/libs/`.
6. Install Fabric Loader for Minecraft 26.3 and the matching Fabric API, then place the JARs in the Minecraft `mods` folder.

The Gradle wrapper bootstraps Gradle 9.6 and requires internet access on first run.

## GitHub Actions

1. Create an empty GitHub repository.
2. Upload the **contents** of this project folder to the repository root.
3. Commit and push to the `main` branch.
4. The workflow runs automatically on pushes to `main`.
5. To run it manually, open **Actions → Build ItsM3liodas Client → Run workflow**.
6. After a successful run, download the `itsm3liodas-client-26.3` artifact from the run's **Artifacts** section. The JAR originates from `build/libs/`.

A failed Gradle build fails the workflow; the workflow does not upload an artifact on failure.

## Controls

- **Right Shift**: open the settings screen.
- Settings are saved automatically.

## Build verification

**Not build-tested in the packaging environment.** This environment did not have Java 25 or dependency-download access, so no successful compilation is claimed. GitHub Actions is configured to perform the first dependency-resolved build. Do not call this a tested release until that workflow passes and the resulting JAR is tested in the matching Minecraft version.
