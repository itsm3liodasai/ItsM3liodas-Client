# ItsM3liodas Client (Minecraft 1.21.11 / Fabric)

**ItsM3liodas Client** is a client-side visual customization, HUD, camera utility, Spotify/lyrics HUD, and 3D cosmetic + custom cape mod for **Minecraft Java Edition 1.21.11** built on **Fabric Loader** and **Java 21**.

## How to Get the Compiled `.jar` with GitHub Actions (No Local Setup Needed)
1. Upload/push the contents of this archive (`ItsM3liodas-Client-Fabric-1.21.11`) to a GitHub repository.
2. Open the **Actions** tab in your GitHub repository — **Build ItsM3liodas Client (.JAR for MC 1.21.11)** runs automatically on every push (or click **Run workflow** manually).
3. When the green checkmark completes, click the workflow run and download **`itsm3liodas-client-mc1.21.11-fabric-jar`** under **Artifacts** (or check **Releases** if you checked `create_release` or pushed a `v*` tag).
4. Unzip if needed and drop `itsm3liodas-client-2.5.0+1.21.11.jar` + `fabric-api-0.141.6+1.21.11.jar` into `.minecraft/mods/`.

## Target Environment
- **Minecraft:** 1.21.11
- **Java:** 21
- **Fabric Loader:** `0.20.1` (`>=0.18.1`)
- **Fabric API:** `0.141.6+1.21.11`
- **Fabric Loom:** `1.17.21` (`net.fabricmc.fabric-loom-remap`)
- **Mappings:** Yarn `1.21.11+build.6`
- **Gradle:** `9.8.2`
