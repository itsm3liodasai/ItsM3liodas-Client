package com.itsm3liodas.client;

import com.itsm3liodas.client.config.ClientConfig;
import com.itsm3liodas.client.cosmetic.ClientCosmetics;
import com.itsm3liodas.client.module.ClientModules;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class ClientConfigTest {

    @Test
    void defaultsPassValidationAndHaveZeroKeybindConflicts() {
        ClientConfig cfg = new ClientConfig();
        cfg.validateAndClamp();
        assertEquals(ClientConfig.CURRENT_SCHEMA_VERSION, cfg.schemaVersion);
        List<String> conflicts = ClientConfig.detectKeybindConflicts(cfg.keybinds);
        assertTrue(conflicts.isEmpty(), "Default keybinds must not conflict");
    }

    @Test
    void outOfBoundsValuesAreSafelyClamped() {
        ClientConfig cfg = new ClientConfig();
        cfg.hudScale = 99.0f;
        cfg.hudOpacity = -5.0f;
        cfg.zoom.strength = 500.0f;
        cfg.colorGrading.brightness = Float.NaN;
        cfg.validateAndClamp();

        assertEquals(2.5f, cfg.hudScale);
        assertEquals(0.1f, cfg.hudOpacity);
        assertEquals(12.0f, cfg.zoom.strength);
        assertEquals(0.5f, cfg.colorGrading.brightness);
    }

    @Test
    void configSaveCreatesBackupAndRecoversFromCorruptPrimary(@TempDir Path tempDir) throws Exception {
        Path configPath = tempDir.resolve("config.json");
        ClientConfig original = new ClientConfig();
        original.accentColor = "#FF4D8D";
        original.motionBlur.enabled = true;
        original.save(configPath);

        original.zoom.strength = 6.5f;
        original.save(configPath);
        assertTrue(Files.exists(tempDir.resolve("config.json.bak")));

        Files.writeString(configPath, "{ invalid json !!!");
        ClientConfig recovered = ClientConfig.load(configPath);
        assertEquals("#FF4D8D", recovered.accentColor);
        assertTrue(recovered.motionBlur.enabled);
    }

    @Test
    void visualPackSafetyRejectsExecutableAndTraversalEntries() {
        assertTrue(ClientConfig.isSafeAssetEntryPath("assets/itsm3liodas/textures/gui/panel.png"));
        assertTrue(ClientConfig.isSafeAssetEntryPath("pack.mcmeta"));
        assertFalse(ClientConfig.isSafeAssetEntryPath("../escape.png"));
        assertFalse(ClientConfig.isSafeAssetEntryPath("payload/evil.class"));
        assertFalse(ClientConfig.isSafeAssetEntryPath("scripts/run.js"));
        assertFalse(ClientConfig.isSafeAssetEntryPath("libs/mod.jar"));
    }

    @Test
    void zoomAndFreelookOperateIndependently() {
        ClientConfig cfg = new ClientConfig();
        ClientModules modules = new ClientModules();

        modules.setZoomActive(true);
        modules.tick(cfg, 0.25f);
        assertTrue(modules.adjustFov(70.0, cfg) < 70.0);
        assertFalse(modules.hasActiveFreelookOffset());

        modules.setFreelookActive(true);
        modules.applyFreelookDelta(45.0f, -20.0f, cfg);
        modules.tick(cfg, 0.25f);
        assertTrue(modules.hasActiveFreelookOffset());

        modules.setZoomActive(false);
        modules.tick(cfg, 1.0f);
        assertTrue(modules.hasActiveFreelookOffset(), "Disabling Zoom must not break Freelook");
    }

    @Test
    void jsonImportRejectsEmptyAndParsesValid() {
        assertTrue(ClientConfig.importJson("   ").isEmpty());
        ClientConfig cfg = new ClientConfig();
        cfg.themeId = "blossom";
        Optional<ClientConfig> parsed = ClientConfig.importJson(cfg.exportJson());
        assertTrue(parsed.isPresent());
        assertEquals("blossom", parsed.get().themeId);
    }

    @Test
    void cosmeticWingMotionAnimatesAndRespectsDisableFlag() {
        ClientConfig cfg = new ClientConfig();
        cfg.cosmetics.wingFlapSpeed = 99.0f;
        cfg.cosmetics.wingSpread = 0.01f;
        cfg.validateAndClamp();

        assertEquals(2.5f, cfg.cosmetics.wingFlapSpeed);
        assertEquals(0.6f, cfg.cosmetics.wingSpread);

        float a0 = ClientCosmetics.computeWingInnerYawDeg(0.1f, cfg.cosmetics, false, false);
        float a1 = ClientCosmetics.computeWingInnerYawDeg(0.45f, cfg.cosmetics, false, false);
        assertNotEquals(a0, a1, "Enabled animated wings must move across time");

        cfg.cosmetics.animationsEnabled = false;
        float staticA0 = ClientCosmetics.computeWingInnerYawDeg(0.1f, cfg.cosmetics, false, false);
        float staticA1 = ClientCosmetics.computeWingInnerYawDeg(0.45f, cfg.cosmetics, false, false);
        assertEquals(staticA0, staticA1, "Disabled animations must hold a steady resting wing pose");
    }

    @Test
    void customCapeRejectsExecutableAndAcceptsImageOrGif(@TempDir Path tempDir) throws Exception {
        Path png = tempDir.resolve("custom_cape.png");
        Path gif = tempDir.resolve("animated_cape.gif");
        Path bad = tempDir.resolve("malware.jar");
        Files.writeString(png, "stub");
        Files.writeString(gif, "stub");
        Files.writeString(bad, "stub");

        assertTrue(com.itsm3liodas.client.cosmetic.CustomCapeManager.isSupportedCapeFile(png));
        assertTrue(com.itsm3liodas.client.cosmetic.CustomCapeManager.isSupportedCapeFile(gif));
        assertFalse(com.itsm3liodas.client.cosmetic.CustomCapeManager.isSupportedCapeFile(bad));
    }
}
