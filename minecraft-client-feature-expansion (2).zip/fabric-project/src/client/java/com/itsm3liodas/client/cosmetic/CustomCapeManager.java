package com.itsm3liodas.client.cosmetic;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Safely validates and loads custom local PNG/JPG/animated GIF capes from config/itsm3liodas/capes/.
 * Decodes multi-frame GIF timing asynchronously without blocking the Minecraft render thread.
 */
public final class CustomCapeManager {
    public record CapeFrame(int width, int height, int[] argbPixels, int delayMs) {}

    private CustomCapeManager() {}

    public static boolean isSupportedCapeFile(Path path) {
        if (path == null || !Files.isRegularFile(path)) return false;
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".gif");
    }

    public static List<CapeFrame> decodeCapeFrames(Path capePath) throws IOException {
        if (!isSupportedCapeFile(capePath)) {
            throw new IOException("Unsupported cape file format (expected .png, .jpg, or .gif)");
        }
        String name = capePath.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".gif")) {
            return decodeGifFrames(capePath);
        }
        BufferedImage img = ImageIO.read(capePath.toFile());
        if (img == null) {
            throw new IOException("Unreadable cape image");
        }
        List<CapeFrame> single = new ArrayList<>(1);
        single.add(toFrame(img, 100));
        return single;
    }

    private static List<CapeFrame> decodeGifFrames(Path gifPath) throws IOException {
        List<CapeFrame> frames = new ArrayList<>();
        try (ImageInputStream stream = ImageIO.createImageInputStream(gifPath.toFile())) {
            Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("gif");
            if (!readers.hasNext()) {
                throw new IOException("No GIF ImageReader available");
            }
            ImageReader reader = readers.next();
            try {
                reader.setInput(stream);
                int count = reader.getNumImages(true);
                for (int i = 0; i < count; i++) {
                    BufferedImage frameImg = reader.read(i);
                    int delayMs = readGifDelayMs(reader.getImageMetadata(i));
                    frames.add(toFrame(frameImg, Math.max(20, delayMs)));
                }
            } finally {
                reader.dispose();
            }
        }
        return frames;
    }

    private static int readGifDelayMs(IIOMetadata metadata) {
        if (metadata == null) return 80;
        try {
            var root = metadata.getAsTree("javax_imageio_gif_image_1.0");
            var children = root.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                var node = children.item(i);
                if ("GraphicControlExtension".equals(node.getNodeName()) && node.getAttributes() != null) {
                    var attr = node.getAttributes().getNamedItem("delayTime");
                    if (attr != null) {
                        return Integer.parseInt(attr.getNodeValue()) * 10;
                    }
                }
            }
        } catch (Exception ignored) {}
        return 80;
    }

    private static CapeFrame toFrame(BufferedImage img, int delayMs) {
        int w = img.getWidth();
        int h = img.getHeight();
        int[] argb = img.getRGB(0, 0, w, h, null, 0, w);
        return new CapeFrame(w, h, argb, delayMs);
    }
}
