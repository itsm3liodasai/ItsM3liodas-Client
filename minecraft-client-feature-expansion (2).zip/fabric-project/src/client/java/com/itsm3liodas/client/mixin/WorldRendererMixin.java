package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Customizes the RGBA color and line width of the standard block-selection outline
 * without altering occlusion or block visibility rules.
 * Verified against Yarn 1.21.11 WorldRenderer#drawBlockOutline(..., OutlineRenderState, int color, float lineWidth).
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private int itsm3liodas$recolorBlockOutline(int originalColor) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.blockOutline.enabled) return originalColor;
        int alpha = Math.round(Math.max(0.1f, Math.min(1.0f, cfg.blockOutline.opacity)) * 255.0f);
        int rgb = 0x7C5CFF;
        try {
            String hex = cfg.blockOutline.color.startsWith("#") ? cfg.blockOutline.color.substring(1) : cfg.blockOutline.color;
            rgb = Integer.parseInt(hex, 16) & 0x00FFFFFF;
        } catch (Exception ignored) {}
        return (alpha << 24) | rgb;
    }

    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, ordinal = 3, require = 0)
    private float itsm3liodas$resizeBlockOutline(float originalLineWidth) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.blockOutline.enabled) return originalLineWidth;
        return Math.max(1.0f, Math.min(6.0f, cfg.blockOutline.thickness));
    }
}
