package com.itsm3liodas.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;

/**
 * Versioned, validated configuration store for ItsM3liodas Client (MC 1.21.11 / Java 21).
 * Handles atomic saves, automatic .bak rolling backups, error recovery, and bounds clamping.
 */
public final class ClientConfig {
    public static final int CURRENT_SCHEMA_VERSION = 3;
    private static final Logger LOGGER = LoggerFactory.getLogger("itsm3liodas-config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public int schemaVersion = CURRENT_SCHEMA_VERSION;
    public String clientVersion = "2.5.0+1.21.11";

    // Global Theme & UI
    public String themeId = "midnight";
    public String accentColor = "#7C5CFF";
    public String secondaryAccentColor = "#38BDF8";
    public float hudScale = 1.0f;
    public float hudOpacity = 0.85f;
    public float menuAnimationSpeed = 1.0f;
    public int cornerRadius = 12;
    public boolean reducedMotion = false;
    public String fontStyle = "inter";

    // Module configurations
    public MotionBlurConfig motionBlur = new MotionBlurConfig();
    public MenuBlurConfig menuBlur = new MenuBlurConfig();
    public NametagsConfig nametags = new NametagsConfig();
    public CrosshairConfig crosshair = new CrosshairConfig();
    public BlockOutlineConfig blockOutline = new BlockOutlineConfig();
    public ItemPhysicsConfig itemPhysics = new ItemPhysicsConfig();
    public ColorGradingConfig colorGrading = new ColorGradingConfig();
    public VisualPacksConfig visualPacks = new VisualPacksConfig();
    public HandAuraConfig handAura = new HandAuraConfig();
    public ZoomConfig zoom = new ZoomConfig();
    public FreelookConfig freelook = new FreelookConfig();
    public ShulkerPreviewConfig shulkerPreview = new ShulkerPreviewConfig();
    public ViewmodelConfig viewmodel = new ViewmodelConfig();
    public CosmeticsConfig cosmetics = new CosmeticsConfig();
    public ParticleEffectsConfig particles = new ParticleEffectsConfig();
    public MusicLyricsConfig musicLyrics = new MusicLyricsConfig();
    public PerformanceConfig performance = new PerformanceConfig();

    // Preserved & Enhanced HUD Elements
    public Map<String, HudElementConfig> hudElements = createDefaultHudElements();

    // Keybinds (GLFW key codes + mode)
    public Map<String, KeybindEntry> keybinds = createDefaultKeybinds();

    public static Map<String, HudElementConfig> createDefaultHudElements() {
        Map<String, HudElementConfig> map = new LinkedHashMap<>();
        map.put("fps", new HudElementConfig(true, 0.02f, 0.03f, 1.0f, 0.85f, "#FFFFFF", "{fps} FPS"));
        map.put("ping", new HudElementConfig(true, 0.02f, 0.08f, 1.0f, 0.85f, "#38BDF8", "{ping}"));
        map.put("coordinates", new HudElementConfig(true, 0.02f, 0.13f, 1.0f, 0.85f, "#E2E8F0", "XYZ: {x}, {y}, {z}"));
        map.put("direction", new HudElementConfig(true, 0.02f, 0.19f, 1.0f, 0.85f, "#A78BFA", "Facing: {dir}"));
        map.put("biome", new HudElementConfig(true, 0.02f, 0.24f, 1.0f, 0.85f, "#34D399", "Biome: {biome}"));
        map.put("clock", new HudElementConfig(true, 0.86f, 0.03f, 1.0f, 0.85f, "#F8FAFC", "24H"));
        map.put("server", new HudElementConfig(true, 0.82f, 0.08f, 1.0f, 0.85f, "#94A3B8", "{addr}"));
        map.put("armor", new HudElementConfig(true, 0.85f, 0.65f, 1.0f, 0.92f, "#E2E8F0", "UKU"));
        map.put("heldItem", new HudElementConfig(true, 0.82f, 0.84f, 1.0f, 0.85f, "#F1F5F9", "FULL"));
        map.put("potions", new HudElementConfig(true, 0.02f, 0.45f, 1.0f, 0.85f, "#C4B5FD", "COMPACT"));
        map.put("keystrokes", new HudElementConfig(true, 0.83f, 0.16f, 1.0f, 0.85f, "#7C5CFF", "WASD_MOUSE"));
        return map;
    }

    public static Map<String, KeybindEntry> createDefaultKeybinds() {
        Map<String, KeybindEntry> map = new LinkedHashMap<>();
        map.put("menu", new KeybindEntry(344, "TOGGLE"));      // Right Shift
        map.put("zoom", new KeybindEntry(67, "HOLD"));         // C
        map.put("freelook", new KeybindEntry(342, "HOLD"));    // Left Alt
        map.put("hudEditor", new KeybindEntry(72, "TOGGLE"));  // H
        map.put("wardrobe", new KeybindEntry(75, "TOGGLE"));   // K
        return map;
    }

    public void validateAndClamp() {
        schemaVersion = CURRENT_SCHEMA_VERSION;
        hudScale = clamp(hudScale, 0.5f, 2.5f);
        hudOpacity = clamp(hudOpacity, 0.1f, 1.0f);
        menuAnimationSpeed = clamp(menuAnimationSpeed, 0.25f, 2.5f);
        cornerRadius = Math.max(0, Math.min(24, cornerRadius));

        motionBlur.intensity = clamp(motionBlur.intensity, 0.0f, 1.0f);
        motionBlur.durationMs = clamp(motionBlur.durationMs, 8.0f, 120.0f);
        motionBlur.qualitySamples = Math.max(2, Math.min(16, motionBlur.qualitySamples));

        menuBlur.strength = clamp(menuBlur.strength, 0.0f, 24.0f);
        menuBlur.dimming = clamp(menuBlur.dimming, 0.0f, 0.9f);
        menuBlur.opacity = clamp(menuBlur.opacity, 0.2f, 1.0f);

        nametags.scale = clamp(nametags.scale, 0.5f, 2.0f);
        nametags.backgroundOpacity = clamp(nametags.backgroundOpacity, 0.0f, 1.0f);

        crosshair.size = clamp(crosshair.size, 2.0f, 24.0f);
        crosshair.thickness = clamp(crosshair.thickness, 1.0f, 6.0f);
        crosshair.gap = clamp(crosshair.gap, 0.0f, 16.0f);
        crosshair.opacity = clamp(crosshair.opacity, 0.1f, 1.0f);

        blockOutline.thickness = clamp(blockOutline.thickness, 1.0f, 6.0f);
        blockOutline.opacity = clamp(blockOutline.opacity, 0.1f, 1.0f);

        itemPhysics.speed = clamp(itemPhysics.speed, 0.1f, 3.0f);

        colorGrading.brightness = clamp(colorGrading.brightness, 0.5f, 1.8f);
        colorGrading.contrast = clamp(colorGrading.contrast, 0.5f, 1.8f);
        colorGrading.saturation = clamp(colorGrading.saturation, 0.0f, 2.0f);
        colorGrading.temperature = clamp(colorGrading.temperature, -1.0f, 1.0f);
        colorGrading.gamma = clamp(colorGrading.gamma, 0.5f, 2.2f);
        colorGrading.vignette = clamp(colorGrading.vignette, 0.0f, 1.0f);

        zoom.strength = clamp(zoom.strength, 1.5f, 12.0f);
        zoom.transitionSpeed = clamp(zoom.transitionSpeed, 1.0f, 20.0f);

        freelook.horizontalSensitivity = clamp(freelook.horizontalSensitivity, 0.1f, 3.0f);
        freelook.verticalSensitivity = clamp(freelook.verticalSensitivity, 0.1f, 3.0f);
        freelook.maxHorizontalDeg = clamp(freelook.maxHorizontalDeg, 30.0f, 180.0f);
        freelook.maxVerticalDeg = clamp(freelook.maxVerticalDeg, 30.0f, 90.0f);

        handAura.intensity = clamp(handAura.intensity, 0.0f, 1.0f);
        handAura.size = clamp(handAura.size, 0.5f, 2.5f);
        handAura.transparency = clamp(handAura.transparency, 0.1f, 1.0f);
        handAura.animationSpeed = clamp(handAura.animationSpeed, 0.2f, 3.0f);
        handAura.particleAmount = Math.max(0, Math.min(48, handAura.particleAmount));

        viewmodel.scale = clamp(viewmodel.scale, 0.4f, 1.8f);
        cosmetics.wingFlapSpeed = clamp(cosmetics.wingFlapSpeed, 0.25f, 2.5f);
        cosmetics.wingSpread = clamp(cosmetics.wingSpread, 0.6f, 1.6f);
        particles.amount = Math.max(0, Math.min(120, particles.amount));
        particles.size = clamp(particles.size, 0.3f, 3.0f);
        particles.transparency = clamp(particles.transparency, 0.1f, 1.0f);

        musicLyrics.lyricScale = clamp(musicLyrics.lyricScale, 0.6f, 2.0f);
        musicLyrics.lyricOpacity = clamp(musicLyrics.lyricOpacity, 0.2f, 1.0f);
        musicLyrics.cardOpacity = clamp(musicLyrics.cardOpacity, 0.2f, 1.0f);

        if (hudElements == null || hudElements.isEmpty()) {
            hudElements = createDefaultHudElements();
        } else {
            for (HudElementConfig el : hudElements.values()) {
                el.x = clamp(el.x, 0.0f, 0.96f);
                el.y = clamp(el.y, 0.0f, 0.96f);
                el.scale = clamp(el.scale, 0.5f, 2.5f);
                el.opacity = clamp(el.opacity, 0.1f, 1.0f);
                el.lowDurabilityThreshold = Math.max(5, Math.min(60, el.lowDurabilityThreshold));
            }
        }
        if (keybinds == null || keybinds.isEmpty()) {
            keybinds = createDefaultKeybinds();
        }
    }

    public static List<String> detectKeybindConflicts(Map<String, KeybindEntry> keybinds) {
        Map<Integer, List<String>> seen = new HashMap<>();
        for (Map.Entry<String, KeybindEntry> entry : keybinds.entrySet()) {
            int code = entry.getValue().keyCode;
            if (code > 0) {
                seen.computeIfAbsent(code, k -> new ArrayList<>()).add(entry.getKey());
            }
        }
        List<String> conflicts = new ArrayList<>();
        for (Map.Entry<Integer, List<String>> entry : seen.entrySet()) {
            if (entry.getValue().size() > 1) {
                conflicts.add("Key " + entry.getKey() + " assigned to: " + String.join(", ", entry.getValue()));
            }
        }
        return conflicts;
    }

    public static boolean isSafeAssetEntryPath(String entryPath) {
        if (entryPath == null || entryPath.isBlank()) return false;
        String lower = entryPath.toLowerCase(Locale.ROOT).trim();
        if (lower.contains("..") || lower.startsWith("/") || lower.startsWith("\\")) return false;
        if (lower.endsWith(".class") || lower.endsWith(".jar") || lower.endsWith(".js")
                || lower.endsWith(".sh") || lower.endsWith(".bat") || lower.endsWith(".exe")) {
            return false;
        }
        return lower.endsWith(".json") || lower.endsWith(".png") || lower.endsWith(".mcmeta")
                || lower.endsWith(".fsh") || lower.endsWith(".vsh") || lower.endsWith(".ogg")
                || lower.endsWith(".lrc");
    }

    public static ClientConfig load(Path configFile) {
        Path backupFile = configFile.resolveSibling(configFile.getFileName() + ".bak");
        try {
            if (Files.exists(configFile)) {
                String json = Files.readString(configFile, StandardCharsets.UTF_8);
                ClientConfig cfg = GSON.fromJson(json, ClientConfig.class);
                if (cfg != null) {
                    cfg.validateAndClamp();
                    return cfg;
                }
            }
        } catch (IOException | JsonSyntaxException ex) {
            LOGGER.warn("Primary config invalid or unreadable, attempting backup restore: {}", ex.getMessage());
            try {
                if (Files.exists(backupFile)) {
                    String backupJson = Files.readString(backupFile, StandardCharsets.UTF_8);
                    ClientConfig recovered = GSON.fromJson(backupJson, ClientConfig.class);
                    if (recovered != null) {
                        recovered.validateAndClamp();
                        return recovered;
                    }
                }
            } catch (IOException | JsonSyntaxException backupEx) {
                LOGGER.error("Backup config recovery failed, using safe defaults: {}", backupEx.getMessage());
            }
        }
        ClientConfig defaults = new ClientConfig();
        defaults.validateAndClamp();
        return defaults;
    }

    public void save(Path configFile) {
        validateAndClamp();
        Path backupFile = configFile.resolveSibling(configFile.getFileName() + ".bak");
        Path tempFile = configFile.resolveSibling(configFile.getFileName() + ".tmp");
        try {
            Files.createDirectories(configFile.getParent());
            if (Files.exists(configFile)) {
                Files.copy(configFile, backupFile, StandardCopyOption.REPLACE_EXISTING);
            }
            Files.writeString(tempFile, GSON.toJson(this), StandardCharsets.UTF_8);
            try {
                Files.move(tempFile, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tempFile, configFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            LOGGER.error("Failed to save ItsM3liodas Client configuration: {}", ex.getMessage());
        }
    }

    public String exportJson() {
        validateAndClamp();
        return GSON.toJson(this);
    }

    public static Optional<ClientConfig> importJson(String rawJson) {
        if (rawJson == null || rawJson.isBlank()) return Optional.empty();
        try {
            ClientConfig parsed = GSON.fromJson(rawJson, ClientConfig.class);
            if (parsed == null) return Optional.empty();
            parsed.validateAndClamp();
            return Optional.of(parsed);
        } catch (JsonSyntaxException ex) {
            return Optional.empty();
        }
    }

    private static float clamp(float value, float min, float max) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }

    public static final class HudElementConfig {
        public boolean enabled;
        public float x;
        public float y;
        public float scale;
        public float opacity;
        public String color;
        public String format;
        public boolean locked = false;
        public int decimalPrecision = 1;
        public boolean armorVanillaFrame = false;
        public boolean armorHorizontal = true;
        public boolean armorWarningBadge = true;
        public int lowDurabilityThreshold = 25;

        public HudElementConfig() {}

        public HudElementConfig(boolean enabled, float x, float y, float scale, float opacity, String color, String format) {
            this.enabled = enabled;
            this.x = x;
            this.y = y;
            this.scale = scale;
            this.opacity = opacity;
            this.color = color;
            this.format = format;
        }
    }

    public static final class KeybindEntry {
        public int keyCode;
        public String mode;

        public KeybindEntry() {}

        public KeybindEntry(int keyCode, String mode) {
            this.keyCode = keyCode;
            this.mode = mode;
        }
    }

    public static final class MotionBlurConfig {
        public boolean enabled = false;
        public String preset = "Medium";
        public float intensity = 0.45f;
        public float durationMs = 32.0f;
        public int qualitySamples = 6;
        public boolean cameraBlur = true;
        public boolean guiBlur = false;
        public boolean backgroundBlur = true;
    }

    public static final class MenuBlurConfig {
        public boolean enabled = true;
        public float strength = 10.0f;
        public float dimming = 0.35f;
        public float opacity = 0.88f;
        public boolean smoothTransitions = true;
        public boolean performanceFriendly = false;
        public boolean blurInventory = true;
        public boolean blurClientMenu = true;
    }

    public static final class NametagsConfig {
        public boolean enabled = false;
        public String textColor = "#FFFFFF";
        public String font = "default";
        public float scale = 1.0f;
        public float backgroundOpacity = 0.45f;
        public boolean textShadow = true;
        public boolean showHealthWhenAvailable = true;
        public boolean distanceScaling = true;
    }

    public static final class CrosshairConfig {
        public boolean enabled = false;
        public String preset = "M3liodas Cross";
        public String color = "#FFFFFF";
        public float size = 8.0f;
        public float thickness = 2.0f;
        public float gap = 3.0f;
        public boolean centerDot = true;
        public boolean outline = true;
        public float opacity = 0.95f;
    }

    public static final class BlockOutlineConfig {
        public boolean enabled = false;
        public String preset = "Midnight Neon";
        public String color = "#7C5CFF";
        public float thickness = 2.0f;
        public float opacity = 0.85f;
        public boolean glow = true;
    }

    public static final class ItemPhysicsConfig {
        public boolean enabled = false;
        public boolean rotation = true;
        public float speed = 1.0f;
        public String style = "Flat Lay";
        public int maxAnimatedItems = 64;
    }

    public static final class ColorGradingConfig {
        public boolean enabled = false;
        public String preset = "Natural";
        public float brightness = 1.0f;
        public float contrast = 1.0f;
        public float saturation = 1.0f;
        public float temperature = 0.0f;
        public float gamma = 1.0f;
        public float vignette = 0.15f;
        public String filterColor = "#000000";
        public float filterStrength = 0.0f;
    }

    public static final class VisualPacksConfig {
        public boolean enabled = true;
        public List<String> activePackIds = new ArrayList<>();
    }

    public static final class HandAuraConfig {
        public boolean enabled = false;
        public String style = "Soft Glow";
        public String primaryColor = "#7C5CFF";
        public String secondaryColor = "#38BDF8";
        public float intensity = 0.65f;
        public float size = 1.15f;
        public float transparency = 0.75f;
        public float animationSpeed = 1.0f;
        public int particleAmount = 14;
        public boolean affectHeldItem = true;
        public String quality = "Balanced";
    }

    public static final class ZoomConfig {
        public boolean enabled = true;
        public boolean toggleMode = false;
        public float strength = 4.0f;
        public float transitionSpeed = 10.0f;
        public boolean reduceSensitivity = true;
    }

    public static final class FreelookConfig {
        public boolean enabled = true;
        public boolean toggleMode = false;
        public float horizontalSensitivity = 1.0f;
        public float verticalSensitivity = 1.0f;
        public float maxHorizontalDeg = 180.0f;
        public float maxVerticalDeg = 89.0f;
        public boolean smoothMovement = true;
        public boolean allowThirdPerson = true;
    }

    public static final class ShulkerPreviewConfig {
        public boolean enabled = true;
        public float previewScale = 1.0f;
        public String backgroundStyle = "M3liodas Glass";
        public boolean smoothAnimation = true;
    }

    public static final class ViewmodelConfig {
        public boolean enabled = false;
        public float handX = 0.0f;
        public float handY = 0.0f;
        public float handZ = 0.0f;
        public float itemX = 0.0f;
        public float itemY = 0.0f;
        public float itemZ = 0.0f;
        public float scale = 1.0f;
        public float rotX = 0.0f;
        public float rotY = 0.0f;
        public float rotZ = 0.0f;
        public boolean mirrorLeftHand = false;
    }

    public static final class CosmeticsConfig {
        public boolean enabled = true;
        public Map<String, String> equippedBySlot = new LinkedHashMap<>();
        public String primaryDye = "#7C5CFF";
        public String secondaryDye = "#38BDF8";
        public boolean animationsEnabled = true;
        public float wingFlapSpeed = 1.0f;
        public float wingSpread = 1.0f;
        public String customCapeFile = "";
        public boolean customCapeEnabled = false;
    }

    public static final class ParticleEffectsConfig {
        public boolean enabled = false;
        public String style = "Starlight Sparkles";
        public String primaryColor = "#A78BFA";
        public String secondaryColor = "#38BDF8";
        public float size = 1.0f;
        public float transparency = 0.8f;
        public float speed = 1.0f;
        public int amount = 24;
        public String quality = "Balanced";
        public boolean performanceMode = false;
    }

    public static final class MusicLyricsConfig {
        public boolean enabled = true;
        public boolean showNowPlayingCard = true;
        public boolean showSkyLyrics = true;
        public String lyricPlacement = "sky-center";
        public float lyricX = 50.0f;
        public float lyricY = 20.0f;
        public String lyricFont = "space";
        public float lyricScale = 1.1f;
        public float lyricOpacity = 0.95f;
        public boolean lyricGlow = true;
        public float cardOpacity = 0.85f;
        public String spotifyClientId = "";
    }

    public static final class PerformanceConfig {
        public String preset = "Balanced";
        public boolean reducedParticles = false;
        public boolean lowCostBlur = false;
        public boolean cacheCosmeticMeshes = true;
    }
}
