package com.itsm3liodas.client;

import com.itsm3liodas.client.config.ClientConfig;
import com.itsm3liodas.client.gui.ClientMenuScreen;
import com.itsm3liodas.client.hud.HudManager;
import com.itsm3liodas.client.module.ClientModules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Main Fabric client entrypoint for ItsM3liodas Client (Minecraft 1.21.11).
 */
public final class ItsM3liodasClient implements ClientModInitializer {
    public static final String MOD_ID = "itsm3liodas";
    public static final Logger LOGGER = LoggerFactory.getLogger("itsm3liodas-client");

    private static ClientConfig config;
    private static final ClientModules MODULES = new ClientModules();
    private static final HudManager HUD_MANAGER = new HudManager();
    private static final ExecutorService IO_EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "ItsM3liodas-AsyncIO");
        t.setDaemon(true);
        return t;
    });

    private static KeyBinding menuKey;
    private static KeyBinding zoomKey;
    private static KeyBinding freelookKey;

    @Override
    public void onInitializeClient() {
        Path configPath = getConfigPath();
        config = ClientConfig.load(configPath);

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "keybinds"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itsm3liodas.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itsm3liodas.zoom", GLFW.GLFW_KEY_C, category));
        freelookKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itsm3liodas.freelook", GLFW.GLFW_KEY_LEFT_ALT, category));

        // 1.21.11 HudElementRegistry (replaces deprecated HudRenderCallback)
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.HOTBAR,
                Identifier.of(MOD_ID, "hud_overlay"),
                (drawContext, tickCounter) -> HUD_MANAGER.render(drawContext, tickCounter, config)
        );

        ClientTickEvents.END_CLIENT_TICK.register(ItsM3liodasClient::onClientTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            config.save(getConfigPath());
            IO_EXECUTOR.shutdown();
        });

        LOGGER.info("ItsM3liodas Client initialized for Minecraft 1.21.11 (Java 21)");
    }

    private static void onClientTick(MinecraftClient client) {
        while (menuKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new ClientMenuScreen(config));
            }
        }

        if (config.zoom.toggleMode) {
            while (zoomKey.wasPressed()) {
                MODULES.setZoomActive(!MODULES.isZoomActive());
            }
        } else {
            MODULES.setZoomActive(zoomKey.isPressed());
        }

        if (config.freelook.toggleMode) {
            while (freelookKey.wasPressed()) {
                MODULES.setFreelookActive(!MODULES.isFreelookActive());
            }
        } else {
            MODULES.setFreelookActive(freelookKey.isPressed());
        }

        MODULES.tick(config, 0.05f);
    }

    public static ClientConfig getConfig() {
        return config;
    }

    public static ClientModules getModules() {
        return MODULES;
    }

    public static void saveConfigAsync() {
        Path target = getConfigPath();
        IO_EXECUTOR.submit(() -> config.save(target));
    }

    private static Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("itsm3liodas").resolve("config.json");
    }
}
