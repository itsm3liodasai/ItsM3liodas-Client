package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adjusts camera FOV smoothly when Zoom is active. Does not alter reach or entity culling.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void itsm3liodas$applyZoomFov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.zoom.enabled) return;
        double adjusted = ItsM3liodasClient.getModules().adjustFov(cir.getReturnValue(), cfg);
        cir.setReturnValue((float) adjusted);
    }
}
