package com.itsm3liodas.client.cosmetic;

import com.itsm3liodas.client.config.ClientConfig;

/**
 * Articulated cosmetic animation math & metadata engine for ItsM3liodas Styles (MC 1.21.11).
 * Drives multi-joint flapping wings, billowing capes, orbiting accessories, and shoulder companions.
 * Purely visual — zero impact on player hitboxes, elytra flight speed, or combat.
 */
public final class ClientCosmetics {
    public static final int TOTAL_FREE_COSMETICS = 168;
    public static final int TOTAL_DECORATIVE_WINGS = 24;

    private ClientCosmetics() {}

    public static float computeWingInnerYawDeg(float timeSeconds, ClientConfig.CosmeticsConfig cfg, boolean gliding, boolean sprinting) {
        if (cfg == null || !cfg.enabled) return 0.0f;
        float spreadAngle = (gliding ? 14.0f : 24.0f) * (2.0f - Math.min(1.4f, cfg.wingSpread));
        if (!cfg.animationsEnabled) {
            return spreadAngle;
        }
        float freq = sprinting ? 5.0f : 3.4f;
        float amp = gliding ? 16.0f : (sprinting ? 22.0f : 18.0f);
        return spreadAngle + (float) Math.sin(timeSeconds * cfg.wingFlapSpeed * freq) * amp;
    }

    public static float computeWingOuterFlexDeg(float timeSeconds, ClientConfig.CosmeticsConfig cfg, boolean gliding, boolean sprinting) {
        if (cfg == null || !cfg.enabled || !cfg.animationsEnabled) return 0.0f;
        float freq = sprinting ? 5.0f : 3.4f;
        float amp = (gliding ? 16.0f : (sprinting ? 22.0f : 18.0f)) * 0.85f;
        return (float) Math.sin(timeSeconds * cfg.wingFlapSpeed * freq - 0.85) * amp;
    }

    public static float computeCapeSwingPitchDeg(float timeSeconds, ClientConfig.CosmeticsConfig cfg, boolean gliding, boolean walking) {
        if (cfg == null || !cfg.enabled) return 0.0f;
        float base = gliding ? 42.0f : (walking ? 22.0f : 8.0f);
        if (!cfg.animationsEnabled) return base;
        return base + (float) Math.sin(timeSeconds * 3.2f) * 7.0f;
    }

    public static float computeOrbitAngleDeg(float timeSeconds, ClientConfig.CosmeticsConfig cfg, float speedDegPerSec) {
        if (cfg == null || !cfg.enabled || !cfg.animationsEnabled) return 0.0f;
        return (timeSeconds * speedDegPerSec) % 360.0f;
    }
}
