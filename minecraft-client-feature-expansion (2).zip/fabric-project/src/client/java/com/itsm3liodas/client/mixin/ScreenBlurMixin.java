package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies independent Menu Blur dimming behind supported screens without coupling to Motion Blur.
 */
@Mixin(Screen.class)
public abstract class ScreenBlurMixin {
    @Inject(method = "renderInGameBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void itsm3liodas$customMenuBackdrop(DrawContext context, CallbackInfo ci) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.menuBlur.enabled || !cfg.menuBlur.blurInventory) return;
        int dimAlpha = Math.round(Math.max(0.0f, Math.min(0.9f, cfg.menuBlur.dimming)) * 235);
        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        context.fillGradient(0, 0, width, height, (dimAlpha << 24) | 0x090D1A, (dimAlpha << 24) | 0x05070F);
        ci.cancel();
    }
}
