package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds purely decorative visual rotation/tilt to dropped item rendering on MC 1.21.11 render states.
 */
@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"), require = 0)
    private void itsm3liodas$applyDecorativeItemPhysics(
            ItemEntityRenderState state, MatrixStack matrices,
            OrderedRenderCommandQueue queue, CameraRenderState cameraState, CallbackInfo ci) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.itemPhysics.enabled) return;

        if ("Flat Lay".equalsIgnoreCase(cfg.itemPhysics.style)) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90.0f));
            matrices.translate(0.0, 0.0, -0.06);
        }
        if (cfg.itemPhysics.rotation) {
            float spin = (state.age * 3.0f * cfg.itemPhysics.speed) % 360.0f;
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(spin));
        }
    }
}
