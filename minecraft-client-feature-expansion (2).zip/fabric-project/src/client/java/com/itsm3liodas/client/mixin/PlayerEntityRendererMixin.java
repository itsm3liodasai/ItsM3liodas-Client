package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import com.itsm3liodas.client.cosmetic.ClientCosmetics;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Hook anchor for decorative Nametag styling and ItsM3liodas Styles articulated cosmetic layer.
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    protected boolean itsm3liodas$shouldScaleNametag() {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        return cfg != null && cfg.nametags.enabled && cfg.nametags.distanceScaling;
    }

    protected float itsm3liodas$computeActiveWingFlap(float timeSeconds, boolean gliding, boolean sprinting) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null) return 0.0f;
        return ClientCosmetics.computeWingInnerYawDeg(timeSeconds, cfg.cosmetics, gliding, sprinting);
    }
}
