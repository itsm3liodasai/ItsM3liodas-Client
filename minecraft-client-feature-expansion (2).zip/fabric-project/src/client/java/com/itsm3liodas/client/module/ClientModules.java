package com.itsm3liodas.client.module;

import com.itsm3liodas.client.config.ClientConfig;

/**
 * Runtime state machine and math helpers for ItsM3liodas Client modules.
 * Every feature is strictly visual / camera-only and independently toggleable.
 */
public final class ClientModules {
    private boolean zoomActive = false;
    private float currentZoomProgress = 0.0f;

    private boolean freelookActive = false;
    private float freelookYawOffset = 0.0f;
    private float freelookPitchOffset = 0.0f;
    private float targetFreelookYaw = 0.0f;
    private float targetFreelookPitch = 0.0f;

    public void tick(ClientConfig cfg, float frameDeltaSeconds) {
        float zoomTarget = (cfg.zoom.enabled && zoomActive) ? 1.0f : 0.0f;
        float speed = Math.max(1.0f, cfg.zoom.transitionSpeed);
        currentZoomProgress += (zoomTarget - currentZoomProgress) * Math.min(1.0f, frameDeltaSeconds * speed);
        if (Math.abs(zoomTarget - currentZoomProgress) < 0.001f) {
            currentZoomProgress = zoomTarget;
        }

        if (!cfg.freelook.enabled || !freelookActive) {
            targetFreelookYaw = 0.0f;
            targetFreelookPitch = 0.0f;
        }
        float lookSmooth = cfg.freelook.smoothMovement ? Math.min(1.0f, frameDeltaSeconds * 16.0f) : 1.0f;
        freelookYawOffset += (targetFreelookYaw - freelookYawOffset) * lookSmooth;
        freelookPitchOffset += (targetFreelookPitch - freelookPitchOffset) * lookSmooth;
    }

    public void setZoomActive(boolean active) {
        this.zoomActive = active;
    }

    public boolean isZoomActive() {
        return zoomActive;
    }

    public double adjustFov(double baseFov, ClientConfig cfg) {
        if (!cfg.zoom.enabled || currentZoomProgress <= 0.001f) {
            return baseFov;
        }
        double targetFov = baseFov / Math.max(1.2, cfg.zoom.strength);
        return baseFov + (targetFov - baseFov) * currentZoomProgress;
    }

    public double adjustMouseSensitivity(double baseSensitivity, ClientConfig cfg) {
        if (cfg.zoom.enabled && cfg.zoom.reduceSensitivity && currentZoomProgress > 0.05f) {
            double divisor = 1.0 + (cfg.zoom.strength - 1.0) * 0.65 * currentZoomProgress;
            return baseSensitivity / divisor;
        }
        return baseSensitivity;
    }

    public void setFreelookActive(boolean active) {
        this.freelookActive = active;
        if (!active) {
            this.targetFreelookYaw = 0.0f;
            this.targetFreelookPitch = 0.0f;
        }
    }

    public boolean isFreelookActive() {
        return freelookActive;
    }

    public void applyFreelookDelta(float deltaYaw, float deltaPitch, ClientConfig cfg) {
        if (!cfg.freelook.enabled || !freelookActive) return;
        float maxYaw = cfg.freelook.maxHorizontalDeg;
        float maxPitch = cfg.freelook.maxVerticalDeg;
        targetFreelookYaw = clamp(targetFreelookYaw + deltaYaw * cfg.freelook.horizontalSensitivity, -maxYaw, maxYaw);
        targetFreelookPitch = clamp(targetFreelookPitch + deltaPitch * cfg.freelook.verticalSensitivity, -maxPitch, maxPitch);
    }

    public float getFreelookYawOffset() {
        return freelookYawOffset;
    }

    public float getFreelookPitchOffset() {
        return freelookPitchOffset;
    }

    public boolean hasActiveFreelookOffset() {
        return Math.abs(freelookYawOffset) > 0.05f || Math.abs(freelookPitchOffset) > 0.05f;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
