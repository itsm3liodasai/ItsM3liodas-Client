package com.itsm3liodas.client.mixin;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces vanilla crosshair rendering with the customizable ItsM3liodas crosshair when enabled.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void itsm3liodas$renderCustomCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        ClientConfig cfg = ItsM3liodasClient.getConfig();
        if (cfg == null || !cfg.crosshair.enabled || client.options.hudHidden) {
            return;
        }
        ci.cancel();

        int cx = context.getScaledWindowWidth() / 2;
        int cy = context.getScaledWindowHeight() / 2;
        int size = Math.round(cfg.crosshair.size);
        int thick = Math.max(1, Math.round(cfg.crosshair.thickness));
        int gap = Math.round(cfg.crosshair.gap);
        int alpha = Math.round(cfg.crosshair.opacity * 255.0f);
        int rgb = parseRgb(cfg.crosshair.color, 0xFFFFFF);
        int argb = (alpha << 24) | rgb;
        int halfT = thick / 2;

        if (cfg.crosshair.outline) {
            int out = (alpha << 24);
            context.fill(cx - halfT - 1, cy - gap - size - 1, cx - halfT + thick + 1, cy - gap + 1, out);
            context.fill(cx - halfT - 1, cy + gap - 1, cx - halfT + thick + 1, cy + gap + size + 1, out);
            context.fill(cx - gap - size - 1, cy - halfT - 1, cx - gap + 1, cy - halfT + thick + 1, out);
            context.fill(cx + gap - 1, cy - halfT - 1, cx + gap + size + 1, cy - halfT + thick + 1, out);
        }

        context.fill(cx - halfT, cy - gap - size, cx - halfT + thick, cy - gap, argb);
        context.fill(cx - halfT, cy + gap, cx - halfT + thick, cy + gap + size, argb);
        context.fill(cx - gap - size, cy - halfT, cx - gap, cy - halfT + thick, argb);
        context.fill(cx + gap, cy - halfT, cx + gap + size, cy - halfT + thick, argb);

        if (cfg.crosshair.centerDot) {
            context.fill(cx - halfT, cy - halfT, cx - halfT + thick, cy - halfT + thick, argb);
        }
    }

    private static int parseRgb(String hex, int fallback) {
        try {
            String s = hex.startsWith("#") ? hex.substring(1) : hex;
            return Integer.parseInt(s, 16) & 0x00FFFFFF;
        } catch (Exception e) {
            return fallback;
        }
    }
}
