package com.itsm3liodas.client.gui;

import com.itsm3liodas.client.ItsM3liodasClient;
import com.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/**
 * In-game client menu screen for ItsM3liodas Client (MC 1.21.11).
 * Uses independent Menu Blur settings and persists changes automatically on close.
 */
public final class ClientMenuScreen extends Screen {
    private final ClientConfig config;

    public ClientMenuScreen(ClientConfig config) {
        super(Text.literal("ItsM3liodas Client"));
        this.config = config;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Motion Blur: " + (config.motionBlur.enabled ? "ON" : "OFF")),
                btn -> {
                    config.motionBlur.enabled = !config.motionBlur.enabled;
                    btn.setMessage(Text.literal("Motion Blur: " + (config.motionBlur.enabled ? "ON" : "OFF")));
                }).dimensions(cx - 160, cy - 60, 150, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Menu Blur: " + (config.menuBlur.enabled ? "ON" : "OFF")),
                btn -> {
                    config.menuBlur.enabled = !config.menuBlur.enabled;
                    btn.setMessage(Text.literal("Menu Blur: " + (config.menuBlur.enabled ? "ON" : "OFF")));
                }).dimensions(cx + 10, cy - 60, 150, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Custom Crosshair: " + (config.crosshair.enabled ? "ON" : "OFF")),
                btn -> {
                    config.crosshair.enabled = !config.crosshair.enabled;
                    btn.setMessage(Text.literal("Custom Crosshair: " + (config.crosshair.enabled ? "ON" : "OFF")));
                }).dimensions(cx - 160, cy - 32, 150, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Music Lyrics HUD: " + (config.musicLyrics.enabled ? "ON" : "OFF")),
                btn -> {
                    config.musicLyrics.enabled = !config.musicLyrics.enabled;
                    btn.setMessage(Text.literal("Music Lyrics HUD: " + (config.musicLyrics.enabled ? "ON" : "OFF")));
                }).dimensions(cx + 10, cy - 32, 150, 20).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Save & Close"),
                btn -> close()).dimensions(cx - 75, cy + 48, 150, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (config.menuBlur.enabled && config.menuBlur.blurClientMenu) {
            int dimAlpha = Math.round(config.menuBlur.dimming * 200);
            context.fill(0, 0, this.width, this.height, (dimAlpha << 24) | 0x060812);
        }
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 90, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        ItsM3liodasClient.saveConfigAsync();
        super.close();
    }
}
