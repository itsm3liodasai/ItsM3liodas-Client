import { MusicTrack, SyncedLyricLine } from '../types/client';

export const BUILTIN_SYNCED_TRACKS: MusicTrack[] = [
  {
    id: 'track_starlight_horizon',
    title: 'Starlight Horizon',
    artist: 'ItsM3liodas Sessions',
    album: 'Twilight PvP Vol. 1',
    durationSec: 48,
    coverColors: ['#7C5CFF', '#38BDF8', '#0F172A'],
    bpm: 124,
    lyrics: [
      { timeSec: 0, text: 'Sky turns violet over cubic hills' },
      { timeSec: 4, text: 'Diamond blade catching lunar chills' },
      { timeSec: 8, text: 'Steps echo across deepslate stone' },
      { timeSec: 12, text: 'Gliding high where the beacons shone' },
      { timeSec: 16, text: 'Wings unfold in the midnight breeze' },
      { timeSec: 20, text: 'Cherry petals drift above the trees' },
      { timeSec: 24, text: 'Hold the rhythm through the endless sky' },
      { timeSec: 28, text: 'Watch the constellation banners fly' },
      { timeSec: 32, text: 'Every block framed in neon light' },
      { timeSec: 36, text: 'Synced lyrics glowing crystal bright' },
      { timeSec: 40, text: 'Carry forward till the morning sun' },
      { timeSec: 44, text: 'Starlight horizon has just begun' },
    ],
  },
  {
    id: 'track_sakura_drift',
    title: 'Sakura Drift (Chill Mix)',
    artist: 'Hana & M3liodas',
    album: 'Blossom Biome',
    durationSec: 42,
    coverColors: ['#F472B6', '#C084FC', '#1E1122'],
    bpm: 96,
    lyrics: [
      { timeSec: 0, text: 'Soft pink blossoms falling slow' },
      { timeSec: 4, text: 'Floating lanterns in a quiet row' },
      { timeSec: 8, text: 'Water mirrors every distant star' },
      { timeSec: 12, text: 'No need to wonder where we are' },
      { timeSec: 16, text: 'Gentle bassline hums beneath the sky' },
      { timeSec: 20, text: 'Paper wings go drifting quietly by' },
      { timeSec: 25, text: 'Warm glow across the valley floor' },
      { timeSec: 30, text: 'Stay in this moment a little more' },
      { timeSec: 36, text: 'Fading softly into sakura dawn' },
    ],
  },
  {
    id: 'track_cyber_arena',
    title: 'Neon Velocity',
    artist: 'Valence Pulse',
    album: '1.21 Overdrive',
    durationSec: 40,
    coverColors: ['#06B6D4', '#EC4899', '#090D16'],
    bpm: 138,
    lyrics: [
      { timeSec: 0, text: 'Pulse ignites on the neon grid' },
      { timeSec: 4, text: 'Zero lag in the moves we did' },
      { timeSec: 8, text: 'Lock the armor, feel the beat drop' },
      { timeSec: 12, text: 'Climbing towers to the very top' },
      { timeSec: 16, text: 'Cyber thrusters burning bright cyan' },
      { timeSec: 20, text: 'Fastest rhythm since the match began' },
      { timeSec: 25, text: 'Basslines shimmering across the HUD' },
      { timeSec: 30, text: 'Electric fire in the circuit flood' },
      { timeSec: 35, text: 'One last combo as the chorus rings' },
    ],
  },
];

export function parseLrcLyrics(rawLrc: string): SyncedLyricLine[] {
  const lines: SyncedLyricLine[] = [];
  const regex = /\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]\s*(.*)/;
  for (const rawLine of rawLrc.split(/\r?\n/)) {
    const match = rawLine.match(regex);
    if (!match) continue;
    const min = parseInt(match[1], 10);
    const sec = parseInt(match[2], 10);
    const frac = match[3] ? parseInt(match[3].padEnd(3, '0').slice(0, 3), 10) / 1000 : 0;
    const text = match[4].trim();
    if (text) {
      lines.push({ timeSec: min * 60 + sec + frac, text });
    }
  }
  return lines.sort((a, b) => a.timeSec - b.timeSec);
}

export async function fetchSyncedLyricsAsync(artist: string, title: string): Promise<SyncedLyricLine[] | null> {
  try {
    const url = `https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(title)}`;
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) return null;
    const data = (await res.json()) as { syncedLyrics?: string; plainLyrics?: string };
    if (data.syncedLyrics) {
      const parsed = parseLrcLyrics(data.syncedLyrics);
      if (parsed.length > 0) return parsed;
    }
    if (data.plainLyrics) {
      return data.plainLyrics
        .split(/\r?\n/)
        .filter((l) => l.trim().length > 0)
        .slice(0, 24)
        .map((text, idx) => ({ timeSec: idx * 3.5, text: text.trim() }));
    }
    return null;
  } catch {
    return null;
  }
}
