import { CosmeticCategory, CosmeticItem, OutfitPreset } from '../types/client';

export const COSMETIC_CATEGORY_LABELS: Record<CosmeticCategory, string> = {
  hats: 'Hats',
  headAccessories: 'Head Accessories',
  masks: 'Masks',
  capes: 'Capes',
  wings: 'Decorative Wings',
  shoulderAccessories: 'Shoulder Accessories',
  backAccessories: 'Back Accessories',
  footwear: 'Footwear',
  outfitOverlays: 'Outfit Overlays',
};

interface RawEntry {
  name: string;
  rarity: CosmeticItem['rarity'];
  desc: string;
  compat: string;
  anim: CosmeticItem['animationType'];
  c1: string;
  c2: string;
}

function buildCategory(
  category: CosmeticCategory,
  prefix: string,
  entries: RawEntry[]
): CosmeticItem[] {
  return entries.map((e, idx) => ({
    id: `${prefix}_${idx + 1}_${e.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`,
    name: e.name,
    category,
    rarity: e.rarity,
    description: e.desc,
    compatibilityNote: e.compat,
    animationType: e.anim,
    defaultPrimary: e.c1,
    defaultSecondary: e.c2,
    shapeVariant: idx,
    free: true,
    author: 'ItsM3liodas Studio',
  }));
}

const HATS: RawEntry[] = [
  { name: 'Crown of Midnight', rarity: 'Signature', desc: 'Regal obsidian crown inlaid with glowing star-violet spires.', compat: 'Renders above player hat layer; compatible with masks.', anim: 'Pulse', c1: '#7C5CFF', c2: '#E2E8F0' },
  { name: 'Astral Mage Spire', rarity: 'Rare', desc: 'Wide-brimmed velvet wizard hat tilted slightly with an orbiting star charm.', compat: 'Clips slightly with tall head accessories.', anim: 'Float', c1: '#4F46E5', c2: '#FBBF24' },
  { name: 'Crimson Ronin Kabuto', rarity: 'Mythic', desc: 'Ceremonial samurai crest helmet with sweeping crescent horns.', compat: 'Visual overlay only; does not alter armor hitbox.', anim: 'Static', c1: '#DC2626', c2: '#F59E0B' },
  { name: 'Cozy Cloud Beanie', rarity: 'Common', desc: 'Soft ribbed knit cap with a folded cuff and woven M3liodas tag.', compat: 'Works cleanly with all masks and glasses.', anim: 'Static', c1: '#38BDF8', c2: '#F8FAFC' },
  { name: 'Blossom Sunhat', rarity: 'Rare', desc: 'Woven wide brim hat tied with trailing sakura silk ribbons.', compat: 'Ribbons flutter gently while moving.', anim: 'Flutter', c1: '#F472B6', c2: '#FFF1F2' },
  { name: 'Explorer Canvas Fedora', rarity: 'Common', desc: 'Classic adventurer brimmed hat with stitched leather band.', compat: 'Compatible with all masks and head accessories.', anim: 'Static', c1: '#92400E', c2: '#FDE68A' },
  { name: 'Frost Queen Tiara', rarity: 'Mythic', desc: 'Crystalline glacial spikes radiating subtle frost shimmer.', compat: 'Pairs cleanly with Arctic capes and masks.', anim: 'Pulse', c1: '#67E8F9', c2: '#EFF6FF' },
  { name: 'Steampunk Brass Tophat', rarity: 'Rare', desc: 'Tall charcoal top hat fitted with decorative brass gears and goggles.', compat: 'Occupies hat slot; leaves face free for masks.', anim: 'Orbit', c1: '#B45309', c2: '#334155' },
  { name: 'Cyber Visor Cap', rarity: 'Rare', desc: 'Sleek forward-angled street cap with luminous neon rim strip.', compat: 'Works with Cyber Respirator and neon masks.', anim: 'Pulse', c1: '#0F172A', c2: '#22D3EE' },
  { name: 'Valkyrie Winged Helm', rarity: 'Mythic', desc: 'Silver plated crest flanked by delicate miniature fluttering wing feathers.', compat: 'Pairs with Seraph Feathered Wings.', anim: 'Flutter', c1: '#E2E8F0', c2: '#FACC15' },
  { name: 'Witch Twilight Brim', rarity: 'Rare', desc: 'Deep dusk-purple wide brim with crescent buckle.', compat: 'Compatible with facial masks.', anim: 'Float', c1: '#6D28D9', c2: '#34D399' },
  { name: 'Velvet Star Beret', rarity: 'Common', desc: 'Minimalist tilted artist beret pinned with a twin-star emblem.', compat: 'Zero clipping across slim and classic skins.', anim: 'Static', c1: '#BE185D', c2: '#FDE047' },
  { name: 'Phantom Hood Cowl', rarity: 'Rare', desc: 'Draped nocturnal ranger hood casting a mysterious dark brow shadow.', compat: 'Matches Phantom Half-Mask and Abyssal capes.', anim: 'Wave', c1: '#1E1B4B', c2: '#8B5CF6' },
  { name: 'Solar Emperor Diadem', rarity: 'Signature', desc: 'Radiant gilded circlet crowning a suspended miniature sun crystal.', compat: 'Stacks smoothly with halos.', anim: 'Pulse', c1: '#F59E0B', c2: '#FEF08A' },
  { name: 'Kitsune Shrine Ushanka', rarity: 'Common', desc: 'Plush winter fur hat pinned with lucky crimson shrine bells.', compat: 'Bells sway softly while sprinting.', anim: 'Flutter', c1: '#F8FAFC', c2: '#EF4444' },
  { name: 'Astronaut Void Helmet', rarity: 'Mythic', desc: 'Reflective curved obsidian visor dome with glowing cyan HUD arc.', compat: 'Occupies both hat and upper mask visual area.', anim: 'Pulse', c1: '#334155', c2: '#22D3EE' },
  { name: 'Emerald Archdruid Hood', rarity: 'Rare', desc: 'Moss-woven woodland cowl braided with golden ivy sprouts.', compat: 'Pairs cleanly with Emerald Leaf-Wings.', anim: 'Wave', c1: '#065F46', c2: '#4ADE80' },
  { name: 'Dragonborn Horned Crown', rarity: 'Signature', desc: 'Forged blackened steel circlet sprouting jagged obsidian crests.', compat: 'Matches Obsidian Dragon Wings.', anim: 'Pulse', c1: '#18181B', c2: '#A855F7' },
];

const HEAD_ACCESSORIES: RawEntry[] = [
  { name: 'Celestial Starlight Halo', rarity: 'Signature', desc: 'Floating luminous ring hovering cleanly above the head.', compat: 'Stackable visually with most low-profile hats.', anim: 'Float', c1: '#FDE047', c2: '#A78BFA' },
  { name: 'Obsidian Rift Horns', rarity: 'Mythic', desc: 'Curved crystalline horns glowing at the tips with violet energy.', compat: 'Compatible with masks and capes.', anim: 'Pulse', c1: '#1E1B4B', c2: '#8B5CF6' },
  { name: 'Golden Laurel Wreath', rarity: 'Rare', desc: 'Twin olive-leaf victory crowns wrapping softly around the brow.', compat: 'Works cleanly without obscuring hairstyles.', anim: 'Static', c1: '#F59E0B', c2: '#FEF3C7' },
  { name: 'Starlight Twin Antennae', rarity: 'Common', desc: 'Playful bobbing luminous orbs mounted on slender curved stems.', compat: 'Lightweight geometry; zero performance cost.', anim: 'Flutter', c1: '#38BDF8', c2: '#C084FC' },
  { name: 'Kitsune Fox Ears', rarity: 'Rare', desc: 'Pointed tufted fox ears with subtle organic twitch animation.', compat: 'Pairs naturally with Kitsune Fox Mask.', anim: 'Flutter', c1: '#F97316', c2: '#FFF7ED' },
  { name: 'Abyssal Dragon Fin', rarity: 'Mythic', desc: 'Sleek dorsal ridge fins sweeping back from the forehead.', compat: 'Matches Abyssal Rift outfits.', anim: 'Pulse', c1: '#0F172A', c2: '#EF4444' },
  { name: 'Orbiting Runic Prism', rarity: 'Signature', desc: 'Three geometric crystals circling continuously around the crown.', compat: 'Independent orbit physics; works with all caps.', anim: 'Orbit', c1: '#22D3EE', c2: '#818CF8' },
  { name: 'Midnight Cat Ears', rarity: 'Common', desc: 'Crisp triangular feline ears with glowing inner accents that twitch.', compat: 'Compatible with Neon Synth Headset or masks.', anim: 'Flutter', c1: '#1E293B', c2: '#F472B6' },
  { name: 'Lunar Crescent Crown', rarity: 'Rare', desc: 'Suspended silver crescent moon poised above the forehead.', compat: 'Matches M3liodas Nebula Cape.', anim: 'Float', c1: '#E2E8F0', c2: '#6366F1' },
  { name: 'Sakura Blossom Hairpin', rarity: 'Common', desc: 'Twin carved cherry blossoms tucked neatly beside the temple.', compat: 'Ultra-clean minimal accessory.', anim: 'Flutter', c1: '#FB7185', c2: '#FEF08A' },
  { name: 'Seraph Ear Winglets', rarity: 'Rare', desc: 'Mini feathered winglets flapping beside both sides of the head.', compat: 'Works with halos and tiaras.', anim: 'Flutter', c1: '#F8FAFC', c2: '#38BDF8' },
  { name: 'Neon Synth Headset', rarity: 'Rare', desc: 'Studio over-ear headphones with pulsing equalizer earcups.', compat: 'Matches Valence-style Music Lyrics HUD aesthetic.', anim: 'Pulse', c1: '#0F172A', c2: '#A855F7' },
  { name: 'Twin Flame Halos', rarity: 'Signature', desc: 'Counter-rotating solar rings flickering above the player crown.', compat: 'Pairs dramatically with Phoenix Flame Wings.', anim: 'Orbit', c1: '#EF4444', c2: '#FACC15' },
  { name: 'Frost Antler Crown', rarity: 'Mythic', desc: 'Branching crystalline ice antlers glittering softly in daylight.', compat: 'Matches Arctic Aurora Warden look.', anim: 'Float', c1: '#BAE6FD', c2: '#0EA5E9' },
  { name: 'Butterfly Hair Swarm', rarity: 'Rare', desc: 'Three tiny glowing prism butterflies orbiting around your hair.', compat: 'Independent gentle flutter flight path.', anim: 'Orbit', c1: '#F472B6', c2: '#38BDF8' },
  { name: 'Cyber Holo-Monocle', rarity: 'Common', desc: 'Floating translucent targeting grid reticle beside the right eye.', compat: 'Strictly decorative; provides zero aim help.', anim: 'Pulse', c1: '#22D3EE', c2: '#0F172A' },
  { name: 'Demon Onyx Horns', rarity: 'Mythic', desc: 'Sweeping swept-back onyx horns wrapped with molten ember veins.', compat: 'Pairs with Reaper & Dragon wings.', anim: 'Pulse', c1: '#27272A', c2: '#F97316' },
  { name: 'Cloud Nimbus Puff', rarity: 'Common', desc: 'Fluffy miniature cumulus cloud drifting calmly above your head.', compat: 'Zero clipping; adorable bobbing motion.', anim: 'Float', c1: '#F8FAFC', c2: '#94A3B8' },
];

const MASKS: RawEntry[] = [
  { name: 'Kitsune Spirit Mask', rarity: 'Signature', desc: 'Porcelain fox mask painted with crimson and gold spirit markings.', compat: 'Covers upper face; leaves mouth or side hair visible.', anim: 'Static', c1: '#F8FAFC', c2: '#EF4444' },
  { name: 'Phantom Half-Mask', rarity: 'Rare', desc: 'Sleek asymmetric midnight mask leaving one eye revealed.', compat: 'Compatible with almost all hats.', anim: 'Pulse', c1: '#1E1B4B', c2: '#7C5CFF' },
  { name: 'Oni Crimson Visor', rarity: 'Mythic', desc: 'Sculpted lower-jaw oni fangs with glowing ember vents.', compat: 'Pairs cleanly with Ronin Kabuto.', anim: 'Pulse', c1: '#991B1B', c2: '#FBBF24' },
  { name: 'Cyber Holo Respirator', rarity: 'Rare', desc: 'Tactical lower-face mask with illuminated cyan filter grille.', compat: 'Pairs with Cyber Visor Cap.', anim: 'Pulse', c1: '#0F172A', c2: '#06B6D4' },
  { name: 'Blossom Silk Veil', rarity: 'Common', desc: 'Translucent embroidered sakura veil draped softly below the eyes.', compat: 'Gentle cloth sway animation.', anim: 'Wave', c1: '#F472B6', c2: '#FCE7F3' },
  { name: 'Venetian Star Masquerade', rarity: 'Rare', desc: 'Ornate gold-filigree masquerade eye mask with starlight trim.', compat: 'Lightweight overlay; works with berets and crowns.', anim: 'Static', c1: '#F59E0B', c2: '#312E81' },
  { name: 'Void Watcher Goggles', rarity: 'Signature', desc: 'Twin circular brass-and-obsidian lenses glowing deep violet.', compat: 'Visual tint is external only; does not change camera vision.', anim: 'Pulse', c1: '#312E81', c2: '#C084FC' },
  { name: 'Arctic Glacier Goggles', rarity: 'Common', desc: 'Reflective icy-blue mountain goggles with frosted frame.', compat: 'Pairs naturally with Cozy Beanie.', anim: 'Static', c1: '#0EA5E9', c2: '#E0F2FE' },
  { name: 'Alchemist Beak Mask', rarity: 'Rare', desc: 'Stylized dark-leather apothecary mask with brass lens rims.', compat: 'Best worn without front-heavy helmets.', anim: 'Static', c1: '#27272A', c2: '#D97706' },
  { name: 'Shadow Shinobi Cowl', rarity: 'Common', desc: 'Streamlined dark cloth face wrap with subtle stitch trim.', compat: 'Minimal profile; fits under any hat.', anim: 'Static', c1: '#18181B', c2: '#64748B' },
  { name: 'Runic Mystic Blindfold', rarity: 'Mythic', desc: 'Embroidered silk band glowing with ancient rune glyphs.', compat: 'Cosmetic only; never affects player screen visibility.', anim: 'Pulse', c1: '#4C1D95', c2: '#38BDF8' },
  { name: 'Sun Pharaoh Gold Mask', rarity: 'Mythic', desc: 'Lapis-and-gold ceremonial lower mask with geometric inlays.', compat: 'Works with Laurels and Crowns.', anim: 'Static', c1: '#EAB308', c2: '#1D4ED8' },
  { name: 'Neon Synth Visor', rarity: 'Signature', desc: 'Full wraparound LED visor scrolling vibrant futuristic bars.', compat: 'Supports primary/accent dye colors.', anim: 'Pulse', c1: '#0F172A', c2: '#EC4899' },
  { name: 'Frost Spirit Half-Mask', rarity: 'Rare', desc: 'Translucent glacier shard lower mask breathing cold vapor.', compat: 'Matches Frost Icicle Wings.', anim: 'Float', c1: '#E0F2FE', c2: '#38BDF8' },
  { name: 'Steampunk Brass Goggles', rarity: 'Common', desc: 'Twin riveted copper eyewear lenses with warm amber glass.', compat: 'Matches Brass Tophat & Brass Wings.', anim: 'Static', c1: '#B45309', c2: '#FBBF24' },
  { name: 'Valkyrie Cheek Plates', rarity: 'Rare', desc: 'Silver filigree cheek guards leaving eyes bright and clear.', compat: 'Matches Valkyrie Helm & Blade-Wings.', anim: 'Static', c1: '#E2E8F0', c2: '#38BDF8' },
  { name: 'Reaper Skull Half-Jaw', rarity: 'Mythic', desc: 'Carved ivory bone lower jaw mask framed in dark obsidian.', compat: 'Matches Reaper Bone-Wings.', anim: 'Pulse', c1: '#F1F5F9', c2: '#334155' },
  { name: 'Starlight Scarf Wrap', rarity: 'Common', desc: 'Cozy layered night-sky neck scarf tucked up over the chin.', compat: 'Cloth ends flutter slightly while walking.', anim: 'Wave', c1: '#1E293B', c2: '#818CF8' },
];

const CAPES: RawEntry[] = [
  { name: 'M3liodas Nebula Cape', rarity: 'Signature', desc: 'Deep cosmos cloak shimmering with animated parallax starlight.', compat: 'Smooth cloth curve; supports Elytra fallback preview.', anim: 'Wave', c1: '#1E1B4B', c2: '#8B5CF6' },
  { name: 'Midnight Crescent Cloak', rarity: 'Rare', desc: 'Velvet obsidian mantle emblazoned with a silver crescent moon.', compat: 'Standard cape slot.', anim: 'Wave', c1: '#090D16', c2: '#E2E8F0' },
  { name: 'Blossom Petal Banner', rarity: 'Rare', desc: 'Soft pastel rose cloak adorned with drifting cherry petals.', compat: 'Pairs cleanly with Blossom Wing overlays.', anim: 'Wave', c1: '#F472B6', c2: '#FFF1F2' },
  { name: 'Ocean Tide Mantle', rarity: 'Common', desc: 'Deep sapphire-to-aqua gradient cape echoing rolling waves.', compat: 'Matches Ocean theme palette.', anim: 'Wave', c1: '#0369A1', c2: '#22D3EE' },
  { name: 'Crimson Monarch Cape', rarity: 'Mythic', desc: 'Regal scarlet cloak bordered by golden filigree trim.', compat: 'Classic royal silhouette.', anim: 'Wave', c1: '#991B1B', c2: '#FBBF24' },
  { name: 'Arctic Aurora Cape', rarity: 'Rare', desc: 'Curtain of northern lights flowing in emerald and ice blue.', compat: 'Animated color wave.', anim: 'Wave', c1: '#0F172A', c2: '#34D399' },
  { name: 'Emerald Rune Cloak', rarity: 'Common', desc: 'Forest-moss cloak etched with glowing druid sigils.', compat: 'Compatible with Back Accessories.', anim: 'Wave', c1: '#065F46', c2: '#6EE7B7' },
  { name: 'Abyssal Rift Cloak', rarity: 'Mythic', desc: 'Tattered-edge void obsidian cloak crackling with magenta veins.', compat: 'Matches Abyss theme.', anim: 'Wave', c1: '#18181B', c2: '#EC4899' },
  { name: 'Golden Sunburst Cape', rarity: 'Rare', desc: 'Radiant solar banner displaying a crisp geometric sun emblem.', compat: 'High-contrast crisp pixel motif.', anim: 'Wave', c1: '#D97706', c2: '#FEF08A' },
  { name: 'Cyber Grid Cape', rarity: 'Rare', desc: 'Matte carbon cloak projected with neon horizon grid lines.', compat: 'Glow intensity respects performance settings.', anim: 'Wave', c1: '#0F172A', c2: '#06B6D4' },
  { name: 'Starfield Constellation Cape', rarity: 'Signature', desc: 'Astronomical indigo cloak linking bright celestial star nodes.', compat: 'Clean silhouette with all armor.', anim: 'Wave', c1: '#1E293B', c2: '#A5B4FC' },
  { name: 'Minimalist Monogram Cape', rarity: 'Common', desc: 'Tailored matte slate cloak featuring the clean ItsM3liodas "M" crest.', compat: 'Universal sleek everyday cloak.', anim: 'Wave', c1: '#1E293B', c2: '#7C5CFF' },
  { name: 'Phoenix Ember Shroud', rarity: 'Mythic', desc: 'Flowing gradient crimson-to-gold mantle with glowing cinder hem.', compat: 'Matches Phoenix Flame Wings.', anim: 'Wave', c1: '#B91C1C', c2: '#FACC15' },
  { name: 'Prism Iridescent Cloak', rarity: 'Signature', desc: 'Holographic crystal cloak shifting softly across pastel spectrums.', compat: 'Dynamic cloth articulation.', anim: 'Wave', c1: '#8B5CF6', c2: '#22D3EE' },
  { name: 'Split-Tail Assassin Cloak', rarity: 'Rare', desc: 'Twin-tailed charcoal ranger cloak designed for agile movement.', compat: 'Sways independently on each tail.', anim: 'Wave', c1: '#18181B', c2: '#64748B' },
  { name: 'Sakura Silk Haori Cape', rarity: 'Common', desc: 'Pale rose ceremonial drape bordered with crisp white clouds.', compat: 'Pairs naturally with Blossom sets.', anim: 'Wave', c1: '#FB7185', c2: '#FFF1F2' },
  { name: 'Thunderstorm Arc Cape', rarity: 'Mythic', desc: 'Dark slate storm mantle illuminated by crackling electric streaks.', compat: 'Pairs with Storm Lightning Wings.', anim: 'Wave', c1: '#0F172A', c2: '#38BDF8' },
  { name: 'Valkyrie Alabaster Mantle', rarity: 'Rare', desc: 'Pure ivory ceremonial cape clasped with golden shoulder pins.', compat: 'Pairs with Seraph & Valkyrie Wings.', anim: 'Wave', c1: '#F8FAFC', c2: '#EAB308' },
];

const WINGS: RawEntry[] = [
  { name: 'Seraph Feathered Wings', rarity: 'Signature', desc: 'Articulated multi-joint angelic pinions that flap organically in 3D.', compat: 'Visual only; does not grant flight or alter Elytra stats.', anim: 'Flutter', c1: '#F8FAFC', c2: '#C4B5FD' },
  { name: 'Obsidian Dragon Wings', rarity: 'Mythic', desc: 'Sweeping membrane dragon wings with hinged outer claw tips.', compat: 'Folds neatly while idle; spreads wide while gliding.', anim: 'Flutter', c1: '#18181B', c2: '#7C5CFF' },
  { name: 'Monarch Butterfly Wings', rarity: 'Rare', desc: 'Upper and lower stained-glass butterfly wings fluttering smoothly.', compat: 'Realistic double-lobe butterfly wing beat.', anim: 'Flutter', c1: '#F97316', c2: '#1E1B4B' },
  { name: 'Cyber Mech Thrusters', rarity: 'Mythic', desc: 'Articulated twin aero-fins flexing dynamically with cyan plasma vents.', compat: 'Matches Cyber outfit overlays.', anim: 'Pulse', c1: '#1E293B', c2: '#22D3EE' },
  { name: 'Crystal Fairy Wings', rarity: 'Rare', desc: 'Translucent multi-faceted prism wings fluttering rapidly.', compat: 'Works nicely with Blossom & Frost sets.', anim: 'Flutter', c1: '#A78BFA', c2: '#67E8F9' },
  { name: 'Phoenix Flame Wings', rarity: 'Signature', desc: 'Sweeping layered fire plumes pulsing from crimson core to gold tips.', compat: 'Reduced particle count in Performance Mode.', anim: 'Flutter', c1: '#EF4444', c2: '#FACC15' },
  { name: 'Void Bat Wings', rarity: 'Common', desc: 'Compact nocturnal leathery wings with articulated wing ribs.', compat: 'Compact profile prevents screen clutter in F5.', anim: 'Flutter', c1: '#27272A', c2: '#A855F7' },
  { name: 'Frost Icicle Wings', rarity: 'Rare', desc: 'Floating faceted ice blades arranged in breathing symmetrical arcs.', compat: 'Pairs cleanly with Frost Queen Tiara.', anim: 'Float', c1: '#BAE6FD', c2: '#38BDF8' },
  { name: 'Blossom Sakura Wings', rarity: 'Mythic', desc: 'Graceful branch-framed wings blooming with fluttering cherry petals.', compat: 'Blossom Collection centerpiece.', anim: 'Flutter', c1: '#F472B6', c2: '#FBCFE8' },
  { name: 'Origami Paper Wings', rarity: 'Common', desc: 'Crisp folded geometric craft wings with clean articulated hinge creases.', compat: 'Low-poly geometry; ultra fast rendering.', anim: 'Flutter', c1: '#F1F5F9', c2: '#64748B' },
  { name: 'Astral Energy Pinions', rarity: 'Signature', desc: 'Detached floating energy blades fanning gracefully open and shut.', compat: 'Zero clipping with capes.', anim: 'Float', c1: '#6366F1', c2: '#38BDF8' },
  { name: 'Steampunk Brass Wings', rarity: 'Rare', desc: 'Clockwork copper-and-canvas mechanical wings with hinged struts.', compat: 'Works with Brass Tophat.', anim: 'Flutter', c1: '#B45309', c2: '#FDE68A' },
  { name: 'Fallen Ash Seraph Wings', rarity: 'Mythic', desc: 'Charcoal-and-ember ragged angel feathers beating with heavy grace.', compat: 'Dramatic wide wingspan; visual only.', anim: 'Flutter', c1: '#27272A', c2: '#F97316' },
  { name: 'Lunar Moth Wings', rarity: 'Signature', desc: 'Moonlit emerald-and-silver swallowtail moth wings with trailing tips.', compat: 'Lower wing tails trail softly behind upper lobes.', anim: 'Flutter', c1: '#34D399', c2: '#E2E8F0' },
  { name: 'Cyber Holo-Grid Wings', rarity: 'Rare', desc: 'Floating wireframe hologram wings pulsing with neon wave sweeps.', compat: 'Supports primary/accent dyes.', anim: 'Pulse', c1: '#06B6D4', c2: '#A855F7' },
  { name: 'Storm Lightning Wings', rarity: 'Signature', desc: 'Jagged crackling sky-arc wings surging with electric blue energy.', compat: 'Rapid energetic wing pulse.', anim: 'Pulse', c1: '#38BDF8', c2: '#FEF08A' },
  { name: 'Celestial Peacock Plumes', rarity: 'Mythic', desc: 'Fanned iridescent tail-eye feathers shimmering in sapphire and gold.', compat: 'Spread-and-fold rhythmic fan motion.', anim: 'Flutter', c1: '#0EA5E9', c2: '#FACC15' },
  { name: 'Starlight Constellation Wings', rarity: 'Signature', desc: 'Suspended glowing star-nodes linked by radiant astral wing rays.', compat: 'Pairs with Starfield Constellation Cape.', anim: 'Float', c1: '#818CF8', c2: '#F8FAFC' },
  { name: 'Coral Reef Aqua Fins', rarity: 'Common', desc: 'Flowing translucent ocean fin-wings undulating like sea ribbons.', compat: 'Matches Ocean theme & Corsair Coat.', anim: 'Wave', c1: '#0284C7', c2: '#2DD4BF' },
  { name: 'Valkyrie Blade-Wings', rarity: 'Mythic', desc: 'Six razor-sleek silver-and-gold feather blades sweeping in battle formation.', compat: 'Articulated mechanical fan spread.', anim: 'Float', c1: '#E2E8F0', c2: '#FACC15' },
  { name: 'Emerald Forest Leaf-Wings', rarity: 'Common', desc: 'Layered verdant woodland leaves fluttering gently like autumn canopy.', compat: 'Matches Emerald Druid Vest.', anim: 'Flutter', c1: '#10B981', c2: '#A3E635' },
  { name: 'Reaper Bone-Wings', rarity: 'Mythic', desc: 'Skeletal ivory wing arches trailing dark spectral shadow wisps.', compat: 'Articulated rib segments.', anim: 'Flutter', c1: '#E2E8F0', c2: '#475569' },
  { name: 'Solar Halo-Wings', rarity: 'Signature', desc: 'Radiant golden sunbeams radiating outward behind a split halo arc.', compat: 'Matches Solar Emperor Diadem.', anim: 'Float', c1: '#F59E0B', c2: '#FEF08A' },
  { name: 'Nebula Void-Ribbons', rarity: 'Signature', desc: 'Four flowing cosmic energy ribbons billowing gracefully from the shoulders.', compat: 'Independent sinusoidal ribbon motion.', anim: 'Wave', c1: '#7C5CFF', c2: '#EC4899' },
];

const SHOULDER_ACCESSORIES: RawEntry[] = [
  { name: 'Mini Void Dragonet', rarity: 'Signature', desc: 'Tiny curled amethyst dragon perched on your shoulder flapping mini wings.', compat: 'Visual companion only; zero AI entity spawned.', anim: 'Float', c1: '#5B21B6', c2: '#38BDF8' },
  { name: 'Floating Lantern Wisp', rarity: 'Rare', desc: 'Miniature glowing paper lantern bobbing beside your left shoulder.', compat: 'Emits soft cosmetic aura only (no dynamic block light).', anim: 'Float', c1: '#F59E0B', c2: '#FEF3C7' },
  { name: 'Astral Shoulder Pauldrons', rarity: 'Mythic', desc: 'Twin curved celestial armor plates hovering slightly above shoulders.', compat: 'Leaves center chest clear for Outfit Overlays.', anim: 'Pulse', c1: '#312E81', c2: '#818CF8' },
  { name: 'Blossom Bird Companion', rarity: 'Common', desc: 'Tiny round sakura songbird flapping gently on your shoulder.', compat: 'Compatible with all capes and wings.', anim: 'Flutter', c1: '#F472B6', c2: '#FFF1F2' },
  { name: 'Mini Slime Buddy', rarity: 'Common', desc: 'Translucent bouncy emerald cube friend bouncing on your shoulder.', compat: 'Squishes gently with player movement.', anim: 'Float', c1: '#10B981', c2: '#A7F3D0' },
  { name: 'Clockwork Gear Mantle', rarity: 'Rare', desc: 'Rotating interlocking brass gears spinning continuously across the shoulder.', compat: 'Matches Steampunk set.', anim: 'Orbit', c1: '#D97706', c2: '#78350F' },
  { name: 'Frost Crystal Spike', rarity: 'Rare', desc: 'Crystalline glacial shoulder clusters with icy sheen.', compat: 'Pairs with Frost Tiara.', anim: 'Pulse', c1: '#38BDF8', c2: '#E0F2FE' },
  { name: 'Neon Holo-Drone', rarity: 'Mythic', desc: 'Tiny hovering triangular scanner drone orbiting calmly beside you.', compat: 'Purely cosmetic hover loop.', anim: 'Orbit', c1: '#1E293B', c2: '#22D3EE' },
  { name: 'Golden Griffin Crest', rarity: 'Mythic', desc: 'Sculpted royal gold shoulder guards with crimson cloth tabs.', compat: 'Pairs with Crimson Monarch Cape.', anim: 'Static', c1: '#EAB308', c2: '#DC2626' },
  { name: 'Shadow Raven Perch', rarity: 'Rare', desc: 'Sleek midnight raven with gleaming violet eyes perched on shoulder.', compat: 'Subtle wing-tuck animation.', anim: 'Flutter', c1: '#18181B', c2: '#8B5CF6' },
  { name: 'Mini Axolotl Friend', rarity: 'Common', desc: 'Adorable rosy aquatic buddy curled happily on your shoulder.', compat: 'Clean silhouette across all skins.', anim: 'Float', c1: '#FB7185', c2: '#FCE7F3' },
  { name: 'Arcane Runic Orb', rarity: 'Signature', desc: 'Levitating runed sphere bound by delicate spinning silver rings.', compat: 'Compatible with Back Accessories.', anim: 'Orbit', c1: '#7C5CFF', c2: '#E2E8F0' },
  { name: 'Phoenix Hatchling Chick', rarity: 'Mythic', desc: 'Tiny glowing ember bird perched on your shoulder fluttering sparks.', compat: 'Pairs with Phoenix Flame Wings.', anim: 'Flutter', c1: '#EF4444', c2: '#FACC15' },
  { name: 'Lunar Spirit Fox', rarity: 'Signature', desc: 'Miniature glowing white fox cub curled peacefully around your collar.', compat: 'Tail swishes softly.', anim: 'Float', c1: '#F8FAFC', c2: '#818CF8' },
  { name: 'Cyber Shield Emitter', rarity: 'Rare', desc: 'Sleek hexagonal shoulder emitter projecting a tiny holo chevron.', compat: 'Visual only; zero damage mitigation.', anim: 'Pulse', c1: '#0F172A', c2: '#22D3EE' },
  { name: 'Mini Enderman Plush', rarity: 'Common', desc: 'Cute blocky obsidian plushie friend clutching a tiny purple block.', compat: 'Zero teleportation or hitbox effect.', anim: 'Float', c1: '#18181B', c2: '#C084FC' },
  { name: 'Sakura Wind Chime', rarity: 'Common', desc: 'Delicate hanging glass wind-bell dangling from a curved shoulder pin.', compat: 'Sways organically as you move.', anim: 'Wave', c1: '#FB7185', c2: '#E0F2FE' },
  { name: 'Solar Star Companion', rarity: 'Signature', desc: 'Spinning miniature golden sun-star hovering above your right shoulder.', compat: 'Pairs with Solar Valkyrie set.', anim: 'Orbit', c1: '#FACC15', c2: '#F97316' },
];

const BACK_ACCESSORIES: RawEntry[] = [
  { name: 'Runic Greatsword Scabbard', rarity: 'Mythic', desc: 'Ornamental greatsword strapped diagonally across the back.', compat: 'Decorative prop only; does not replace held weapon.', anim: 'Static', c1: '#475569', c2: '#8B5CF6' },
  { name: 'Alchemist Potion Pack', rarity: 'Rare', desc: 'Leather satchel carrying glowing corked vials and brass clasps.', compat: 'Best worn without wide capes.', anim: 'Float', c1: '#78350F', c2: '#34D399' },
  { name: 'Samurai Sashimono Banner', rarity: 'Rare', desc: 'Vertical war-banner crest rising cleanly behind the shoulder.', compat: 'Banner fabric ripples gracefully in wind.', anim: 'Wave', c1: '#991B1B', c2: '#FDE047' },
  { name: 'Starlight Arrow Quiver', rarity: 'Common', desc: 'Sleek leather quiver stocked with violet-fletched arrows.', compat: 'Purely cosmetic; independent of inventory arrows.', anim: 'Static', c1: '#713F12', c2: '#A78BFA' },
  { name: 'Astral Clockwork Ring', rarity: 'Signature', desc: 'Giant celestial halo wheel turning silently behind the shoulders.', compat: 'Stacks stunningly with Capes and Wings.', anim: 'Orbit', c1: '#FBBF24', c2: '#6366F1' },
  { name: 'Blossom Paper Parasol', rarity: 'Rare', desc: 'Closed decorative sakura umbrella strapped neatly across the back.', compat: 'Pairs with Kimono Haori overlay.', anim: 'Static', c1: '#F472B6', c2: '#FEF3C7' },
  { name: 'Arcane Grimoire Tome', rarity: 'Mythic', desc: 'Floating chained spellbook hovering gently behind your back.', compat: 'Pages flutter subtly on hover.', anim: 'Float', c1: '#4C1D95', c2: '#FACC15' },
  { name: 'Twin Katana Cross', rarity: 'Rare', desc: 'Two lacquered scabbards crossed cleanly behind the torso.', compat: 'Cosmetic only; zero combat impact.', anim: 'Static', c1: '#1E293B', c2: '#EF4444' },
  { name: 'Jetstream Thruster Pack', rarity: 'Mythic', desc: 'Compact twin-nozzle booster pack with subtle cyan pilot lights.', compat: 'Visual jet flare on sprint.', anim: 'Pulse', c1: '#334155', c2: '#22D3EE' },
  { name: 'Explorer Compass Pack', rarity: 'Common', desc: 'Canvas bedroll backpack with swinging brass lantern hook.', compat: 'Pairs cleanly with Explorer Fedora.', anim: 'Static', c1: '#65A30D', c2: '#D97706' },
  { name: 'Solar Chakra Wheel', rarity: 'Signature', desc: 'Geometric spinning sun-sigil suspended just behind the spine.', compat: 'Works alongside Wings and Capes.', anim: 'Orbit', c1: '#F59E0B', c2: '#F43F5E' },
  { name: 'Crystal Aegis Shield', rarity: 'Rare', desc: 'Faceted amethyst-and-steel kite shield slung over the back.', compat: 'Cosmetic only; separate from offhand shield.', anim: 'Static', c1: '#475569', c2: '#38BDF8' },
  { name: 'Kitsune Nine-Tail Fan', rarity: 'Signature', desc: 'Fanned mystical fox tails swaying gracefully behind the lower back.', compat: 'Gentle wave motion on every tail.', anim: 'Wave', c1: '#FFF7ED', c2: '#F97316' },
  { name: 'Cyber Katana Holster', rarity: 'Mythic', desc: 'Illuminated neon blade sheath mounted cleanly across the spine.', compat: 'Pulses with Cyber theme accents.', anim: 'Pulse', c1: '#0F172A', c2: '#22D3EE' },
  { name: 'Steampunk Pressure Tank', rarity: 'Rare', desc: 'Twin riveted copper steam cylinders with spinning pressure gauges.', compat: 'Pairs with Brass Wings.', anim: 'Orbit', c1: '#B45309', c2: '#38BDF8' },
  { name: 'Moonlit Lantern Staff', rarity: 'Common', desc: 'Carved wooden traveler staff topped with a swaying star lantern.', compat: 'Gentle lantern swing.', anim: 'Wave', c1: '#78350F', c2: '#FDE047' },
  { name: 'Void Rift Portal Ring', rarity: 'Signature', desc: 'Spinning obsidian ring framing a swirling violet portal vortex.', compat: 'Stacks with Abyssal Rift outfits.', anim: 'Orbit', c1: '#4C1D95', c2: '#EC4899' },
  { name: 'Plush Panda Backpack', rarity: 'Common', desc: 'Cozy black-and-white panda backpack hugging your shoulders.', compat: 'Zero clipping with hats and footwear.', anim: 'Static', c1: '#F8FAFC', c2: '#18181B' },
];

const FOOTWEAR: RawEntry[] = [
  { name: 'Hermes Winged Boots', rarity: 'Signature', desc: 'Sleek alabaster boots sporting tiny flapping ankle wings.', compat: 'Cosmetic only; does not modify walk or jump speed.', anim: 'Flutter', c1: '#F8FAFC', c2: '#FACC15' },
  { name: 'Obsidian Sabatons', rarity: 'Mythic', desc: 'Dark armored greaves etched with glowing violet rune seams.', compat: 'Cleanly hugs vanilla leg model.', anim: 'Pulse', c1: '#18181B', c2: '#7C5CFF' },
  { name: 'Blossom Ribbon Sandals', rarity: 'Common', desc: 'Wraparound pastel ankle ribbons with subtle petal trim.', compat: 'Matches Blossom Kimono Haori.', anim: 'Wave', c1: '#F472B6', c2: '#FFF1F2' },
  { name: 'Cyber Hover Greaves', rarity: 'Mythic', desc: 'Futuristic matte boots with glowing neon sole trim.', compat: 'Visual glow strip only.', anim: 'Pulse', c1: '#0F172A', c2: '#22D3EE' },
  { name: 'Arctic Fur Mukluks', rarity: 'Common', desc: 'Warm snow boots trimmed with soft white fleece cuffs.', compat: 'Matches Arctic set.', anim: 'Static', c1: '#0284C7', c2: '#F8FAFC' },
  { name: 'Void Walker Anklets', rarity: 'Rare', desc: 'Floating luminous rings orbiting smoothly around both ankles.', compat: 'Lightweight overlay; shows skin boots beneath.', anim: 'Orbit', c1: '#6D28D9', c2: '#E879F9' },
  { name: 'Crimson Strider Boots', rarity: 'Rare', desc: 'Tall cuffed leather boots accented with gold buckles.', compat: 'Pairs with Crimson Monarch Cape.', anim: 'Static', c1: '#991B1B', c2: '#FBBF24' },
  { name: 'Emerald Moss Greaves', rarity: 'Common', desc: 'Woven woodland boots wrapped in living ivy tendrils.', compat: 'Matches Emerald Druid Vest.', anim: 'Static', c1: '#065F46', c2: '#4ADE80' },
  { name: 'Golden Valkyrie Greaves', rarity: 'Mythic', desc: 'Polished gilded shin guards with feathered ankle spurs.', compat: 'Pairs with Valkyrie Helm.', anim: 'Flutter', c1: '#EAB308', c2: '#F8FAFC' },
  { name: 'Shadow Shinobi Tabi', rarity: 'Common', desc: 'Tactical wrapped shin guards with split-toe dark soles.', compat: 'Pairs cleanly with Shadow Cowl.', anim: 'Static', c1: '#18181B', c2: '#64748B' },
  { name: 'Neon Skate Blades', rarity: 'Rare', desc: 'Stylized roller-blade sole accents with glowing wheel hubs.', compat: 'Wheels spin visually while walking.', anim: 'Orbit', c1: '#1E293B', c2: '#EC4899' },
  { name: 'Frost Stepper Spurs', rarity: 'Rare', desc: 'Crystalline ice-edged boots leaving tiny decorative frost glints.', compat: 'Purely client-side visual trim.', anim: 'Pulse', c1: '#38BDF8', c2: '#E0F2FE' },
  { name: 'Phoenix Talon Greaves', rarity: 'Signature', desc: 'Gilded ember greaves crowned with flaring ankle feather crests.', compat: 'Matches Phoenix Flame Wings.', anim: 'Flutter', c1: '#DC2626', c2: '#FACC15' },
  { name: 'Steampunk Brass Boots', rarity: 'Common', desc: 'Buckled explorer leather boots with tiny spinning ankle cogs.', compat: 'Matches Brass Tophat.', anim: 'Orbit', c1: '#78350F', c2: '#F59E0B' },
  { name: 'Starlight Comet Runners', rarity: 'Rare', desc: 'Sleek midnight athletic sneakers with glowing cyan sole trails.', compat: 'Modern casual streetwear silhouette.', anim: 'Pulse', c1: '#1E293B', c2: '#38BDF8' },
  { name: 'Dragon Scale Sabatons', rarity: 'Mythic', desc: 'Layered obsidian scale boots tipped with glowing amethyst claws.', compat: 'Matches Dragonborn Crown.', anim: 'Static', c1: '#18181B', c2: '#A855F7' },
  { name: 'Cloud Slipper Fluffs', rarity: 'Common', desc: 'Plush pastel-white cloud slippers bobbing playfully at each step.', compat: 'Matches Cloud Nimbus Puff.', anim: 'Float', c1: '#F8FAFC', c2: '#BAE6FD' },
  { name: 'Solar Flare Greaves', rarity: 'Signature', desc: 'Radiant sun-forged leg plates ringed by floating gold halo bands.', compat: 'Orbiting ankle rings.', anim: 'Orbit', c1: '#F59E0B', c2: '#FEF08A' },
];

const OUTFIT_OVERLAYS: RawEntry[] = [
  { name: 'M3liodas Starlight Trim', rarity: 'Signature', desc: 'Tailored midnight coat lapels lined with starry violet piping.', compat: 'Renders neatly over player outer skin layer.', anim: 'Pulse', c1: '#1E1B4B', c2: '#7C5CFF' },
  { name: 'Crimson Royal Sash', rarity: 'Rare', desc: 'Diagonal ceremonial scarlet sash fastened with a gold medallion.', compat: 'Clean chest overlay; compatible with any skin.', anim: 'Static', c1: '#DC2626', c2: '#FACC15' },
  { name: 'Blossom Kimono Haori', rarity: 'Mythic', desc: 'Draped sakura-patterned open haori jacket with wide sleeves.', compat: 'Animates gently while sprinting.', anim: 'Wave', c1: '#FB7185', c2: '#FFF1F2' },
  { name: 'Cyber Circuit Suit', rarity: 'Mythic', desc: 'Luminous neon circuit lines mapped cleanly over arms and chest.', compat: 'Supports primary/secondary color dyes.', anim: 'Pulse', c1: '#0F172A', c2: '#22D3EE' },
  { name: 'Arctic Expedition Parka', rarity: 'Common', desc: 'Fur-lined winter coat overlay with buckled storm collar.', compat: 'Matches Arctic Mukluks & Goggles.', anim: 'Static', c1: '#0369A1', c2: '#F1F5F9' },
  { name: 'Abyssal Void Ribbons', rarity: 'Signature', desc: 'Floating dark-energy ribbons coiling gently around torso and arms.', compat: 'Zero clipping with Back Accessories.', anim: 'Float', c1: '#312E81', c2: '#EC4899' },
  { name: 'Emerald Druid Vest', rarity: 'Common', desc: 'Woven forest tunic layered with golden leaf embroidery.', compat: 'Matches Emerald Rune Cloak.', anim: 'Static', c1: '#065F46', c2: '#34D399' },
  { name: 'Golden Paladin Surcoat', rarity: 'Mythic', desc: 'White-and-gold armored tabard displaying a radiant crest.', compat: 'Visual overlay only; does not change armor.', anim: 'Static', c1: '#F8FAFC', c2: '#EAB308' },
  { name: 'Shadow Assassin Wraps', rarity: 'Rare', desc: 'Crossed dark leather chest straps with subtle metallic clasps.', compat: 'Minimalist tactical look.', anim: 'Static', c1: '#18181B', c2: '#94A3B8' },
  { name: 'Ocean Corsair Coat', rarity: 'Rare', desc: 'Tailored sea-captain waistcoat with brass buttons and cyan trim.', compat: 'Matches Ocean Tide Mantle.', anim: 'Wave', c1: '#0C4A6E', c2: '#38BDF8' },
  { name: 'Runic Mage Robe Trim', rarity: 'Rare', desc: 'Layered scholar stole hanging softly with glowing glyph borders.', compat: 'Matches Astral Mage Spire.', anim: 'Pulse', c1: '#4C1D95', c2: '#FBBF24' },
  { name: 'Minimalist Tech Vest', rarity: 'Common', desc: 'Matte slate utility vest with clean reflective piping.', compat: 'Universal clean modern aesthetic.', anim: 'Static', c1: '#334155', c2: '#7C5CFF' },
  { name: 'Phoenix Ember Chestplate', rarity: 'Signature', desc: 'Decorative molten gold-and-scarlet breastplate with rising glow.', compat: 'Pairs cleanly with Phoenix Flame Wings.', anim: 'Pulse', c1: '#991B1B', c2: '#FACC15' },
  { name: 'Steampunk Aviator Jacket', rarity: 'Rare', desc: 'Cropped leather bomber jacket with fleece collar and brass zippers.', compat: 'Pairs with Steampunk Brass Wings.', anim: 'Static', c1: '#78350F', c2: '#FDE68A' },
  { name: 'Sakura Shrine Miko Robe', rarity: 'Rare', desc: 'Crisp crimson-and-white ceremonial sleeves with bow sash.', compat: 'Matches Kitsune Spirit Mask.', anim: 'Wave', c1: '#F8FAFC', c2: '#EF4444' },
  { name: 'Void Knight Pauldron Coat', rarity: 'Mythic', desc: 'Deep charcoal trench coat with glowing violet chest sigil.', compat: 'Matches Obsidian Dragon Wings.', anim: 'Pulse', c1: '#18181B', c2: '#8B5CF6' },
  { name: 'Pastel Hoodie Lounge', rarity: 'Common', desc: 'Relaxed oversized pastel violet hoodie with drawstring cuffs.', compat: 'Clean casual aesthetic.', anim: 'Static', c1: '#A78BFA', c2: '#F8FAFC' },
  { name: 'Valkyrie Winged Breastplate', rarity: 'Signature', desc: 'Sculpted alabaster chest armor embossed with winged gold reliefs.', compat: 'Matches Valkyrie Blade-Wings.', anim: 'Pulse', c1: '#E2E8F0', c2: '#EAB308' },
];

export const COSMETICS_CATALOG: CosmeticItem[] = [
  ...buildCategory('hats', 'hat', HATS),
  ...buildCategory('headAccessories', 'head', HEAD_ACCESSORIES),
  ...buildCategory('masks', 'mask', MASKS),
  ...buildCategory('capes', 'cape', CAPES),
  ...buildCategory('wings', 'wing', WINGS),
  ...buildCategory('shoulderAccessories', 'shoulder', SHOULDER_ACCESSORIES),
  ...buildCategory('backAccessories', 'back', BACK_ACCESSORIES),
  ...buildCategory('footwear', 'foot', FOOTWEAR),
  ...buildCategory('outfitOverlays', 'outfit', OUTFIT_OVERLAYS),
];

const findId = (cat: CosmeticCategory, name: string) =>
  COSMETICS_CATALOG.find((c) => c.category === cat && c.name === name)?.id;

export const DEFAULT_OUTFIT_PRESETS: OutfitPreset[] = [
  {
    id: 'preset_m3liodas_sovereign',
    name: 'M3liodas Sovereign',
    primaryDye: '#7C5CFF',
    secondaryDye: '#38BDF8',
    equipped: {
      hats: findId('hats', 'Crown of Midnight'),
      headAccessories: findId('headAccessories', 'Celestial Starlight Halo'),
      masks: findId('masks', 'Phantom Half-Mask'),
      capes: findId('capes', 'M3liodas Nebula Cape'),
      wings: findId('wings', 'Seraph Feathered Wings'),
      shoulderAccessories: findId('shoulderAccessories', 'Mini Void Dragonet'),
      backAccessories: findId('backAccessories', 'Astral Clockwork Ring'),
      footwear: findId('footwear', 'Obsidian Sabatons'),
      outfitOverlays: findId('outfitOverlays', 'M3liodas Starlight Trim'),
    },
  },
  {
    id: 'preset_phoenix_ascendant',
    name: 'Phoenix Ascendant',
    primaryDye: '#EF4444',
    secondaryDye: '#FACC15',
    equipped: {
      hats: findId('hats', 'Solar Emperor Diadem'),
      headAccessories: findId('headAccessories', 'Twin Flame Halos'),
      masks: findId('masks', 'Oni Crimson Visor'),
      capes: findId('capes', 'Phoenix Ember Shroud'),
      wings: findId('wings', 'Phoenix Flame Wings'),
      shoulderAccessories: findId('shoulderAccessories', 'Phoenix Hatchling Chick'),
      backAccessories: findId('backAccessories', 'Solar Chakra Wheel'),
      footwear: findId('footwear', 'Phoenix Talon Greaves'),
      outfitOverlays: findId('outfitOverlays', 'Phoenix Ember Chestplate'),
    },
  },
  {
    id: 'preset_blossom_spirit',
    name: 'Blossom Spirit',
    primaryDye: '#F472B6',
    secondaryDye: '#FFF1F2',
    equipped: {
      hats: findId('hats', 'Blossom Sunhat'),
      headAccessories: findId('headAccessories', 'Sakura Blossom Hairpin'),
      masks: findId('masks', 'Blossom Silk Veil'),
      capes: findId('capes', 'Blossom Petal Banner'),
      wings: findId('wings', 'Blossom Sakura Wings'),
      shoulderAccessories: findId('shoulderAccessories', 'Blossom Bird Companion'),
      backAccessories: findId('backAccessories', 'Blossom Paper Parasol'),
      footwear: findId('footwear', 'Blossom Ribbon Sandals'),
      outfitOverlays: findId('outfitOverlays', 'Blossom Kimono Haori'),
    },
  },
  {
    id: 'preset_cyber_runner',
    name: 'Cyber Runner',
    primaryDye: '#22D3EE',
    secondaryDye: '#0F172A',
    equipped: {
      hats: findId('hats', 'Cyber Visor Cap'),
      headAccessories: findId('headAccessories', 'Neon Synth Headset'),
      masks: findId('masks', 'Cyber Holo Respirator'),
      capes: findId('capes', 'Cyber Grid Cape'),
      wings: findId('wings', 'Cyber Mech Thrusters'),
      shoulderAccessories: findId('shoulderAccessories', 'Neon Holo-Drone'),
      backAccessories: findId('backAccessories', 'Cyber Katana Holster'),
      footwear: findId('footwear', 'Cyber Hover Greaves'),
      outfitOverlays: findId('outfitOverlays', 'Cyber Circuit Suit'),
    },
  },
  {
    id: 'preset_void_dragonlord',
    name: 'Void Dragonlord',
    primaryDye: '#8B5CF6',
    secondaryDye: '#18181B',
    equipped: {
      hats: findId('hats', 'Dragonborn Horned Crown'),
      headAccessories: findId('headAccessories', 'Obsidian Rift Horns'),
      masks: findId('masks', 'Void Watcher Goggles'),
      capes: findId('capes', 'Abyssal Rift Cloak'),
      wings: findId('wings', 'Obsidian Dragon Wings'),
      shoulderAccessories: findId('shoulderAccessories', 'Mini Void Dragonet'),
      backAccessories: findId('backAccessories', 'Void Rift Portal Ring'),
      footwear: findId('footwear', 'Dragon Scale Sabatons'),
      outfitOverlays: findId('outfitOverlays', 'Void Knight Pauldron Coat'),
    },
  },
  {
    id: 'preset_crimson_ronin',
    name: 'Crimson Ronin',
    primaryDye: '#DC2626',
    secondaryDye: '#FACC15',
    equipped: {
      hats: findId('hats', 'Crimson Ronin Kabuto'),
      headAccessories: findId('headAccessories', 'Kitsune Fox Ears'),
      masks: findId('masks', 'Kitsune Spirit Mask'),
      capes: findId('capes', 'Crimson Monarch Cape'),
      wings: findId('wings', 'Monarch Butterfly Wings'),
      backAccessories: findId('backAccessories', 'Twin Katana Cross'),
      footwear: findId('footwear', 'Crimson Strider Boots'),
      outfitOverlays: findId('outfitOverlays', 'Sakura Shrine Miko Robe'),
    },
  },
];

export interface OnlineStylePackListing {
  id: string;
  name: string;
  author: string;
  version: string;
  mcVersion: string;
  sha256Preview: string;
  description: string;
  preset: OutfitPreset;
}

export const TRUSTED_ONLINE_STYLE_LIBRARY: OnlineStylePackListing[] = [
  {
    id: 'online_arctic_warden',
    name: 'Arctic Aurora Warden',
    author: 'ItsM3liodas Curated',
    version: '1.2.0',
    mcVersion: '1.21.11',
    sha256Preview: '8f4c...e91a',
    description: 'Frost Antler Crown, Glacier Goggles, Icicle Wings, Aurora Cape, and Fur Mukluks.',
    preset: {
      id: 'preset_arctic_warden',
      name: 'Arctic Aurora Warden',
      primaryDye: '#38BDF8',
      secondaryDye: '#E0F2FE',
      equipped: {
        hats: findId('hats', 'Frost Queen Tiara'),
        headAccessories: findId('headAccessories', 'Frost Antler Crown'),
        masks: findId('masks', 'Frost Spirit Half-Mask'),
        capes: findId('capes', 'Arctic Aurora Cape'),
        wings: findId('wings', 'Frost Icicle Wings'),
        shoulderAccessories: findId('shoulderAccessories', 'Frost Crystal Spike'),
        footwear: findId('footwear', 'Arctic Fur Mukluks'),
        outfitOverlays: findId('outfitOverlays', 'Arctic Expedition Parka'),
      },
    },
  },
  {
    id: 'online_storm_valkyrie',
    name: 'Storm Valkyrie',
    author: 'ItsM3liodas Verified',
    version: '2.1.0',
    mcVersion: '1.21.11',
    sha256Preview: '3b19...77d2',
    description: 'Valkyrie Winged Helm, Blade-Wings, Thunderstorm Cape, and Gilded Greaves.',
    preset: {
      id: 'preset_storm_valkyrie',
      name: 'Storm Valkyrie',
      primaryDye: '#E2E8F0',
      secondaryDye: '#38BDF8',
      equipped: {
        hats: findId('hats', 'Valkyrie Winged Helm'),
        headAccessories: findId('headAccessories', 'Seraph Ear Winglets'),
        masks: findId('masks', 'Valkyrie Cheek Plates'),
        capes: findId('capes', 'Thunderstorm Arc Cape'),
        wings: findId('wings', 'Valkyrie Blade-Wings'),
        shoulderAccessories: findId('shoulderAccessories', 'Arcane Runic Orb'),
        footwear: findId('footwear', 'Golden Valkyrie Greaves'),
        outfitOverlays: findId('outfitOverlays', 'Valkyrie Winged Breastplate'),
      },
    },
  },
  {
    id: 'online_lunar_kitsune',
    name: 'Lunar Kitsune',
    author: 'ItsM3liodas Curated',
    version: '1.4.2',
    mcVersion: '1.21.11',
    sha256Preview: '91a0...5f03',
    description: 'Lunar Moth Wings, Nine-Tail Fan, Kitsune Spirit Mask, and Lunar Spirit Fox.',
    preset: {
      id: 'preset_lunar_kitsune',
      name: 'Lunar Kitsune',
      primaryDye: '#34D399',
      secondaryDye: '#E2E8F0',
      equipped: {
        headAccessories: findId('headAccessories', 'Lunar Crescent Crown'),
        masks: findId('masks', 'Kitsune Spirit Mask'),
        capes: findId('capes', 'Midnight Crescent Cloak'),
        wings: findId('wings', 'Lunar Moth Wings'),
        shoulderAccessories: findId('shoulderAccessories', 'Lunar Spirit Fox'),
        backAccessories: findId('backAccessories', 'Kitsune Nine-Tail Fan'),
        footwear: findId('footwear', 'Hermes Winged Boots'),
        outfitOverlays: findId('outfitOverlays', 'Sakura Shrine Miko Robe'),
      },
    },
  },
];
