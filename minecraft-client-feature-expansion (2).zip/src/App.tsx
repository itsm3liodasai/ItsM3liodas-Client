import {
  Crown,
  Eye,
  FolderArchive,
  Layers,
  LayoutGrid,
  Maximize2,
  Minimize2,
  Search,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { FabricDeliveryView } from './components/FabricDeliveryView';
import { HudEditorPanel } from './components/HudEditorPanel';
import { MinecraftViewport } from './components/MinecraftViewport';
import { ModulesWorkspace } from './components/ModulesWorkspace';
import { StylesWardrobe } from './components/StylesWardrobe';
import { formatKeyCodeLabel, useClientStore } from './store/useClientStore';
import { FONT_FAMILY_META } from './types/client';

export function App() {
  const {
    config,
    setConfig,
    world,
    setWorld,
    musicState,
    togglePlayMusic,
    stepTrack,
    selectTrack,
    loadLocalAudioTrack,
    attachLrcToCurrentTrack,
    lookupOnlineLyrics,
    menuOpen,
    setMenuOpen,
    activeTab,
    setActiveTab,
    toasts,
    pushToast,
    recordMouseClick,
    recordSettingChange,
    applyThemePreset,
    applyMotionBlurPreset,
    applyColorGradingPreset,
    applyPerformancePreset,
    toggleFavoriteModule,
    updateHudElement,
    resetAllHudElements,
    equipCosmetic,
    toggleVisualPack,
    importVisualPackJson,
    keybindConflicts,
    exportFullConfig,
    importFullConfig,
    restoreBackupConfig,
    resetAllConfig,
  } = useClientStore();

  const menuBlurPx =
    config.menuBlur.enabled && config.menuBlur.blurClientMenu
      ? config.menuBlur.performanceFriendly
        ? Math.min(8, config.menuBlur.strength)
        : config.menuBlur.strength
      : 0;

  const menuDimAlpha = config.menuBlur.enabled && config.menuBlur.blurClientMenu ? config.menuBlur.dimming : 0.15;

  const panelBg = config.theme.gradientEnabled
    ? `linear-gradient(155deg, ${config.theme.backgroundTop}, ${config.theme.backgroundBottom})`
    : config.theme.backgroundTop;

  const navItems = [
    { id: 'studio', label: 'Modules & Lyrics', icon: LayoutGrid },
    { id: 'hud', label: 'HUD & Uku Armor', icon: Layers },
    { id: 'wardrobe', label: '3D Cosmetics & Capes', icon: Sparkles },
    { id: 'delivery', label: 'Get .JAR on GitHub', icon: FolderArchive },
  ] as const;

  return (
    <div
      style={{ fontFamily: FONT_FAMILY_META[config.theme.fontFamily]?.css ?? FONT_FAMILY_META.inter.css }}
      className="relative h-screen w-screen overflow-hidden bg-[#060810] text-slate-100"
    >
      {/* Real-Time Three.js 3D Minecraft World Viewport + HUD + Valence Lyrics + Uku Armor */}
      <div className="absolute inset-0">
        <MinecraftViewport
          config={config}
          world={world}
          setWorld={setWorld}
          musicState={musicState}
          onTogglePlayMusic={togglePlayMusic}
          onStepTrack={stepTrack}
          onUpdateLyricsPos={(lx, ly) =>
            setConfig((c) => ({
              ...c,
              musicLyrics: { ...c.musicLyrics, lyricPosition: 'custom', lyricX: lx, lyricY: ly },
            }))
          }
          onMouseAction={recordMouseClick}
          interactiveMode={!menuOpen}
        />
      </div>

      {/* Top Floating Quick Play Bar when Client Menu is Minimized */}
      {!menuOpen && (
        <div className="absolute top-3 left-1/2 z-30 flex -translate-x-1/2 flex-wrap items-center gap-2 rounded-full border border-white/15 bg-black/70 px-3.5 py-1.5 text-xs shadow-2xl backdrop-blur-md">
          <span className="font-bold text-white">ItsM3liodas Client</span>
          <span className="text-slate-500">·</span>
          <span className="text-[11px] text-slate-300">
            Drag Lyrics Anywhere · Drag Screen = Look ·{' '}
            <strong className="font-mono text-sky-300">{formatKeyCodeLabel(config.keybinds.zoom.key)}</strong> = Zoom ·{' '}
            <strong className="font-mono text-sky-300">{formatKeyCodeLabel(config.keybinds.freelook.key)}</strong> = Freelook
          </span>
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            style={{ backgroundColor: config.theme.accentColor }}
            className="ml-1 inline-flex items-center gap-1 rounded-full px-3 py-1 text-[11px] font-semibold text-white shadow"
          >
            <Maximize2 className="h-3 w-3" /> Open Client ({formatKeyCodeLabel(config.keybinds.openMenu.key)})
          </button>
        </div>
      )}

      {/* Sleek Modern Minecraft Client Overlay with Left Sidebar Navigation */}
      {menuOpen && (
        <div
          style={{
            backdropFilter: `blur(${menuBlurPx}px)`,
            WebkitBackdropFilter: `blur(${menuBlurPx}px)`,
            backgroundColor: `rgba(4, 6, 14, ${menuDimAlpha})`,
          }}
          className={`absolute inset-0 z-30 flex items-center justify-center p-2 sm:p-4 ${
            config.menuBlur.smoothTransitions ? 'transition-all duration-200' : ''
          }`}
        >
          <div
            style={{
              background: panelBg,
              opacity: config.menuBlur.enabled ? config.menuBlur.opacity : config.theme.panelOpacity,
              borderRadius: `${config.theme.cornerRadius}px`,
            }}
            className="mc-animate-in flex h-full max-h-[92vh] w-full max-w-[1460px] overflow-hidden border border-white/15 shadow-[0_24px_90px_rgba(0,0,0,0.85)]"
          >
            {/* Left Sidebar (Clean Feather/Lunar Style) */}
            <aside className="flex w-16 shrink-0 flex-col justify-between border-r border-white/10 bg-[#070912]/90 p-2.5 sm:w-56 sm:p-3.5">
              <div className="space-y-4">
                {/* Brand */}
                <div className="flex items-center gap-2.5 px-1 py-1">
                  <div
                    style={{
                      background: `linear-gradient(135deg, ${config.theme.accentColor}, ${config.theme.secondaryColor})`,
                    }}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl shadow-lg"
                  >
                    <Crown className="h-5 w-5 text-white" />
                  </div>
                  <div className="hidden min-w-0 sm:block">
                    <div className="truncate text-xs font-extrabold tracking-wide text-white">ITSM3LIODAS</div>
                    <div className="text-[10px] font-medium text-slate-400">MC 1.21.11 · Fabric</div>
                  </div>
                </div>

                {/* Nav Links */}
                <nav className="space-y-1">
                  {navItems.map((tab) => {
                    const Icon = tab.icon;
                    const active = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setActiveTab(tab.id)}
                        style={active ? { backgroundColor: config.theme.accentColor } : undefined}
                        className={`flex w-full items-center justify-center gap-2.5 rounded-xl px-2.5 py-2.5 text-xs font-semibold transition-all sm:justify-start ${
                          active
                            ? 'text-white shadow-lg'
                            : 'text-slate-400 hover:bg-white/[0.06] hover:text-white'
                        }`}
                        title={tab.label}
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        <span className="hidden truncate sm:inline">{tab.label}</span>
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Bottom Quick Controls */}
              <div className="space-y-2 border-t border-white/10 pt-3">
                <div className="hidden items-center justify-between rounded-lg bg-black/40 px-2.5 py-1.5 font-mono text-[11px] sm:flex">
                  <span className="text-slate-400">Viewport FPS</span>
                  <span className="font-bold text-emerald-400">{world.fps}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/[0.07] px-2.5 py-2 text-xs font-semibold text-white hover:bg-white/15"
                >
                  <Minimize2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="hidden sm:inline">Preview 3D World</span>
                </button>
              </div>
            </aside>

            {/* Right Content Frame */}
            <div className="flex min-w-0 flex-1 flex-col">
              {/* Minimalist Top Utility Bar */}
              <header className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-black/20 px-4 py-2.5">
                <div className="flex items-center gap-2 text-xs font-semibold text-white">
                  <span>{navItems.find((n) => n.id === activeTab)?.label}</span>
                  <span className="rounded bg-white/10 px-2 py-0.5 font-mono text-[10px] font-normal text-slate-300">
                    v2.5.0
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setWorld((w) => ({ ...w, zoomEngaged: !w.zoomEngaged }))}
                    className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[11px] font-medium ${
                      world.zoomEngaged ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-200' : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Search className="h-3 w-3" /> Zoom
                  </button>
                  <button
                    type="button"
                    onClick={() => setWorld((w) => ({ ...w, freelookEngaged: !w.freelookEngaged }))}
                    className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[11px] font-medium ${
                      world.freelookEngaged ? 'border-sky-400/50 bg-sky-500/20 text-sky-200' : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Eye className="h-3 w-3" /> Freelook
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setWorld((w) => ({
                        ...w,
                        pingMs: w.pingMs === null ? 24 : null,
                        serverAddress: w.serverAddress === null ? 'play.itsm3liodas.net' : null,
                      }))
                    }
                    className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-300 hover:bg-white/10"
                  >
                    {world.pingMs !== null ? <Wifi className="h-3 w-3 text-emerald-400" /> : <WifiOff className="h-3 w-3 text-amber-400" />}
                    {world.pingMs !== null ? '24ms' : 'Local'}
                  </button>
                </div>
              </header>

              <main className="min-h-0 flex-1 overflow-y-auto p-4">
                {activeTab === 'studio' && (
                  <ModulesWorkspace
                    config={config}
                    setConfig={setConfig}
                    world={world}
                    setWorld={setWorld}
                    musicState={musicState}
                    onTogglePlayMusic={togglePlayMusic}
                    onStepTrack={stepTrack}
                    onSelectTrack={selectTrack}
                    onLoadAudioFile={loadLocalAudioTrack}
                    onAttachLrc={attachLrcToCurrentTrack}
                    onLookupOnlineLyrics={lookupOnlineLyrics}
                    keybindConflicts={keybindConflicts}
                    onApplyTheme={applyThemePreset}
                    onApplyMotionBlurPreset={applyMotionBlurPreset}
                    onApplyColorGradingPreset={applyColorGradingPreset}
                    onApplyPerformance={applyPerformancePreset}
                    onToggleFavorite={toggleFavoriteModule}
                    onRecordSetting={recordSettingChange}
                    onToggleVisualPack={toggleVisualPack}
                    onImportVisualPack={importVisualPackJson}
                    onExportConfig={exportFullConfig}
                    onImportConfig={importFullConfig}
                    onRestoreBackup={restoreBackupConfig}
                    onResetAll={resetAllConfig}
                    onToast={pushToast}
                  />
                )}

                {activeTab === 'hud' && (
                  <HudEditorPanel
                    config={config}
                    setConfig={setConfig}
                    world={world}
                    setWorld={setWorld}
                    musicState={musicState}
                    onUpdateElement={updateHudElement}
                    onResetAll={resetAllHudElements}
                    onMouseAction={recordMouseClick}
                    onToast={pushToast}
                  />
                )}

                {activeTab === 'wardrobe' && (
                  <StylesWardrobe
                    config={config}
                    setConfig={setConfig}
                    onEquip={equipCosmetic}
                    onToast={pushToast}
                  />
                )}

                {activeTab === 'delivery' && <FabricDeliveryView config={config} onToast={pushToast} />}
              </main>
            </div>
          </div>
        </div>
      )}

      {/* Animated Toast Notifications */}
      <div className="pointer-events-none fixed right-4 bottom-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            style={{ borderRadius: `${Math.max(8, config.theme.cornerRadius - 2)}px` }}
            className={`mc-animate-in pointer-events-auto max-w-xs border px-3.5 py-2.5 text-xs shadow-2xl backdrop-blur-xl ${
              t.tone === 'error'
                ? 'border-rose-400/40 bg-rose-950/90 text-rose-100'
                : t.tone === 'warning'
                ? 'border-amber-400/40 bg-amber-950/90 text-amber-100'
                : t.tone === 'success'
                ? 'border-emerald-400/40 bg-emerald-950/90 text-emerald-100'
                : 'border-white/20 bg-slate-950/90 text-slate-100'
            }`}
          >
            <div className="font-semibold">{t.title}</div>
            {t.detail && <div className="mt-0.5 text-[11px] opacity-85">{t.detail}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
