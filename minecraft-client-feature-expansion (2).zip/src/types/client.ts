export type ThemeId =
  | 'midnight'
  | 'ocean'
  | 'blossom'
  | 'abyss'
  | 'arctic'
  | 'emerald'
  | 'crimson'
  | 'minimal'
  | 'custom';

export type FontFamilyId =
  | 'inter'
  | 'space'
  | 'mono'
  | 'silkscreen'
  | 'cinzel'
  | 'bebas'
  | 'caveat';

export const FONT_FAMILY_META: Record<FontFamilyId, { label: string; css: string }> = {
  inter: { label: 'Inter Clean', css: "'Inter', system-ui, sans-serif" },
  space: { label: 'Space Grotesk', css: "'Space Grotesk', system-ui, sans-serif" },
  mono: { label: 'JetBrains Mono', css: "'JetBrains Mono', monospace" },
  silkscreen: { label: 'Minecraft Pixel (Silkscreen)', css: "'Silkscreen', monospace" },
  cinzel: { label: 'Fantasy Serif (Cinzel)', css: "'Cinzel', serif" },
  bebas: { label: 'Bold Display (Bebas Neue)', css: "'Bebas Neue', sans-serif" },
  caveat: { label: 'Aesthetic Script (Caveat)', css: "'Caveat', cursive" },
};

export type HudElementId =
  | 'fps'
  | 'ping'
  | 'coordinates'
  | 'direction'
  | 'clock'
  | 'armor'
  | 'heldItem'
  | 'biome'
  | 'potions'
  | 'server'
  | 'keystrokes'
  | 'musicCard'
  | 'cps'
  | 'session';

export interface HudElementConfig {
  id: HudElementId;
  label: string;
  description: string;
  enabled: boolean;
  x: number;
  y: number;
  scale: number;
  opacity: number;
  bgOpacity: number;
  color: string;
  font: FontFamilyId;
  spacing: number;
  locked: boolean;
  format: string;
  precision?: number;
  clock24h?: boolean;
  showSeconds?: boolean;
  showDurabilityPercent?: boolean;
  pingUnavailableText?: string;
  armorStyle?: 'uku' | 'uku-numbers' | 'detailed';
  armorOrientation?: 'horizontal' | 'vertical';
  showArmorFrame?: boolean;
  showWarningBadge?: boolean;
  lowDurabilityThreshold?: number;
  showOffhandSlot?: boolean;
}

export interface HudProfile {
  id: string;
  name: string;
  createdAt: string;
  elements: Record<HudElementId, HudElementConfig>;
}

export type MotionBlurPreset = 'Off' | 'Low' | 'Medium' | 'High' | 'Cinematic' | 'Custom';
export type ColorGradingPreset = 'Natural' | 'Cinematic' | 'Vibrant' | 'Cool' | 'Warm' | 'Dark' | 'Custom';
export type HandAuraStyle = 'Soft Glow' | 'Neon' | 'Magical' | 'Electric' | 'Rainbow' | 'Minimal Outline';
export type ParticleStyle =
  | 'Starlight Sparkles'
  | 'Sakura Petals'
  | 'Ember Sparks'
  | 'Frost Snowflakes'
  | 'Void Motes'
  | 'Enchant Runes'
  | 'Neon Rings';
export type PerformancePreset = 'Ultra Quality' | 'Balanced' | 'Performance' | 'Low-End Safe';
export type ViewmodelItemCategory = 'swords' | 'blocks' | 'consumables' | 'ranged';
export type ShowcaseSceneId = 'cherry-grove' | 'end-citadel' | 'sunset-mesa' | 'obsidian-studio';

export interface ViewmodelCategoryOffset {
  handX: number;
  handY: number;
  handZ: number;
  itemX: number;
  itemY: number;
  itemZ: number;
  scale: number;
  rotX: number;
  rotY: number;
  rotZ: number;
}

export interface VisualPackEntry {
  id: string;
  name: string;
  author: string;
  version: string;
  mcFormat: string;
  compatible: boolean;
  enabled: boolean;
  description: string;
  license: string;
  category: 'UI' | 'Sky & Lighting' | 'Blocks & Crosshair' | 'Cosmetic Overlay';
  swatchColors: [string, string, string];
  verifiedAssets: string[];
}

export type CosmeticCategory =
  | 'hats'
  | 'headAccessories'
  | 'masks'
  | 'capes'
  | 'wings'
  | 'shoulderAccessories'
  | 'backAccessories'
  | 'footwear'
  | 'outfitOverlays';

export interface CosmeticItem {
  id: string;
  name: string;
  category: CosmeticCategory;
  rarity: 'Common' | 'Rare' | 'Mythic' | 'Signature';
  description: string;
  compatibilityNote: string;
  animationType: 'Static' | 'Float' | 'Flutter' | 'Pulse' | 'Wave' | 'Orbit';
  defaultPrimary: string;
  defaultSecondary: string;
  shapeVariant: number;
  free: true;
  author: string;
}

export interface OutfitPreset {
  id: string;
  name: string;
  equipped: Partial<Record<CosmeticCategory, string>>;
  primaryDye: string;
  secondaryDye: string;
}

export interface SyncedLyricLine {
  timeSec: number;
  text: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  durationSec: number;
  coverColors: [string, string, string];
  bpm: number;
  audioUrl?: string;
  lyrics: SyncedLyricLine[];
}

export type KeybindActionId =
  | 'openMenu'
  | 'zoom'
  | 'freelook'
  | 'hudEditor'
  | 'wardrobe'
  | 'toggleCrosshair'
  | 'toggleColorGrading'
  | 'resetCamera';

export interface KeybindConfig {
  id: KeybindActionId;
  label: string;
  description: string;
  key: string;
  supportsMode: boolean;
  mode: 'Hold' | 'Toggle';
}

export interface CustomColorPreset {
  id: string;
  name: string;
  brightness: number;
  contrast: number;
  saturation: number;
  temperature: number;
  gamma: number;
  vignette: number;
  filterColor: string;
  filterStrength: number;
}

export interface ThemeSettings {
  themeId: ThemeId;
  accentColor: string;
  secondaryColor: string;
  backgroundTop: string;
  backgroundBottom: string;
  gradientEnabled: boolean;
  panelOpacity: number;
  blurStrength: number;
  fontFamily: FontFamilyId;
  cornerRadius: number;
  animationSpeed: number;
  reducedMotion: boolean;
}

export type LyricPlacementMode =
  | 'sky-center'
  | 'in-front'
  | 'above-crosshair'
  | 'top-banner'
  | 'above-hotbar'
  | 'custom';

export interface ClientConfig {
  schemaVersion: number;
  clientVersion: string;
  hudScale: number;
  hudOpacity: number;
  theme: ThemeSettings;

  motionBlur: {
    enabled: boolean;
    preset: MotionBlurPreset;
    intensity: number;
    durationMs: number;
    qualitySamples: number;
    cameraBlur: boolean;
    guiBlur: boolean;
    backgroundBlur: boolean;
  };

  menuBlur: {
    enabled: boolean;
    strength: number;
    dimming: number;
    opacity: number;
    smoothTransitions: boolean;
    performanceFriendly: boolean;
    blurClientMenu: boolean;
    blurInventory: boolean;
    blurHudEditor: boolean;
  };

  nametags: {
    enabled: boolean;
    textColor: string;
    font: FontFamilyId;
    size: number;
    backgroundOpacity: number;
    textShadow: boolean;
    showHealthWhenPermitted: boolean;
    distanceScaling: boolean;
  };

  crosshair: {
    enabled: boolean;
    preset: string;
    color: string;
    size: number;
    thickness: number;
    gap: number;
    centerDot: boolean;
    outline: boolean;
    opacity: number;
  };

  blockOutline: {
    enabled: boolean;
    preset: string;
    color: string;
    thickness: number;
    opacity: number;
    glow: boolean;
  };

  itemPhysics: {
    enabled: boolean;
    rotation: boolean;
    smoothMovement: boolean;
    speed: number;
    style: 'Flat Lay' | 'Gentle Hover' | 'Classic Spin' | 'Cinematic Float';
    maxAnimatedItems: number;
  };

  colorGrading: {
    enabled: boolean;
    preset: ColorGradingPreset;
    brightness: number;
    contrast: number;
    saturation: number;
    temperature: number;
    gamma: number;
    vignette: number;
    filterColor: string;
    filterStrength: number;
    savedPresets: CustomColorPreset[];
  };

  visualPacks: {
    enabled: boolean;
    packs: VisualPackEntry[];
  };

  handAura: {
    enabled: boolean;
    style: HandAuraStyle;
    primaryColor: string;
    secondaryColor: string;
    intensity: number;
    size: number;
    transparency: number;
    animationSpeed: number;
    particleAmount: number;
    heldItemEffect: boolean;
    quality: 'Low' | 'Balanced' | 'High';
  };

  zoom: {
    enabled: boolean;
    mode: 'Hold' | 'Toggle';
    strength: number;
    transitionSpeed: number;
    reduceSensitivity: boolean;
  };

  freelook: {
    enabled: boolean;
    mode: 'Hold' | 'Toggle';
    horizontalSensitivity: number;
    verticalSensitivity: number;
    maxHorizontalDeg: number;
    maxVerticalDeg: number;
    smoothMovement: boolean;
    thirdPersonSupport: boolean;
  };

  shulkerPreview: {
    enabled: boolean;
    previewScale: number;
    backgroundStyle: 'M3liodas Glass' | 'Obsidian Dark' | 'Vanilla Classic' | 'Accent Border';
    smoothAnimation: boolean;
    showEnchantments: boolean;
    showDurability: boolean;
  };

  viewmodel: {
    enabled: boolean;
    activeCategory: ViewmodelItemCategory;
    leftHandEnabled: boolean;
    rightHandEnabled: boolean;
    categories: Record<ViewmodelItemCategory, ViewmodelCategoryOffset>;
  };

  cosmetics: {
    enabled: boolean;
    animationsEnabled: boolean;
    wingFlapSpeed: number;
    wingSpread: number;
    equipped: Partial<Record<CosmeticCategory, string>>;
    primaryDye: string;
    secondaryDye: string;
    favorites: string[];
    outfits: OutfitPreset[];
    customCapeDataUrl: string | null;
    customCapeName: string | null;
    customCapeIsGif: boolean;
    useCustomCapeImage: boolean;
    showcaseScene: ShowcaseSceneId;
  };

  particles: {
    enabled: boolean;
    style: ParticleStyle;
    primaryColor: string;
    secondaryColor: string;
    size: number;
    transparency: number;
    speed: number;
    amount: number;
    quality: 'Low' | 'Balanced' | 'High';
    performanceMode: boolean;
  };

  musicLyrics: {
    enabled: boolean;
    showNowPlayingCard: boolean;
    showSkyLyrics: boolean;
    lyricPosition: LyricPlacementMode;
    lyricX: number; // 0..100 %
    lyricY: number; // 0..100 %
    lyricFont: FontFamilyId;
    lyricStyle: 'cinematic-glow' | 'glass-pill' | 'pixel-shadow' | 'outline';
    lyricTilt3D: boolean;
    lyricLetterSpacing: number;
    lyricScale: number;
    lyricOpacity: number;
    lyricColor: string;
    lyricGlow: boolean;
    showNextLine: boolean;
    showEqualizer: boolean;
    albumTintSync: boolean;
    spotifyClientId: string;
    spotifyStatus: 'Local Synced Mode' | 'OAuth PKCE Ready';
  };

  performance: {
    preset: PerformancePreset;
    avoidPerFrameAllocations: boolean;
    cacheAssets: boolean;
    optimizeBlur: boolean;
    optimizeParticles: boolean;
    optimizeCosmetics: boolean;
    reducedQualityMode: boolean;
  };

  hudElements: Record<HudElementId, HudElementConfig>;
  hudProfiles: HudProfile[];
  activeHudProfileId: string;
  keybinds: Record<KeybindActionId, KeybindConfig>;
  favoriteModules: string[];
  recentSettings: { id: string; label: string; category: string; timestamp: number }[];
}

export interface SettingDocumentation {
  title: string;
  whatItDoes: string;
  affects: string;
  increasing: string;
  decreasing: string;
  performance: string;
  compatibility: string;
}

export interface ModuleDefinition {
  id: string;
  name: string;
  category: 'Visuals' | 'Camera' | 'HUD' | 'World & Items' | 'Packs & Styles' | 'System';
  summary: string;
  explanation: string;
  keybindAction?: KeybindActionId;
  compatibilityNote?: string;
}
