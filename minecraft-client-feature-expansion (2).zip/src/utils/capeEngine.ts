import { GifReader } from 'omggif';
import * as THREE from 'three';

export interface DecodedGifCape {
  width: number;
  height: number;
  frames: { imageData: ImageData; delayMs: number }[];
  totalDurationMs: number;
}

/**
 * Decodes an animated GIF data URL or ArrayBuffer into real frame-by-frame ImageData
 * with disposal-aware compositing so animated GIF capes play smoothly on Three.js textures.
 */
export async function decodeGifDataUrl(dataUrl: string): Promise<DecodedGifCape | null> {
  try {
    const res = await fetch(dataUrl);
    const buf = await res.arrayBuffer();
    const bytes = new Uint8Array(buf);
    const reader = new GifReader(bytes);
    const w = reader.width;
    const h = reader.height;
    const numFrames = reader.numFrames();
    if (numFrames <= 0 || w <= 0 || h <= 0) return null;

    const composite = document.createElement('canvas');
    composite.width = w;
    composite.height = h;
    const cctx = composite.getContext('2d')!;
    const frameBuf = new Uint8ClampedArray(w * h * 4);
    const frames: { imageData: ImageData; delayMs: number }[] = [];
    let totalDurationMs = 0;

    for (let i = 0; i < numFrames; i++) {
      const info = reader.frameInfo(i);
      const prevCopy = info.disposal === 3 ? cctx.getImageData(0, 0, w, h) : null;
      frameBuf.fill(0);
      reader.decodeAndBlitFrameRGBA(i, frameBuf);

      const temp = document.createElement('canvas');
      temp.width = w;
      temp.height = h;
      const tctx = temp.getContext('2d')!;
      tctx.putImageData(new ImageData(frameBuf, w, h), 0, 0);
      cctx.drawImage(temp, 0, 0);

      const snapshot = cctx.getImageData(0, 0, w, h);
      const delayMs = Math.max(30, (info.delay || 8) * 10);
      frames.push({ imageData: snapshot, delayMs });
      totalDurationMs += delayMs;

      if (info.disposal === 2) {
        cctx.clearRect(info.x, info.y, info.width, info.height);
      } else if (info.disposal === 3 && prevCopy) {
        cctx.putImageData(prevCopy, 0, 0);
      }
    }

    return { width: w, height: h, frames, totalDurationMs };
  } catch {
    return null;
  }
}

/**
 * Generates high-detail custom-made Minecraft cape CanvasTextures (64x104 pixel grid, crisp pixel art + animated motion).
 */
export function drawCustomCapeCanvas(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  variant: number,
  primary: string,
  secondary: string,
  timeSec: number
) {
  ctx.clearRect(0, 0, w, h);

  // Rich base backdrop
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, '#070914');
  grad.addColorStop(0.45, primary);
  grad.addColorStop(1, '#090D18');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Outer trim border
  ctx.strokeStyle = secondary;
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, w - 4, h - 4);
  ctx.strokeStyle = 'rgba(255,255,255,0.22)';
  ctx.lineWidth = 1;
  ctx.strokeRect(6, 6, w - 12, h - 12);

  const cx = w / 2;
  const cy = h / 2;

  if (variant === 0 || variant === 10 || variant === 13) {
    // M3liodas Nebula / Starfield Constellation / Prism Iridescent Cape
    for (let i = 0; i < 24; i++) {
      const sx = ((i * 37 + Math.sin(timeSec + i) * 3) % (w - 16)) + 8;
      const sy = ((i * 53 + timeSec * 8 * ((i % 2) + 0.5)) % (h - 16)) + 8;
      ctx.fillStyle = i % 3 === 0 ? secondary : '#FFFFFF';
      ctx.globalAlpha = 0.45 + 0.55 * Math.abs(Math.sin(timeSec * 2 + i));
      ctx.fillRect(Math.round(sx), Math.round(sy), i % 4 === 0 ? 3 : 2, i % 4 === 0 ? 3 : 2);
    }
    ctx.globalAlpha = 1;
    // Glowing Crescent & Star Emblem
    ctx.fillStyle = secondary;
    ctx.beginPath();
    ctx.arc(cx, cy - 8, 18, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0B0F1E';
    ctx.beginPath();
    ctx.arc(cx + 6, cy - 11, 15, 0, Math.PI * 2);
    ctx.fill();
    // Glowing diamond star
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.moveTo(cx + 8, cy - 16);
    ctx.lineTo(cx + 11, cy - 10);
    ctx.lineTo(cx + 17, cy - 8);
    ctx.lineTo(cx + 11, cy - 6);
    ctx.lineTo(cx + 8, cy);
    ctx.lineTo(cx + 5, cy - 6);
    ctx.lineTo(cx - 1, cy - 8);
    ctx.lineTo(cx + 5, cy - 10);
    ctx.closePath();
    ctx.fill();
  } else if (variant === 2 || variant === 15) {
    // Blossom Sakura Waterfall Cape
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#1E1128');
    bg.addColorStop(0.55, primary);
    bg.addColorStop(1, '#3B0764');
    ctx.fillStyle = bg;
    ctx.fillRect(4, 4, w - 8, h - 8);
    // Branch silhouette
    ctx.strokeStyle = '#1E1B4B';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(4, 24);
    ctx.quadraticCurveTo(cx, 36, w - 12, 18);
    ctx.stroke();
    // Falling animated cherry petals
    for (let i = 0; i < 18; i++) {
      const px = ((i * 29 + Math.sin(timeSec * 1.5 + i) * 8) % (w - 14)) + 7;
      const py = ((i * 41 + timeSec * 18) % (h - 14)) + 7;
      ctx.fillStyle = i % 2 === 0 ? '#FFF1F2' : secondary;
      ctx.fillRect(Math.round(px), Math.round(py), 4, 3);
    }
  } else if (variant === 9 || variant === 16) {
    // Cyber Grid / Thunderstorm Arc Cape
    ctx.fillStyle = '#060A16';
    ctx.fillRect(4, 4, w - 8, h - 8);
    // Synth sun
    const sunGrad = ctx.createLinearGradient(0, 18, 0, 62);
    sunGrad.addColorStop(0, secondary);
    sunGrad.addColorStop(1, '#EC4899');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(cx, 44, 20, 0, Math.PI * 2);
    ctx.fill();
    // Horizon laser grid
    ctx.strokeStyle = secondary;
    ctx.lineWidth = 1.5;
    for (let y = 62; y < h - 4; y += 7) {
      const shift = ((y + timeSec * 18) % 42) + 62;
      ctx.beginPath();
      ctx.moveTo(4, shift);
      ctx.lineTo(w - 4, shift);
      ctx.stroke();
    }
    for (let x = -2; x <= 2; x++) {
      ctx.beginPath();
      ctx.moveTo(cx + x * 6, 62);
      ctx.lineTo(cx + x * 24, h - 4);
      ctx.stroke();
    }
  } else if (variant === 5 || variant === 12) {
    // Arctic Aurora / Phoenix Ember Cape
    for (let band = 0; band < 4; band++) {
      ctx.strokeStyle = band % 2 === 0 ? secondary : primary;
      ctx.lineWidth = 7;
      ctx.globalAlpha = 0.55;
      ctx.beginPath();
      for (let y = 8; y < h - 8; y += 6) {
        const waveX = cx + Math.sin(y * 0.08 + timeSec * 2.5 + band) * 18 + (band - 1.5) * 8;
        if (y === 8) ctx.moveTo(waveX, y);
        else ctx.lineTo(waveX, y);
      }
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  } else if (variant === 4 || variant === 17) {
    // Crimson Monarch / Valkyrie Royal Emblem Cape
    ctx.fillStyle = primary;
    ctx.fillRect(4, 4, w - 8, h - 8);
    // Royal diamond filigree center
    ctx.fillStyle = secondary;
    ctx.beginPath();
    ctx.moveTo(cx, cy - 28);
    ctx.lineTo(cx + 18, cy);
    ctx.lineTo(cx, cy + 28);
    ctx.lineTo(cx - 18, cy);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 16);
    ctx.lineTo(cx + 10, cy);
    ctx.lineTo(cx, cy + 16);
    ctx.lineTo(cx - 10, cy);
    ctx.closePath();
    ctx.fill();
    // Animated pulsing royal crown emblem
    ctx.fillStyle = secondary;
    ctx.fillRect(cx - 6, cy - 5, 12, 10);
  } else {
    // Sleek Geometric Dragon Scale / Rune Crest Cape
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 6; col++) {
        const sx = 8 + col * 14 + (row % 2 === 0 ? 0 : 7);
        const sy = 10 + row * 12;
        ctx.fillStyle = (row + col) % 2 === 0 ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.22)';
        ctx.beginPath();
        ctx.arc(sx, sy, 6, 0, Math.PI);
        ctx.fill();
      }
    }
    // Bold Monogram "M" Crest
    ctx.fillStyle = secondary;
    ctx.font = 'bold 28px "Space Grotesk", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('M', cx, cy);
  }
}

export function createMaterialTexture(canvas: HTMLCanvasElement): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}
