import React, { useRef, useState } from 'react';
import {
  Download,
  Lock,
  Plus,
  RotateCcw,
  Trash2,
  Unlock,
  Upload,
} from 'lucide-react';
import { LiveWorldTelemetry, MusicPlayerState } from '../store/useClientStore';
import { ClientConfig, FONT_FAMILY_META, FontFamilyId, HudElementConfig, HudElementId, HudProfile } from '../types/client';
import { MinecraftViewport } from './MinecraftViewport';
import { SliderRow, ToggleRow } from './SettingTooltip';

interface HudEditorProps {
  config: ClientConfig;
  setConfig: React.Dispatch<React.SetStateAction<ClientConfig>>;
  world: LiveWorldTelemetry;
  setWorld: React.Dispatch<React.SetStateAction<LiveWorldTelemetry>>;
  musicState: MusicPlayerState;
  onUpdateElement: (id: HudElementId, patch: Partial<HudElementConfig>) => void;
  onResetAll: () => void;
  onMouseAction: (btn: 0 | 2, down: boolean) => void;
  onToast: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

export const HudEditorPanel: React.FC<HudEditorProps> = ({
  config,
  setConfig,
  world,
  setWorld,
  musicState,
  onUpdateElement,
  onResetAll,
  onMouseAction,
  onToast,
}) => {
  const [selectedId, setSelectedId] = useState<HudElementId>('armor');
  const [snapGrid, setSnapGrid] = useState(true);
  const [newProfileName, setNewProfileName] = useState('');
  const importRef = useRef<HTMLInputElement | null>(null);

  const selected = config.hudElements[selectedId];

  const handlePositionDrag = (id: HudElementId, x: number, y: number) => {
    const finalX = snapGrid ? Math.round(x / 2) * 2 : x;
    const finalY = snapGrid ? Math.round(y / 2) * 2 : y;
    onUpdateElement(id, { x: finalX, y: finalY });
  };

  const saveProfile = () => {
    const name = newProfileName.trim();
    if (!name) return;
    const profile: HudProfile = {
      id: `hud_${Date.now()}`,
      name,
      createdAt: new Date().toISOString(),
      elements: JSON.parse(JSON.stringify(config.hudElements)),
    };
    setConfig((c) => ({
      ...c,
      hudProfiles: [profile, ...c.hudProfiles],
      activeHudProfileId: profile.id,
    }));
    setNewProfileName('');
    onToast('HUD Profile Saved', `Saved "${name}" layout.`, 'success');
  };

  const loadProfile = (profile: HudProfile) => {
    setConfig((c) => ({
      ...c,
      activeHudProfileId: profile.id,
      hudElements: JSON.parse(JSON.stringify(profile.elements)),
    }));
    onToast('HUD Profile Loaded', `Applied "${profile.name}".`, 'success');
  };

  const exportProfile = () => {
    const payload = {
      format: 'itsm3liodas-hud-profile-v1',
      name: config.hudProfiles.find((p) => p.id === config.activeHudProfileId)?.name ?? 'Custom Layout',
      hudScale: config.hudScale,
      hudOpacity: config.hudOpacity,
      elements: config.hudElements,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'itsm3liodas-hud-profile.json';
    a.click();
    URL.revokeObjectURL(url);
    onToast('HUD Profile Exported', 'Saved itsm3liodas-hud-profile.json', 'success');
  };

  const handleImportProfile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!parsed.elements || typeof parsed.elements !== 'object') {
          onToast('Invalid HUD Profile', 'Missing HUD element map.', 'error');
          return;
        }
        const profile: HudProfile = {
          id: `hud_imp_${Date.now()}`,
          name: String(parsed.name ?? 'Imported Profile').slice(0, 32),
          createdAt: new Date().toISOString(),
          elements: { ...config.hudElements, ...parsed.elements },
        };
        setConfig((c) => ({
          ...c,
          hudScale: typeof parsed.hudScale === 'number' ? parsed.hudScale : c.hudScale,
          hudOpacity: typeof parsed.hudOpacity === 'number' ? parsed.hudOpacity : c.hudOpacity,
          hudElements: profile.elements,
          hudProfiles: [profile, ...c.hudProfiles],
          activeHudProfileId: profile.id,
        }));
        onToast('HUD Profile Imported', `Loaded "${profile.name}".`, 'success');
      } catch {
        onToast('Import Error', 'Could not parse HUD profile JSON.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="grid h-full grid-cols-1 gap-4 lg:grid-cols-12">
      <div className="flex flex-col gap-3 lg:col-span-8">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5">
          <div>
            <h2 className="text-sm font-semibold text-white">Advanced HUD Editor — Live Drag &amp; Drop Stage</h2>
            <p className="text-[11px] text-slate-400">
              Drag any HUD widget to reposition · Includes Uku-style Armor HUD &amp; Valence Music Card
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSnapGrid((s) => !s)}
              className={`rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors ${
                snapGrid ? 'border-emerald-400/40 bg-emerald-500/20 text-emerald-200' : 'border-white/15 bg-white/5 text-slate-300'
              }`}
            >
              Grid Snap: {snapGrid ? 'ON' : 'OFF'}
            </button>
            <button
              type="button"
              onClick={exportProfile}
              className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/10"
            >
              <Download className="h-3.5 w-3.5" /> Export
            </button>
            <button
              type="button"
              onClick={() => importRef.current?.click()}
              className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/10"
            >
              <Upload className="h-3.5 w-3.5" /> Import
            </button>
            <input ref={importRef} type="file" accept=".json" onChange={handleImportProfile} className="hidden" />
            <button
              type="button"
              onClick={onResetAll}
              className="inline-flex items-center gap-1 rounded-lg border border-rose-400/30 bg-rose-500/15 px-2.5 py-1 text-xs text-rose-200 hover:bg-rose-500/25"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Reset All
            </button>
          </div>
        </div>

        <div className="min-h-[460px] flex-1 overflow-hidden rounded-xl border border-white/15 shadow-2xl">
          <MinecraftViewport
            config={config}
            world={world}
            setWorld={setWorld}
            musicState={musicState}
            onUpdateLyricsPos={(lx, ly) =>
              setConfig((c) => ({
                ...c,
                musicLyrics: { ...c.musicLyrics, lyricPosition: 'custom', lyricX: lx, lyricY: ly },
              }))
            }
            onMouseAction={onMouseAction}
            interactiveMode={false}
            hudEditMode={true}
            selectedHudId={selectedId}
            onSelectHudId={setSelectedId}
            onUpdateHudPosition={handlePositionDrag}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
          <span className="text-xs font-semibold text-slate-300">Profiles:</span>
          {config.hudProfiles.map((prof) => {
            const active = prof.id === config.activeHudProfileId;
            return (
              <div
                key={prof.id}
                className={`inline-flex items-center overflow-hidden rounded-lg border ${
                  active ? 'border-white/35 bg-white/15' : 'border-white/10 bg-white/5'
                }`}
              >
                <button
                  type="button"
                  onClick={() => loadProfile(prof)}
                  className="px-2.5 py-1 text-xs font-medium text-white hover:bg-white/10"
                >
                  {prof.name}
                </button>
                {prof.id !== 'profile_default' && (
                  <button
                    type="button"
                    onClick={() =>
                      setConfig((c) => ({
                        ...c,
                        hudProfiles: c.hudProfiles.filter((p) => p.id !== prof.id),
                      }))
                    }
                    className="px-1.5 py-1 text-slate-400 hover:text-rose-300"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                )}
              </div>
            );
          })}
          <div className="ml-auto flex items-center gap-1.5">
            <input
              type="text"
              value={newProfileName}
              onChange={(e) => setNewProfileName(e.target.value)}
              placeholder="New HUD profile name..."
              className="w-40 rounded-lg border border-white/10 bg-black/40 px-2.5 py-1 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={saveProfile}
              className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium text-white"
              style={{ backgroundColor: config.theme.accentColor }}
            >
              <Plus className="h-3.5 w-3.5" /> Save Profile
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3 lg:col-span-4">
        <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
          <div className="text-xs font-semibold tracking-wide text-slate-200 uppercase">Global HUD Master</div>
          <SliderRow
            label="Global HUD Scale"
            value={config.hudScale}
            min={0.5}
            max={2.0}
            step={0.05}
            unit="x"
            docKey="hudScale"
            accentColor={config.theme.accentColor}
            onChange={(v) => setConfig((c) => ({ ...c, hudScale: v }))}
          />
          <SliderRow
            label="Global HUD Opacity"
            value={config.hudOpacity}
            min={0.15}
            max={1.0}
            step={0.05}
            docKey="hudOpacity"
            accentColor={config.theme.accentColor}
            onChange={(v) => setConfig((c) => ({ ...c, hudOpacity: v }))}
          />
        </div>

        <div className="space-y-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div>
              <div className="text-xs font-semibold text-white">{selected.label}</div>
              <div className="text-[11px] text-slate-400">{selected.description}</div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateElement(selected.id, { locked: !selected.locked })}
              className={`rounded-lg border p-1.5 ${
                selected.locked ? 'border-amber-400/40 bg-amber-500/20 text-amber-200' : 'border-white/10 bg-white/5 text-slate-300'
              }`}
              title={selected.locked ? 'Unlock position' : 'Lock position'}
            >
              {selected.locked ? <Lock className="h-3.5 w-3.5" /> : <Unlock className="h-3.5 w-3.5" />}
            </button>
          </div>

          <ToggleRow
            label="Show Element"
            checked={selected.enabled}
            accentColor={config.theme.accentColor}
            onChange={(v) => onUpdateElement(selected.id, { enabled: v })}
          />

          <div className="grid grid-cols-2 gap-2">
            <SliderRow
              label="X Position"
              value={selected.x}
              min={0}
              max={92}
              step={1}
              unit="%"
              accentColor={config.theme.accentColor}
              onChange={(v) => !selected.locked && onUpdateElement(selected.id, { x: v })}
            />
            <SliderRow
              label="Y Position"
              value={selected.y}
              min={0}
              max={92}
              step={1}
              unit="%"
              accentColor={config.theme.accentColor}
              onChange={(v) => !selected.locked && onUpdateElement(selected.id, { y: v })}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <SliderRow
              label="Element Scale"
              value={selected.scale}
              min={0.6}
              max={1.8}
              step={0.05}
              unit="x"
              accentColor={config.theme.accentColor}
              onChange={(v) => onUpdateElement(selected.id, { scale: v })}
            />
            <SliderRow
              label="Spacing"
              value={selected.spacing}
              min={2}
              max={14}
              step={1}
              unit="px"
              accentColor={config.theme.accentColor}
              onChange={(v) => onUpdateElement(selected.id, { spacing: v })}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <SliderRow
              label="Text Opacity"
              value={selected.opacity}
              min={0.15}
              max={1.0}
              step={0.05}
              accentColor={config.theme.accentColor}
              onChange={(v) => onUpdateElement(selected.id, { opacity: v })}
            />
            <SliderRow
              label="Card BG Opacity"
              value={selected.bgOpacity}
              min={0.0}
              max={0.95}
              step={0.05}
              accentColor={config.theme.accentColor}
              onChange={(v) => onUpdateElement(selected.id, { bgOpacity: v })}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
              <span className="text-slate-300">Text Color</span>
              <input
                type="color"
                value={selected.color}
                onChange={(e) => onUpdateElement(selected.id, { color: e.target.value })}
                className="h-5 w-7 cursor-pointer rounded border-0 bg-transparent"
              />
            </label>
            <select
              value={selected.font}
              onChange={(e) => onUpdateElement(selected.id, { font: e.target.value as FontFamilyId })}
              className="rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 text-xs text-white focus:outline-none"
            >
              {(Object.keys(FONT_FAMILY_META) as FontFamilyId[]).map((fk) => (
                <option key={fk} value={fk}>
                  {FONT_FAMILY_META[fk].label}
                </option>
              ))}
            </select>
          </div>

          {(selected.id === 'fps' || selected.id === 'ping' || selected.id === 'coordinates' || selected.id === 'direction') && (
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-slate-300">Format Template</label>
              <input
                type="text"
                value={selected.format}
                onChange={(e) => onUpdateElement(selected.id, { format: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-black/40 px-2.5 py-1.5 font-mono text-xs text-white focus:outline-none"
              />
            </div>
          )}

          {selected.id === 'coordinates' && (
            <SliderRow
              label="Decimal Precision"
              value={selected.precision ?? 1}
              min={0}
              max={2}
              step={1}
              accentColor={config.theme.accentColor}
              onChange={(v) => onUpdateElement('coordinates', { precision: v })}
            />
          )}

          {selected.id === 'clock' && (
            <div className="grid grid-cols-2 gap-2">
              <ToggleRow
                label="24-Hour Format"
                checked={selected.clock24h ?? true}
                accentColor={config.theme.accentColor}
                onChange={(v) => onUpdateElement('clock', { clock24h: v })}
              />
              <ToggleRow
                label="Show Seconds"
                checked={selected.showSeconds ?? true}
                accentColor={config.theme.accentColor}
                onChange={(v) => onUpdateElement('clock', { showSeconds: v })}
              />
            </div>
          )}

          {/* Uku's Armor HUD Inspector */}
          {selected.id === 'armor' && (
            <div className="space-y-2 rounded-lg border border-sky-400/25 bg-sky-950/20 p-2.5">
              <div className="text-[11px] font-semibold text-sky-200">Uku&apos;s Armor HUD Options</div>
              <div className="grid grid-cols-2 gap-2">
                <ToggleRow
                  label="Horizontal Row"
                  checked={(selected.armorOrientation ?? 'horizontal') === 'horizontal'}
                  accentColor={config.theme.accentColor}
                  onChange={(v) => onUpdateElement('armor', { armorOrientation: v ? 'horizontal' : 'vertical' })}
                />
                <ToggleRow
                  label="Vanilla Slot Frame"
                  checked={selected.showArmorFrame ?? false}
                  accentColor={config.theme.accentColor}
                  onChange={(v) => onUpdateElement('armor', { showArmorFrame: v })}
                />
                <ToggleRow
                  label="Numeric % Text"
                  checked={selected.showDurabilityPercent ?? false}
                  accentColor={config.theme.accentColor}
                  onChange={(v) => onUpdateElement('armor', { showDurabilityPercent: v, armorStyle: v ? 'uku-numbers' : 'uku' })}
                />
                <ToggleRow
                  label="Offhand Shield"
                  checked={selected.showOffhandSlot ?? true}
                  accentColor={config.theme.accentColor}
                  onChange={(v) => onUpdateElement('armor', { showOffhandSlot: v })}
                />
              </div>
              <ToggleRow
                label="Low Durability (!) Warning"
                checked={selected.showWarningBadge ?? true}
                accentColor={config.theme.accentColor}
                onChange={(v) => onUpdateElement('armor', { showWarningBadge: v })}
              />
              <SliderRow
                label="Warning Threshold"
                value={selected.lowDurabilityThreshold ?? 25}
                min={5}
                max={60}
                step={5}
                unit="%"
                accentColor={config.theme.accentColor}
                onChange={(v) => onUpdateElement('armor', { lowDurabilityThreshold: v })}
              />
            </div>
          )}

          {selected.id === 'ping' && (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-xs">
              <span className="text-slate-300">Simulate Offline Ping</span>
              <button
                type="button"
                onClick={() =>
                  setWorld((w) => ({
                    ...w,
                    pingMs: w.pingMs === null ? 24 : null,
                    serverAddress: w.serverAddress === null ? 'play.itsm3liodas.net' : null,
                  }))
                }
                className="rounded bg-white/10 px-2 py-0.5 text-[11px] text-white hover:bg-white/20"
              >
                {world.pingMs === null ? 'Go Online (24ms)' : 'Go Singleplayer (N/A)'}
              </button>
            </div>
          )}
        </div>

        <div className="max-h-[240px] space-y-1.5 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-3">
          <div className="mb-1 text-[11px] font-semibold tracking-wide text-slate-400 uppercase">
            All HUD Elements ({Object.values(config.hudElements).filter((e) => e.enabled).length}/{Object.values(config.hudElements).length} Active)
          </div>
          {(Object.values(config.hudElements) as HudElementConfig[]).map((el) => (
            <div
              key={el.id}
              onClick={() => setSelectedId(el.id)}
              className={`flex cursor-pointer items-center justify-between rounded-lg border px-2.5 py-1.5 text-xs transition-colors ${
                selectedId === el.id ? 'border-white/30 bg-white/10 text-white' : 'border-white/5 bg-black/20 text-slate-300 hover:bg-white/5'
              }`}
            >
              <span className="font-medium">{el.label}</span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onUpdateElement(el.id, { enabled: !el.enabled });
                }}
                className={`rounded px-2 py-0.5 text-[10px] font-semibold ${
                  el.enabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/10 text-slate-400'
                }`}
              >
                {el.enabled ? 'ON' : 'OFF'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
