import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Camera,
  Grid,
  Play,
  RefreshCw,
  RotateCcw,
  Square,
  Video,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { COSMETICS_CATALOG } from '../data/cosmeticsCatalog';
import {
  CosmeticCategory,
  ShowcaseSceneId,
} from '../types/client';
import { DecodedGifCape, decodeGifDataUrl, drawCustomCapeCanvas } from '../utils/capeEngine';

interface PlayerModel3DProps {
  equipped: Partial<Record<CosmeticCategory, string>>;
  primaryDye: string;
  secondaryDye: string;
  cosmeticsEnabled: boolean;
  animationsEnabled: boolean;
  wingFlapSpeed: number;
  wingSpread: number;
  customCapeDataUrl: string | null;
  customCapeIsGif: boolean;
  useCustomCapeImage: boolean;
  showcaseScene: ShowcaseSceneId;
  onChangeScene?: (scene: ShowcaseSceneId) => void;
  accentColor: string;
  pose: 'idle' | 'walk' | 'glide' | 'wave';
  onCycleNextWing?: () => void;
  onToast?: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

function makePixelCanvasTexture(drawFn: (ctx: CanvasRenderingContext2D) => void, size = 16): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  drawFn(c.getContext('2d')!);
  const tex = new THREE.CanvasTexture(c);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.NearestFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createRealisticMinecraftSkinTextures(accentColor: string) {
  const headFront = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#E8B796';
    ctx.fillRect(0, 0, 16, 16);
    ctx.fillStyle = '#DCA27F';
    ctx.fillRect(0, 12, 16, 4);
    ctx.fillRect(0, 0, 2, 16);
    ctx.fillRect(14, 0, 2, 16);
    // Detailed anime/MC hair
    ctx.fillStyle = '#17162B';
    ctx.fillRect(0, 0, 16, 5);
    ctx.fillRect(0, 5, 3, 4);
    ctx.fillRect(13, 5, 3, 4);
    ctx.fillRect(4, 5, 3, 1);
    ctx.fillRect(10, 5, 2, 1);
    // Expressive eyes
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(3, 8, 3, 2);
    ctx.fillRect(10, 8, 3, 2);
    ctx.fillStyle = accentColor;
    ctx.fillRect(4, 8, 2, 2);
    ctx.fillRect(10, 8, 2, 2);
    ctx.fillStyle = '#090D16';
    ctx.fillRect(5, 9, 1, 1);
    ctx.fillRect(10, 9, 1, 1);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(4, 8, 1, 1);
    ctx.fillRect(10, 8, 1, 1);
    // Subtle smile
    ctx.fillStyle = '#B5775B';
    ctx.fillRect(6, 13, 4, 1);
  });

  const torso = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#1C2538';
    ctx.fillRect(0, 0, 16, 16);
    ctx.fillStyle = '#111726';
    ctx.fillRect(0, 0, 3, 16);
    ctx.fillRect(13, 0, 3, 16);
    ctx.fillRect(0, 13, 16, 3);
    ctx.fillStyle = '#334155';
    ctx.fillRect(7, 1, 2, 14);
    ctx.fillStyle = accentColor;
    ctx.fillRect(10, 4, 3, 3);
    ctx.fillRect(3, 12, 10, 1);
  });

  const arm = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#243047';
    ctx.fillRect(0, 0, 16, 11);
    ctx.fillStyle = accentColor;
    ctx.fillRect(0, 10, 16, 1);
    ctx.fillStyle = '#E8B796';
    ctx.fillRect(0, 11, 16, 5);
  });

  const leg = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#0E1525';
    ctx.fillRect(0, 0, 16, 12);
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(2, 3, 12, 5);
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, 12, 16, 4);
  });

  const grassTop = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#3D7A47';
    ctx.fillRect(0, 0, 16, 16);
    const specks = ['#4C9657', '#2E6237', '#55A862', '#346D3E'];
    for (let y = 0; y < 16; y += 2) {
      for (let x = 0; x < 16; x += 2) {
        ctx.fillStyle = specks[(x * 7 + y * 13) % specks.length];
        ctx.fillRect(x, y, 2, 2);
      }
    }
  });

  const grassSide = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#6B482F';
    ctx.fillRect(0, 0, 16, 16);
    ctx.fillStyle = '#573823';
    for (let i = 0; i < 20; i++) {
      ctx.fillRect((i * 5) % 14, 4 + ((i * 7) % 11), 2, 2);
    }
    ctx.fillStyle = '#3D7A47';
    ctx.fillRect(0, 0, 16, 4);
    ctx.fillStyle = '#4C9657';
    for (let x = 0; x < 16; x += 2) {
      if (x % 4 === 0) ctx.fillRect(x, 4, 2, 1);
    }
  });

  const stoneTex = makePixelCanvasTexture((ctx) => {
    ctx.fillStyle = '#475569';
    ctx.fillRect(0, 0, 16, 16);
    const cols = ['#334155', '#64748B', '#3E4C61'];
    for (let y = 0; y < 16; y += 2) {
      for (let x = 0; x < 16; x += 2) {
        ctx.fillStyle = cols[(x * 3 + y * 5) % cols.length];
        ctx.fillRect(x, y, 2, 2);
      }
    }
  });

  return { headFront, torso, arm, leg, grassTop, grassSide, stoneTex };
}

function createButterflyWingTexture(primary: string, secondary: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 64;
  c.height = 64;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createRadialGradient(12, 32, 4, 34, 32, 48);
  grad.addColorStop(0, secondary);
  grad.addColorStop(0.55, primary);
  grad.addColorStop(1, '#0F172A');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  ctx.strokeStyle = 'rgba(15,23,42,0.8)';
  ctx.lineWidth = 3;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(0, 32);
    ctx.quadraticCurveTo(28, 8 + i * 9, 60, 6 + i * 10);
    ctx.stroke();
  }
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  ctx.beginPath();
  ctx.arc(46, 20, 4, 0, Math.PI * 2);
  ctx.arc(44, 44, 3, 0, Math.PI * 2);
  ctx.fill();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createSculptedButterflyGeo(scale: number, isUpper: boolean): THREE.ExtrudeGeometry {
  const s = new THREE.Shape();
  if (isUpper) {
    s.moveTo(0, 0);
    s.bezierCurveTo(0.18 * scale, 0.35 * scale, 0.72 * scale, 0.56 * scale, 0.85 * scale, 0.25 * scale);
    s.bezierCurveTo(0.92 * scale, 0.04 * scale, 0.65 * scale, -0.15 * scale, 0, -0.08 * scale);
  } else {
    s.moveTo(0, -0.05 * scale);
    s.bezierCurveTo(0.32 * scale, -0.06 * scale, 0.62 * scale, -0.22 * scale, 0.55 * scale, -0.45 * scale);
    s.bezierCurveTo(0.42 * scale, -0.64 * scale, 0.14 * scale, -0.46 * scale, 0, -0.18 * scale);
  }
  return new THREE.ExtrudeGeometry(s, { depth: 0.025, bevelEnabled: true, bevelThickness: 0.008, bevelSize: 0.008, bevelSegments: 2 });
}

export const PlayerModel3D: React.FC<PlayerModel3DProps> = ({
  equipped,
  primaryDye,
  secondaryDye,
  cosmeticsEnabled,
  animationsEnabled,
  wingFlapSpeed,
  wingSpread,
  customCapeDataUrl,
  customCapeIsGif,
  useCustomCapeImage,
  showcaseScene,
  onChangeScene,
  accentColor,
  pose,
  onCycleNextWing,
  onToast,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [yawDeg, setYawDeg] = useState(148);
  const [pitchDeg, setPitchDeg] = useState(11);
  const [zoom, setZoom] = useState(1.0);
  const [autoSpin, setAutoSpin] = useState(true);
  const [autoReel, setAutoReel] = useState(false);
  const [recording, setRecording] = useState(false);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const draggingRef = useRef<{ active: boolean; x: number; y: number }>({ active: false, x: 0, y: 0 });

  // Custom Cape decoded GIF/Image cache
  const decodedGifRef = useRef<DecodedGifCape | null>(null);
  const staticCapeImgRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    decodedGifRef.current = null;
    staticCapeImgRef.current = null;
    if (!customCapeDataUrl) return;
    if (customCapeIsGif) {
      decodeGifDataUrl(customCapeDataUrl).then((res) => {
        decodedGifRef.current = res;
      });
    } else {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        staticCapeImgRef.current = img;
      };
      img.src = customCapeDataUrl;
    }
  }, [customCapeDataUrl, customCapeIsGif]);

  const stateRef = useRef({
    equipped,
    primaryDye,
    secondaryDye,
    cosmeticsEnabled,
    animationsEnabled,
    wingFlapSpeed,
    wingSpread,
    customCapeDataUrl,
    customCapeIsGif,
    useCustomCapeImage,
    showcaseScene,
    accentColor,
    pose,
    yawDeg,
    pitchDeg,
    zoom,
    autoSpin,
  });
  stateRef.current = {
    equipped,
    primaryDye,
    secondaryDye,
    cosmeticsEnabled,
    animationsEnabled,
    wingFlapSpeed,
    wingSpread,
    customCapeDataUrl,
    customCapeIsGif,
    useCustomCapeImage,
    showcaseScene,
    accentColor,
    pose,
    yawDeg,
    pitchDeg,
    zoom,
    autoSpin,
  };

  useEffect(() => {
    if (!autoReel || !onCycleNextWing) return;
    const id = window.setInterval(() => onCycleNextWing(), 2400);
    return () => window.clearInterval(id);
  }, [autoReel, onCycleNextWing]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      preserveDrawingBuffer: true,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 120);

    // Atmosphere Lighting
    const hemi = new THREE.HemisphereLight(0xc7d2fe, 0x0f172a, 1.0);
    scene.add(hemi);

    const sunLight = new THREE.DirectionalLight(0xfff7ed, 2.0);
    sunLight.position.set(4.5, 8.5, 5.0);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(1024, 1024);
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0x7c5cff, 1.45);
    rimLight.position.set(-4.5, 4.5, -5.0);
    scene.add(rimLight);

    const lanternLight = new THREE.PointLight(0x38bdf8, 2.2, 6.0);
    lanternLight.position.set(-1.35, -0.35, 0.95);
    scene.add(lanternLight);

    const PX = 0.0625;
    const { headFront, torso, arm, leg, grassTop, grassSide, stoneTex } = createRealisticMinecraftSkinTextures(accentColor);

    // Diorama World Group (Realistic + Authentic Minecraft Voxel Environment!)
    const envGroup = new THREE.Group();
    scene.add(envGroup);

    const grassBlockMats = [
      new THREE.MeshStandardMaterial({ map: grassSide, roughness: 0.85 }),
      new THREE.MeshStandardMaterial({ map: grassSide, roughness: 0.85 }),
      new THREE.MeshStandardMaterial({ map: grassTop, roughness: 0.85 }),
      new THREE.MeshStandardMaterial({ color: 0x5c3c24, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ map: grassSide, roughness: 0.85 }),
      new THREE.MeshStandardMaterial({ map: grassSide, roughness: 0.85 }),
    ];
    const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.82 });
    const obsidianMat = new THREE.MeshStandardMaterial({ color: 0x151126, roughness: 0.35, metalness: 0.3 });

    const blockGeo = new THREE.BoxGeometry(0.62, 0.62, 0.62);
    // Build a stepped 5x5 voxel showcase island
    for (let gx = -2; gx <= 2; gx++) {
      for (let gz = -2; gz <= 2; gz++) {
        if (Math.abs(gx) === 2 && Math.abs(gz) === 2) continue;
        const isCenter = Math.abs(gx) <= 1 && Math.abs(gz) <= 1;
        const topBlock = new THREE.Mesh(blockGeo, isCenter ? stoneMat : grassBlockMats);
        topBlock.position.set(gx * 0.62, -1.66, gz * 0.62);
        topBlock.receiveShadow = true;
        topBlock.castShadow = true;
        envGroup.add(topBlock);

        if (isCenter) {
          const under = new THREE.Mesh(blockGeo, obsidianMat);
          under.position.set(gx * 0.62, -2.28, gz * 0.62);
          envGroup.add(under);
        }
      }
    }

    // Glowing Minecraft Soul Lantern Post beside character
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.9, 0.14), new THREE.MeshStandardMaterial({ color: 0x3b281c, roughness: 0.9 }));
    post.position.set(-1.35, -0.9, 0.95);
    post.castShadow = true;
    envGroup.add(post);

    const lantern = new THREE.Mesh(
      new THREE.BoxGeometry(0.24, 0.3, 0.24),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x38bdf8, emissiveIntensity: 1.6, roughness: 0.2 })
    );
    lantern.position.set(-1.35, -0.35, 0.95);
    envGroup.add(lantern);

    // Floating atmospheric motes / blossom petals in 3D space
    const moteCount = 48;
    const moteGroup = new THREE.Group();
    scene.add(moteGroup);
    const moteGeo = new THREE.BoxGeometry(0.055, 0.055, 0.055);
    const moteMat = new THREE.MeshBasicMaterial({ color: 0xf9a8d4, transparent: true, opacity: 0.8 });
    const motes: { mesh: THREE.Mesh; baseX: number; baseY: number; baseZ: number; phase: number }[] = [];
    for (let i = 0; i < moteCount; i++) {
      const m = new THREE.Mesh(moteGeo, moteMat);
      const bx = Math.sin(i * 1.9) * 2.6;
      const by = -0.8 + ((i * 0.37) % 3.2);
      const bz = Math.cos(i * 2.4) * 2.6;
      m.position.set(bx, by, bz);
      moteGroup.add(m);
      motes.push({ mesh: m, baseX: bx, baseY: by, baseZ: bz, phase: i * 0.8 });
    }

    // Player Rig
    const playerRoot = new THREE.Group();
    scene.add(playerRoot);

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xe8b796, roughness: 0.72 });
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x17162b, roughness: 0.82 });
    const headMats = [
      skinMat,
      skinMat,
      hairMat,
      skinMat,
      new THREE.MeshStandardMaterial({ map: headFront, roughness: 0.65 }),
      hairMat,
    ];
    const torsoMat = new THREE.MeshStandardMaterial({ map: torso, roughness: 0.7 });
    const armMat = new THREE.MeshStandardMaterial({ map: arm, roughness: 0.72 });
    const legMat = new THREE.MeshStandardMaterial({ map: leg, roughness: 0.78 });

    const bodyGroup = new THREE.Group();
    bodyGroup.position.y = -0.6;
    playerRoot.add(bodyGroup);

    const headPivot = new THREE.Group();
    headPivot.position.set(0, 12 * PX, 0);
    bodyGroup.add(headPivot);
    const headMesh = new THREE.Mesh(new THREE.BoxGeometry(8 * PX, 8 * PX, 8 * PX), headMats);
    headMesh.position.y = 4 * PX;
    headMesh.castShadow = true;
    headPivot.add(headMesh);

    const torsoMesh = new THREE.Mesh(new THREE.BoxGeometry(8 * PX, 12 * PX, 4 * PX), torsoMat);
    torsoMesh.position.set(0, 6 * PX, 0);
    torsoMesh.castShadow = true;
    bodyGroup.add(torsoMesh);

    const leftArmPivot = new THREE.Group();
    leftArmPivot.position.set(-6 * PX, 11 * PX, 0);
    bodyGroup.add(leftArmPivot);
    const leftArmMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), armMat);
    leftArmMesh.position.y = -5 * PX;
    leftArmMesh.castShadow = true;
    leftArmPivot.add(leftArmMesh);

    const rightArmPivot = new THREE.Group();
    rightArmPivot.position.set(6 * PX, 11 * PX, 0);
    bodyGroup.add(rightArmPivot);
    const rightArmMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), armMat);
    rightArmMesh.position.y = -5 * PX;
    rightArmMesh.castShadow = true;
    rightArmPivot.add(rightArmMesh);

    const leftLegPivot = new THREE.Group();
    leftLegPivot.position.set(-2 * PX, 0, 0);
    bodyGroup.add(leftLegPivot);
    const leftLegMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), legMat);
    leftLegMesh.position.y = -6 * PX;
    leftLegMesh.castShadow = true;
    leftLegPivot.add(leftLegMesh);

    const rightLegPivot = new THREE.Group();
    rightLegPivot.position.set(2 * PX, 0, 0);
    bodyGroup.add(rightLegPivot);
    const rightLegMesh = new THREE.Mesh(new THREE.BoxGeometry(4 * PX, 12 * PX, 4 * PX), legMat);
    rightLegMesh.position.y = -6 * PX;
    rightLegMesh.castShadow = true;
    rightLegPivot.add(rightLegMesh);

    const cosmeticRoot = new THREE.Group();
    bodyGroup.add(cosmeticRoot);

    // Dynamic Cape Texture Canvas (used for both Custom-Made Animated Capes & Uploaded Image/GIF Capes!)
    const capeCanvas = document.createElement('canvas');
    capeCanvas.width = 128;
    capeCanvas.height = 208;
    const capeCtx = capeCanvas.getContext('2d')!;
    const capeTex = new THREE.CanvasTexture(capeCanvas);
    capeTex.magFilter = THREE.NearestFilter;
    capeTex.minFilter = THREE.LinearFilter;
    capeTex.colorSpace = THREE.SRGBColorSpace;

    interface AnimRig {
      leftWingRoot?: THREE.Group;
      leftWingOuter?: THREE.Group;
      rightWingRoot?: THREE.Group;
      rightWingOuter?: THREE.Group;
      wingFeathersL: THREE.Object3D[];
      wingFeathersR: THREE.Object3D[];
      capeMesh?: THREE.Mesh;
      capeBasePositions?: Float32Array;
      capeVariant: number;
      capeColors: [string, string];
      hasCape: boolean;
      haloGroup?: THREE.Group;
      shoulderGroup?: THREE.Group;
      shoulderMiniWings?: [THREE.Object3D, THREE.Object3D];
      backSpinRing?: THREE.Group;
      tailGroup?: THREE.Group[];
      ankleWinglets: [THREE.Object3D, THREE.Object3D][];
    }

    let animRig: AnimRig = {
      wingFeathersL: [],
      wingFeathersR: [],
      ankleWinglets: [],
      capeVariant: 0,
      capeColors: ['#7C5CFF', '#38BDF8'],
      hasCape: false,
    };

    let lastSig = '';

    const rebuildCosmetics = () => {
      while (cosmeticRoot.children.length > 0) cosmeticRoot.remove(cosmeticRoot.children[0]);
      [leftLegPivot, rightLegPivot, leftArmPivot, rightArmPivot, headPivot].forEach((piv) => {
        for (let i = piv.children.length - 1; i >= 1; i--) piv.remove(piv.children[i]);
      });

      animRig = {
        wingFeathersL: [],
        wingFeathersR: [],
        ankleWinglets: [],
        capeVariant: 0,
        capeColors: ['#7C5CFF', '#38BDF8'],
        hasCape: false,
      };

      const st = stateRef.current;
      if (!st.cosmeticsEnabled) return;

      const lookup = (cat: CosmeticCategory) => {
        const id = st.equipped[cat];
        return id ? COSMETICS_CATALOG.find((c) => c.id === id) : undefined;
      };

      const makeMat = (hex: string, glow = false, transparent = false, opacity = 1.0) =>
        new THREE.MeshStandardMaterial({
          color: new THREE.Color(hex),
          roughness: glow ? 0.28 : 0.58,
          metalness: glow ? 0.35 : 0.12,
          emissive: glow ? new THREE.Color(hex) : new THREE.Color(0x000000),
          emissiveIntensity: glow ? 0.65 : 0,
          transparent,
          opacity,
        });

      // 1. Outfit Overlay
      const outfit = lookup('outfitOverlays');
      if (outfit) {
        const p = st.primaryDye || outfit.defaultPrimary;
        const s = st.secondaryDye || outfit.defaultSecondary;
        const chest = new THREE.Mesh(new THREE.BoxGeometry(8.6 * PX, 11.6 * PX, 4.6 * PX), makeMat(p, false, true, 0.95));
        chest.position.set(0, 6 * PX, 0);
        chest.castShadow = true;
        cosmeticRoot.add(chest);
        const sash = new THREE.Mesh(
          new THREE.BoxGeometry((outfit.shapeVariant % 2 === 0 ? 2.4 : 6.4) * PX, 10.2 * PX, 4.9 * PX),
          makeMat(s, outfit.animationType === 'Pulse')
        );
        sash.position.set(0, 6 * PX, 0);
        cosmeticRoot.add(sash);
        const slMat = makeMat(s, outfit.animationType === 'Pulse');
        [leftArmPivot, rightArmPivot].forEach((piv) => {
          const sl = new THREE.Mesh(new THREE.BoxGeometry(4.4 * PX, 9.0 * PX, 4.4 * PX), slMat);
          sl.position.y = -3.9 * PX;
          piv.add(sl);
        });
      }

      // 2. Footwear
      const foot = lookup('footwear');
      if (foot) {
        const p = st.primaryDye || foot.defaultPrimary;
        const s = st.secondaryDye || foot.defaultSecondary;
        const v = foot.shapeVariant;
        [
          [leftLegPivot, -1] as const,
          [rightLegPivot, 1] as const,
        ].forEach(([piv, side]) => {
          const boot = new THREE.Mesh(new THREE.BoxGeometry(4.6 * PX, 4.4 * PX, 4.9 * PX), makeMat(p));
          boot.position.y = -10.1 * PX;
          piv.add(boot);
          const sole = new THREE.Mesh(new THREE.BoxGeometry(4.8 * PX, 1.0 * PX, 5.2 * PX), makeMat(s, true));
          sole.position.y = -11.9 * PX;
          piv.add(sole);
          if (v === 0 || v === 8 || v === 12) {
            const w1 = new THREE.Mesh(new THREE.BoxGeometry(0.4 * PX, 3.0 * PX, 3.4 * PX), makeMat(s, true));
            w1.position.set(side * 2.6 * PX, -9.2 * PX, -0.5 * PX);
            const w2 = new THREE.Mesh(new THREE.BoxGeometry(0.4 * PX, 2.2 * PX, 2.6 * PX), makeMat(p, true));
            w2.position.set(side * 2.7 * PX, -7.8 * PX, -1.2 * PX);
            piv.add(w1, w2);
            animRig.ankleWinglets.push([w1, w2]);
          }
        });
      }

      // 3. Hats
      const hat = lookup('hats');
      if (hat) {
        const p = st.primaryDye || hat.defaultPrimary;
        const s = st.secondaryDye || hat.defaultSecondary;
        const v = hat.shapeVariant;
        const hg = new THREE.Group();
        hg.position.set(0, 8.2 * PX, 0);
        if (v === 0 || v === 6 || v === 13 || v === 17) {
          const band = new THREE.Mesh(new THREE.CylinderGeometry(4.6 * PX, 4.6 * PX, 1.6 * PX, 8), makeMat(p));
          band.rotation.y = Math.PI / 8;
          hg.add(band);
          for (let i = 0; i < 8; i++) {
            const ang = (i * Math.PI) / 4;
            const spire = new THREE.Mesh(new THREE.ConeGeometry(0.8 * PX, (i % 2 === 0 ? 3.2 : 2.1) * PX, 4), makeMat(s, true));
            spire.position.set(Math.cos(ang) * 4.0 * PX, (i % 2 === 0 ? 2.1 : 1.5) * PX, Math.sin(ang) * 4.0 * PX);
            hg.add(spire);
          }
        } else if (v === 1 || v === 10) {
          const brim = new THREE.Mesh(new THREE.CylinderGeometry(6.8 * PX, 6.8 * PX, 0.7 * PX, 12), makeMat(p));
          const cone = new THREE.Mesh(new THREE.ConeGeometry(4.4 * PX, 7.2 * PX, 8), makeMat(p));
          cone.position.y = 3.8 * PX;
          cone.rotation.x = -0.15;
          const buckle = new THREE.Mesh(new THREE.BoxGeometry(2.4 * PX, 1.2 * PX, 0.7 * PX), makeMat(s, true));
          buckle.position.set(0, 1.4 * PX, 3.8 * PX);
          hg.add(brim, cone, buckle);
        } else {
          const dome = new THREE.Mesh(new THREE.BoxGeometry(8.8 * PX, 3.0 * PX, 8.8 * PX), makeMat(p));
          dome.position.y = 0.8 * PX;
          const crest = new THREE.Mesh(new THREE.BoxGeometry(2.0 * PX, 2.2 * PX, 9.2 * PX), makeMat(s, true));
          crest.position.y = 2.6 * PX;
          hg.add(dome, crest);
        }
        headPivot.add(hg);
      }

      // 4. Head Accessories (Segmented Curved Horns, Torus Halos, Orbiting Crystals)
      const headAcc = lookup('headAccessories');
      if (headAcc) {
        const p = st.primaryDye || headAcc.defaultPrimary;
        const s = st.secondaryDye || headAcc.defaultSecondary;
        const v = headAcc.shapeVariant;
        if (v === 0 || v === 2 || v === 8 || v === 12) {
          const halo = new THREE.Group();
          halo.position.set(0, 11.4 * PX, 0);
          const ring = new THREE.Mesh(new THREE.TorusGeometry(5.6 * PX, 0.48 * PX, 10, 32), makeMat(p, true));
          ring.rotation.x = Math.PI / 2;
          halo.add(ring);
          headPivot.add(halo);
          animRig.haloGroup = halo;
        } else if (v === 6 || v === 14) {
          const oc = new THREE.Group();
          oc.position.set(0, 9.6 * PX, 0);
          for (let i = 0; i < 4; i++) {
            const ang = (i * Math.PI) / 2;
            const gem = new THREE.Mesh(new THREE.OctahedronGeometry(1.3 * PX, 0), makeMat(i % 2 === 0 ? p : s, true));
            gem.position.set(Math.cos(ang) * 7.2 * PX, 0, Math.sin(ang) * 7.2 * PX);
            oc.add(gem);
          }
          headPivot.add(oc);
          animRig.haloGroup = oc;
        } else {
          // Segmented tapered curved horns / ears
          [-1, 1].forEach((side) => {
            for (let seg = 0; seg < 4; seg++) {
              const r = (1.1 - seg * 0.2) * PX;
              const hornSeg = new THREE.Mesh(
                new THREE.CylinderGeometry(r * 0.78, r, 1.5 * PX, 6),
                makeMat(seg >= 2 ? s : p, seg >= 2)
              );
              hornSeg.position.set(
                side * (3.6 + seg * 0.75) * PX,
                (8.6 + seg * 1.25) * PX,
                (-0.2 - seg * 0.5) * PX
              );
              hornSeg.rotation.z = side * -(0.28 + seg * 0.14);
              hornSeg.rotation.x = -0.22 * seg;
              headPivot.add(hornSeg);
            }
          });
        }
      }

      // 5. Masks
      const mask = lookup('masks');
      if (mask) {
        const p = st.primaryDye || mask.defaultPrimary;
        const s = st.secondaryDye || mask.defaultSecondary;
        const plate = new THREE.Mesh(new THREE.BoxGeometry(8.2 * PX, 3.4 * PX, 0.8 * PX), makeMat(p));
        plate.position.set(0, 3.0 * PX, 4.2 * PX);
        const eyeL = new THREE.Mesh(new THREE.BoxGeometry(1.9 * PX, 1.0 * PX, 0.45 * PX), makeMat(s, true));
        eyeL.position.set(-2.0 * PX, 3.4 * PX, 4.55 * PX);
        const eyeR = new THREE.Mesh(new THREE.BoxGeometry(1.9 * PX, 1.0 * PX, 0.45 * PX), makeMat(s, true));
        eyeR.position.set(2.0 * PX, 3.4 * PX, 4.55 * PX);
        headPivot.add(plate, eyeL, eyeR);
      }

      // 6. HIGH-DETAIL FLOWING CLOTH CAPE (Supports Custom Image / Animated GIF OR Custom-Made Capes!)
      const cape = lookup('capes');
      if (cape || (st.useCustomCapeImage && st.customCapeDataUrl)) {
        const p = st.primaryDye || cape?.defaultPrimary || '#7C5CFF';
        const s = st.secondaryDye || cape?.defaultSecondary || '#38BDF8';
        animRig.hasCape = true;
        animRig.capeVariant = cape?.shapeVariant ?? 0;
        animRig.capeColors = [p, s];

        // Subdivided flowing cloth plane (4 wide x 12 tall segments!) so cape billows organically!
        const clothGeo = new THREE.PlaneGeometry(10.5 * PX, 17.0 * PX, 4, 12);
        clothGeo.translate(0, -8.5 * PX, 0); // Pivot at collar!
        const clothMat = new THREE.MeshStandardMaterial({
          map: capeTex,
          side: THREE.DoubleSide,
          roughness: 0.65,
          metalness: 0.08,
        });
        const capeMesh = new THREE.Mesh(clothGeo, clothMat);
        capeMesh.position.set(0, 11.6 * PX, -2.35 * PX);
        capeMesh.rotation.x = 0.16;
        capeMesh.castShadow = true;
        cosmeticRoot.add(capeMesh);
        animRig.capeMesh = capeMesh;
        animRig.capeBasePositions = Float32Array.from(clothGeo.attributes.position.array);
      }

      // 7. SCULPTED ARTICULATED 3D WINGS (Feathered Blades, Skeletal Dragon Membranes, Extruded Butterfly Wings)
      const wing = lookup('wings');
      if (wing) {
        const p = st.primaryDye || wing.defaultPrimary;
        const s = st.secondaryDye || wing.defaultSecondary;
        const v = wing.shapeVariant;
        const sp = st.wingSpread;

        const isButterfly = v === 2 || v === 4 || v === 13 || v === 8;
        const isDragonMembrane = v === 1 || v === 6 || v === 21;
        const isCyberBlade = v === 3 || v === 14 || v === 15 || v === 19 || v === 10 || v === 17 || v === 22 || v === 23;

        const primaryMat = makeMat(p, wing.rarity === 'Signature');
        const accentMat = makeMat(s, true);

        const buildWingSide = (side: -1 | 1) => {
          const rootPivot = new THREE.Group();
          rootPivot.position.set(side * 2.1 * PX, 9.8 * PX, -2.4 * PX);
          cosmeticRoot.add(rootPivot);

          const outerPivot = new THREE.Group();
          outerPivot.position.set(side * 8.0 * PX * sp, 1.4 * PX, 0);
          rootPivot.add(outerPivot);

          if (isButterfly) {
            const bTex = createButterflyWingTexture(p, s);
            const bMat = new THREE.MeshStandardMaterial({
              map: bTex,
              roughness: 0.3,
              emissive: new THREE.Color(p),
              emissiveIntensity: 0.25,
              transparent: true,
              opacity: v === 4 ? 0.82 : 0.96,
            });
            const upperGeo = createSculptedButterflyGeo(1.05 * sp, true);
            const lowerGeo = createSculptedButterflyGeo(0.95 * sp, false);
            const upperMesh = new THREE.Mesh(upperGeo, bMat);
            const lowerMesh = new THREE.Mesh(lowerGeo, bMat);
            if (side === -1) {
              upperMesh.scale.x = -1;
              lowerMesh.scale.x = -1;
            }
            upperMesh.castShadow = true;
            rootPivot.add(upperMesh, lowerMesh);
          } else if (isDragonMembrane) {
            // Sculpted Dragon / Bat Skeleton + Triangular Wing Membrane!
            const boneMat = makeMat(p);
            const memMat = new THREE.MeshStandardMaterial({
              color: new THREE.Color(s),
              emissive: new THREE.Color(s),
              emissiveIntensity: 0.22,
              side: THREE.DoubleSide,
              transparent: true,
              opacity: 0.84,
              roughness: 0.5,
            });

            // Shoulder -> Elbow bone
            const armBone = new THREE.Mesh(new THREE.CylinderGeometry(0.45 * PX, 0.65 * PX, 8.5 * PX * sp, 6), boneMat);
            armBone.position.set(side * 4.0 * PX * sp, 1.2 * PX, 0);
            armBone.rotation.z = side * -1.35;
            rootPivot.add(armBone);

            // Outer finger claw spars + stretched membrane triangles
            const tipDirs: [number, number][] = [
              [8.5 * PX * sp, 4.0 * PX * sp],
              [9.5 * PX * sp, -0.5 * PX * sp],
              [7.2 * PX * sp, -5.0 * PX * sp],
              [3.2 * PX * sp, -8.5 * PX * sp],
            ];

            tipDirs.forEach(([tx, ty]) => {
              const len = Math.hypot(tx, ty);
              const spar = new THREE.Mesh(new THREE.CylinderGeometry(0.2 * PX, 0.4 * PX, len, 5), boneMat);
              spar.position.set(side * (tx * 0.5), ty * 0.5, 0);
              spar.rotation.z = Math.atan2(ty, side * tx) - Math.PI / 2;
              outerPivot.add(spar);
            });

            // Build stretched dragon wing membrane mesh across spars
            const verts = new Float32Array([
              0, 0, 0,
              side * tipDirs[0][0], tipDirs[0][1], 0,
              side * tipDirs[1][0], tipDirs[1][1], 0,

              0, 0, 0,
              side * tipDirs[1][0], tipDirs[1][1], 0,
              side * tipDirs[2][0], tipDirs[2][1], 0,

              0, 0, 0,
              side * tipDirs[2][0], tipDirs[2][1], 0,
              side * tipDirs[3][0], tipDirs[3][1], 0,

              // Inner web connecting shoulder to elbow to lower tip
              -side * 7.8 * PX * sp, -2.5 * PX, 0,
              0, 0, 0,
              side * tipDirs[3][0], tipDirs[3][1], 0,
            ]);
            const memGeo = new THREE.BufferGeometry();
            memGeo.setAttribute('position', new THREE.BufferAttribute(verts, 3));
            memGeo.computeVertexNormals();
            const memMesh = new THREE.Mesh(memGeo, memMat);
            outerPivot.add(memMesh);
          } else if (isCyberBlade) {
            // Sleek beveled cyber/valkyrie blades with glowing energy cores
            for (let b = 0; b < 4; b++) {
              const blade = new THREE.Mesh(
                new THREE.ConeGeometry((1.2 - b * 0.15) * PX * sp, (9.5 - b * 1.1) * PX * sp, 4),
                b % 2 === 0 ? primaryMat : accentMat
              );
              blade.position.set(side * (4.6 + b * 1.4) * PX * sp, (3.2 - b * 2.5) * PX, -0.3 * PX);
              blade.rotation.z = side * -(1.25 - b * 0.22);
              (b < 2 ? rootPivot : outerPivot).add(blade);
              (side === -1 ? animRig.wingFeathersL : animRig.wingFeathersR).push(blade);
            }
          } else {
            // Layered Anatomical Feathered Angel/Phoenix/Peacock Wings (10 sculpted tapered feathers per side!)
            const featherShape = new THREE.Shape();
            featherShape.moveTo(-0.045 * sp, 0);
            featherShape.lineTo(0.045 * sp, 0);
            featherShape.lineTo(0.065 * sp, -0.32 * sp);
            featherShape.lineTo(0, -0.46 * sp);
            featherShape.lineTo(-0.065 * sp, -0.32 * sp);
            featherShape.closePath();

            const featherGeo = new THREE.ExtrudeGeometry(featherShape, {
              depth: 0.015,
              bevelEnabled: false,
            });

            // Inner 5 secondary feathers
            for (let f = 0; f < 5; f++) {
              const plume = new THREE.Mesh(featherGeo, f === 4 ? accentMat : primaryMat);
              plume.position.set(side * (1.8 + f * 1.55) * PX * sp, (1.4 - f * 0.15) * PX, -f * 0.08 * PX);
              plume.rotation.z = side * (0.28 - f * 0.08);
              plume.scale.set(1, 0.8 + f * 0.12, 1);
              plume.castShadow = true;
              rootPivot.add(plume);
              (side === -1 ? animRig.wingFeathersL : animRig.wingFeathersR).push(plume);
            }

            // Outer 5 long primary flight feathers
            for (let f = 0; f < 5; f++) {
              const plume = new THREE.Mesh(featherGeo, f >= 3 ? accentMat : primaryMat);
              plume.position.set(side * (0.8 + f * 1.6) * PX * sp, (1.1 - f * 0.65) * PX, -f * 0.08 * PX);
              plume.rotation.z = side * (-0.15 - f * 0.18);
              plume.scale.set(1.05, 1.35 - f * 0.1, 1);
              plume.castShadow = true;
              outerPivot.add(plume);
              (side === -1 ? animRig.wingFeathersL : animRig.wingFeathersR).push(plume);
            }
          }

          return { rootPivot, outerPivot };
        };

        const left = buildWingSide(-1);
        const right = buildWingSide(1);
        animRig.leftWingRoot = left.rootPivot;
        animRig.leftWingOuter = left.outerPivot;
        animRig.rightWingRoot = right.rootPivot;
        animRig.rightWingOuter = right.outerPivot;
      }

      // 8. Shoulder Companion
      const shoulder = lookup('shoulderAccessories');
      if (shoulder) {
        const p = st.primaryDye || shoulder.defaultPrimary;
        const s = st.secondaryDye || shoulder.defaultSecondary;
        const sg = new THREE.Group();
        sg.position.set(-7.8 * PX, 13.5 * PX, 0);
        const pet = new THREE.Mesh(new THREE.BoxGeometry(3.0 * PX, 2.8 * PX, 3.2 * PX), makeMat(p));
        const eye = new THREE.Mesh(new THREE.BoxGeometry(1.5 * PX, 1.0 * PX, 0.5 * PX), makeMat(s, true));
        eye.position.set(0, 0.4 * PX, 1.65 * PX);
        const mwL = new THREE.Mesh(new THREE.BoxGeometry(2.2 * PX, 0.4 * PX, 1.8 * PX), makeMat(s, true));
        mwL.position.set(-2.0 * PX, 0.6 * PX, -0.2 * PX);
        const mwR = new THREE.Mesh(new THREE.BoxGeometry(2.2 * PX, 0.4 * PX, 1.8 * PX), makeMat(s, true));
        mwR.position.set(2.0 * PX, 0.6 * PX, -0.2 * PX);
        sg.add(pet, eye, mwL, mwR);
        cosmeticRoot.add(sg);
        animRig.shoulderGroup = sg;
        animRig.shoulderMiniWings = [mwL, mwR];
      }

      // 9. Back Accessories (Spinning Magic Rings, 9-Tail Fan, Detailed Greatsword)
      const back = lookup('backAccessories');
      if (back) {
        const p = st.primaryDye || back.defaultPrimary;
        const s = st.secondaryDye || back.defaultSecondary;
        const v = back.shapeVariant;
        if (v === 4 || v === 10 || v === 16) {
          const rg = new THREE.Group();
          rg.position.set(0, 7.5 * PX, -3.4 * PX);
          const ringTorus = new THREE.Mesh(new THREE.TorusGeometry(6.8 * PX, 0.35 * PX, 8, 28), makeMat(s, true));
          rg.add(ringTorus);
          for (let i = 0; i < 6; i++) {
            const ang = (i * Math.PI) / 3;
            const node = new THREE.Mesh(new THREE.OctahedronGeometry(1.2 * PX, 0), makeMat(i % 2 === 0 ? p : s, true));
            node.position.set(Math.cos(ang) * 7.2 * PX, Math.sin(ang) * 7.2 * PX, 0);
            rg.add(node);
          }
          cosmeticRoot.add(rg);
          animRig.backSpinRing = rg;
        } else if (v === 12) {
          const tails: THREE.Group[] = [];
          for (let ti = -2; ti <= 2; ti++) {
            const tg = new THREE.Group();
            tg.position.set(0, 1.8 * PX, -2.4 * PX);
            const tMesh = new THREE.Mesh(new THREE.ConeGeometry(1.5 * PX, 9.5 * PX, 5), makeMat(ti === 0 ? s : p, ti === 0));
            tMesh.position.set(ti * 2.1 * PX, 2.2 * PX, -3.2 * PX);
            tMesh.rotation.x = -0.75;
            tMesh.rotation.z = ti * 0.28;
            tg.add(tMesh);
            cosmeticRoot.add(tg);
            tails.push(tg);
          }
          animRig.tailGroup = tails;
        } else {
          // Detailed Greatsword Scabbard + Crossguard
          const swordGroup = new THREE.Group();
          swordGroup.position.set(0, 6.8 * PX, -3.3 * PX);
          swordGroup.rotation.z = 0.55;
          const blade = new THREE.Mesh(new THREE.BoxGeometry(1.8 * PX, 14.0 * PX, 0.55 * PX), makeMat(p));
          const guard = new THREE.Mesh(new THREE.BoxGeometry(5.2 * PX, 1.0 * PX, 1.0 * PX), makeMat(s, true));
          guard.position.y = 4.6 * PX;
          const grip = new THREE.Mesh(new THREE.BoxGeometry(1.0 * PX, 3.2 * PX, 0.7 * PX), makeMat('#78350F'));
          grip.position.y = 6.5 * PX;
          swordGroup.add(blade, guard, grip);
          cosmeticRoot.add(swordGroup);
        }
      }
    };

    const handleResize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(10, Math.round(rect.width));
      const h = Math.max(10, Math.round(rect.height));
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    handleResize();
    const ro = new ResizeObserver(handleResize);
    ro.observe(canvas);

    let raf = 0;
    const start = performance.now();
    let prevTime = start;
    let lastDrawnCustomUrl: string | null = null;

    const animate = (now: number) => {
      const st = stateRef.current;
      const dt = Math.min(0.05, (now - prevTime) * 0.001);
      prevTime = now;

      // Scene lighting & sky color presets
      if (st.showcaseScene === 'cherry-grove') {
        scene.background = new THREE.Color('#130F26');
        scene.fog = new THREE.FogExp2('#130F26', 0.08);
        sunLight.color.set('#FDE68A');
        moteMat.color.set('#F9A8D4');
        lanternLight.color.set('#38BDF8');
      } else if (st.showcaseScene === 'end-citadel') {
        scene.background = new THREE.Color('#090514');
        scene.fog = new THREE.FogExp2('#090514', 0.09);
        sunLight.color.set('#C084FC');
        moteMat.color.set('#A855F7');
        lanternLight.color.set('#EC4899');
      } else if (st.showcaseScene === 'sunset-mesa') {
        scene.background = new THREE.Color('#1E1018');
        scene.fog = new THREE.FogExp2('#1E1018', 0.075);
        sunLight.color.set('#FB923C');
        moteMat.color.set('#FDE047');
        lanternLight.color.set('#F59E0B');
      } else {
        scene.background = new THREE.Color('#090C14');
        scene.fog = new THREE.FogExp2('#090C14', 0.06);
        sunLight.color.set('#FFFFFF');
        moteMat.color.set(st.accentColor);
        lanternLight.color.set(st.accentColor);
      }

      const sig = JSON.stringify([
        st.cosmeticsEnabled,
        st.equipped,
        st.primaryDye,
        st.secondaryDye,
        st.wingSpread,
        st.useCustomCapeImage,
        st.customCapeDataUrl ? st.customCapeDataUrl.slice(0, 48) : null,
      ]);
      if (sig !== lastSig) {
        lastSig = sig;
        lastDrawnCustomUrl = null;
        rebuildCosmetics();
      }

      if (st.autoSpin && !draggingRef.current.active && st.animationsEnabled) {
        setYawDeg((y) => (y + dt * 24) % 360);
      }

      const t = st.animationsEnabled ? (now - start) * 0.001 : 0;
      const flapT = t * st.wingFlapSpeed;

      // Floating atmosphere petals / motes
      motes.forEach((m) => {
        m.mesh.position.y = m.baseY + Math.sin(t * 1.1 + m.phase) * 0.25;
        m.mesh.position.x = m.baseX + Math.cos(t * 0.7 + m.phase) * 0.18;
        m.mesh.rotation.x = t * 0.8 + m.phase;
        m.mesh.rotation.y = t * 1.1;
      });

      // Body & Limb Poses
      const walkRad = st.pose === 'walk' ? Math.sin(t * 6.0) * 0.58 : 0;
      const breathe = st.animationsEnabled ? Math.sin(t * 2.3) * 0.02 : 0;
      bodyGroup.position.y = -0.6 + breathe + (st.pose === 'glide' ? 0.16 : 0);
      bodyGroup.rotation.x = st.pose === 'glide' ? 0.34 : 0;

      leftArmPivot.rotation.x = walkRad * 0.85;
      leftArmPivot.rotation.z = st.pose === 'glide' ? 0.35 : 0.08;
      rightArmPivot.rotation.x = st.pose === 'wave' ? -2.35 + Math.sin(t * 7.2) * 0.35 : -walkRad * 0.85;
      rightArmPivot.rotation.z = st.pose === 'wave' ? -0.35 : st.pose === 'glide' ? -0.35 : -0.08;

      leftLegPivot.rotation.x = st.pose === 'glide' ? 0.18 : -walkRad;
      rightLegPivot.rotation.x = st.pose === 'glide' ? 0.32 : walkRad;

      // Articulated Wings Animation + Individual Feather Fanning
      if (animRig.leftWingRoot && animRig.rightWingRoot) {
        const isGlide = st.pose === 'glide';
        const isWalk = st.pose === 'walk';
        const freq = isWalk ? 4.8 : isGlide ? 3.8 : 3.2;
        const amp = isGlide ? 0.34 : isWalk ? 0.42 : 0.36;
        const baseRest = (isGlide ? 0.25 : 0.44) * (2.0 - Math.min(1.4, st.wingSpread));

        const beat = st.animationsEnabled ? Math.sin(flapT * freq) * amp : 0;
        const outerLag = st.animationsEnabled ? Math.sin(flapT * freq - 0.85) * (amp * 0.72) : 0;

        animRig.leftWingRoot.rotation.y = baseRest + beat;
        animRig.rightWingRoot.rotation.y = -(baseRest + beat);
        if (animRig.leftWingOuter && animRig.rightWingOuter) {
          animRig.leftWingOuter.rotation.y = outerLag;
          animRig.rightWingOuter.rotation.y = -outerLag;
        }
        animRig.wingFeathersL.forEach((f, idx) => {
          f.rotation.x = st.animationsEnabled ? Math.sin(flapT * freq - idx * 0.15) * 0.1 : 0;
        });
        animRig.wingFeathersR.forEach((f, idx) => {
          f.rotation.x = st.animationsEnabled ? Math.sin(flapT * freq - idx * 0.15) * 0.1 : 0;
        });
      }

      // Custom Cape Texture Update (Animated GIF / Uploaded Image / Animated Custom-Made Cape!) + Cloth Ripple Physics
      if (animRig.hasCape && animRig.capeMesh) {
        if (st.useCustomCapeImage && st.customCapeDataUrl) {
          if (st.customCapeIsGif && decodedGifRef.current && decodedGifRef.current.frames.length > 0) {
            const gif = decodedGifRef.current;
            const modMs = (now - start) % Math.max(1, gif.totalDurationMs);
            let acc = 0;
            let frameIdx = 0;
            for (let i = 0; i < gif.frames.length; i++) {
              acc += gif.frames[i].delayMs;
              if (modMs <= acc) {
                frameIdx = i;
                break;
              }
            }
            const tmp = document.createElement('canvas');
            tmp.width = gif.width;
            tmp.height = gif.height;
            tmp.getContext('2d')!.putImageData(gif.frames[frameIdx].imageData, 0, 0);
            capeCtx.clearRect(0, 0, capeCanvas.width, capeCanvas.height);
            capeCtx.drawImage(tmp, 0, 0, capeCanvas.width, capeCanvas.height);
            capeTex.needsUpdate = true;
          } else if (staticCapeImgRef.current && lastDrawnCustomUrl !== st.customCapeDataUrl) {
            capeCtx.clearRect(0, 0, capeCanvas.width, capeCanvas.height);
            capeCtx.drawImage(staticCapeImgRef.current, 0, 0, capeCanvas.width, capeCanvas.height);
            capeTex.needsUpdate = true;
            lastDrawnCustomUrl = st.customCapeDataUrl;
          }
        } else {
          drawCustomCapeCanvas(
            capeCtx,
            capeCanvas.width,
            capeCanvas.height,
            animRig.capeVariant,
            animRig.capeColors[0],
            animRig.capeColors[1],
            t
          );
          capeTex.needsUpdate = true;
        }

        // Smooth cloth vertex wave across the subdivided cape plane
        const baseArr = animRig.capeBasePositions;
        const posAttr = animRig.capeMesh.geometry.attributes.position as THREE.BufferAttribute;
        if (baseArr && posAttr) {
          const arr = posAttr.array as Float32Array;
          const speed = st.pose === 'glide' ? 7.0 : st.pose === 'walk' ? 5.2 : 2.8;
          const swingBase = st.pose === 'glide' ? -0.58 : st.pose === 'walk' ? -0.26 : -0.09;
          for (let i = 0; i < arr.length; i += 3) {
            const bx = baseArr[i];
            const by = baseArr[i + 1];
            const bz = baseArr[i + 2];
            const distFromCollar = Math.max(0, -by); // 0 at top collar -> ~1.06 at hem
            const wave = st.animationsEnabled ? Math.sin(t * speed - distFromCollar * 4.5 + bx * 2.0) * 0.08 * distFromCollar : 0;
            arr[i + 2] = bz + swingBase * distFromCollar + wave;
          }
          posAttr.needsUpdate = true;
          animRig.capeMesh.geometry.computeVertexNormals();
        }
      }

      if (animRig.haloGroup) {
        animRig.haloGroup.rotation.y = st.animationsEnabled ? t * 1.15 : 0;
        animRig.haloGroup.position.y = 10.8 * PX + (st.animationsEnabled ? Math.sin(t * 3.0) * 0.04 : 0);
      }

      if (animRig.shoulderGroup) {
        animRig.shoulderGroup.position.y = 13.5 * PX + (st.animationsEnabled ? Math.sin(t * 3.8) * 0.045 : 0);
        if (animRig.shoulderMiniWings) {
          const mf = st.animationsEnabled ? Math.sin(flapT * 7.5) * 0.55 : 0;
          animRig.shoulderMiniWings[0].rotation.z = -mf;
          animRig.shoulderMiniWings[1].rotation.z = mf;
        }
      }

      animRig.ankleWinglets.forEach(([wL, wR]) => {
        const af = st.animationsEnabled ? Math.sin(flapT * 6.5) * 0.45 : 0;
        wL.rotation.y = 0.35 + af;
        wR.rotation.y = -0.35 - af;
      });

      if (animRig.backSpinRing) animRig.backSpinRing.rotation.z = st.animationsEnabled ? t * 1.45 : 0;
      if (animRig.tailGroup) {
        animRig.tailGroup.forEach((tg, idx) => {
          tg.rotation.y = st.animationsEnabled ? Math.sin(t * 3.0 + idx * 0.6) * 0.18 : 0;
        });
      }

      const radYaw = (st.yawDeg * Math.PI) / 180;
      const radPitch = (st.pitchDeg * Math.PI) / 180;
      const dist = 4.25 / st.zoom;
      camera.position.set(
        Math.sin(radYaw) * Math.cos(radPitch) * dist,
        0.05 + Math.sin(radPitch) * dist,
        Math.cos(radYaw) * Math.cos(radPitch) * dist
      );
      camera.lookAt(0, -0.05, 0);

      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };

    raf = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      capeTex.dispose();
      [headFront, torso, arm, leg, grassTop, grassSide, stoneTex].forEach((tx) => tx.dispose());
      renderer.dispose();
    };
  }, [accentColor]);

  const handleScreenshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `itsm3liodas-3d-showcase-${Date.now()}.png`;
    a.click();
    onToast?.('Screenshot Saved (.png)', 'Captured crisp WebGL 3D Minecraft diorama PNG.', 'success');
  };

  const handleToggleRecord = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (recording && recorderRef.current) {
      recorderRef.current.stop();
      setRecording(false);
      return;
    }
    if (typeof MediaRecorder === 'undefined' || !('captureStream' in canvas)) {
      onToast?.('Recording Unsupported', 'Your browser does not support MediaRecorder canvas capture.', 'warning');
      return;
    }
    try {
      const stream = canvas.captureStream(60);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm';
      const rec = new MediaRecorder(stream, { mimeType });
      recordedChunksRef.current = [];
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };
      rec.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `itsm3liodas-showcase-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
        onToast?.('Video Saved (.webm)', 'Downloaded 60fps 3D showcase clip!', 'success');
      };
      rec.start();
      recorderRef.current = rec;
      setRecording(true);
      onToast?.('Recording Started', 'Click Stop & Save anytime to download .webm video.', 'info');
    } catch {
      onToast?.('Record Error', 'Could not start WebM canvas recorder.', 'error');
    }
  };

  const handleMultiAngleCard = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const sheet = document.createElement('canvas');
    sheet.width = canvas.width;
    sheet.height = canvas.height + 54;
    const ctx = sheet.getContext('2d')!;
    ctx.fillStyle = '#070913';
    ctx.fillRect(0, 0, sheet.width, sheet.height);
    ctx.drawImage(canvas, 0, 54);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 18px "Space Grotesk", sans-serif';
    ctx.fillText('ItsM3liodas Client — MC 1.21.11 3D Showcase', 20, 34);
    const a = document.createElement('a');
    a.href = sheet.toDataURL('image/png');
    a.download = `itsm3liodas-showcase-card-${Date.now()}.png`;
    a.click();
    onToast?.('Showcase Card Saved', 'Exported branded PNG showcase card.', 'success');
  };

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden rounded-xl border border-white/10 bg-[#080B14]">
      <canvas
        ref={canvasRef}
        onMouseDown={(e) => {
          draggingRef.current = { active: true, x: e.clientX, y: e.clientY };
        }}
        onMouseMove={(e) => {
          if (!draggingRef.current.active) return;
          const dx = e.clientX - draggingRef.current.x;
          const dy = e.clientY - draggingRef.current.y;
          draggingRef.current = { active: true, x: e.clientX, y: e.clientY };
          setYawDeg((y) => y - dx * 0.75);
          setPitchDeg((p) => Math.max(-38, Math.min(46, p + dy * 0.45)));
        }}
        onMouseUp={() => (draggingRef.current.active = false)}
        onMouseLeave={() => (draggingRef.current.active = false)}
        onWheel={(e) => {
          e.preventDefault();
          setZoom((z) => Math.max(0.65, Math.min(1.85, z - e.deltaY * 0.001)));
        }}
        className="h-full min-h-[380px] w-full cursor-grab active:cursor-grabbing"
      />

      {/* Top Diorama Scene & Capture Bar */}
      <div className="absolute top-3 right-3 left-3 flex flex-wrap items-center justify-between gap-2">
        {onChangeScene ? (
          <div className="flex flex-wrap gap-1 rounded-lg border border-white/10 bg-black/60 p-1 backdrop-blur-md">
            {(
              [
                { id: 'cherry-grove', label: 'Cherry Grove' },
                { id: 'end-citadel', label: 'End Citadel' },
                { id: 'sunset-mesa', label: 'Sunset Mesa' },
                { id: 'obsidian-studio', label: 'Studio' },
              ] as { id: ShowcaseSceneId; label: string }[]
            ).map((sc) => (
              <button
                key={sc.id}
                type="button"
                onClick={() => onChangeScene(sc.id)}
                className={`rounded-md px-2 py-0.5 text-[10px] font-medium transition-colors ${
                  showcaseScene === sc.id ? 'bg-white/20 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {sc.label}
              </button>
            ))}
          </div>
        ) : (
          <span className="rounded-md border border-white/10 bg-black/55 px-2.5 py-1 text-[11px] font-medium text-slate-200">
            WebGL 3D · Drag Rotate · Scroll Zoom
          </span>
        )}

        <div className="flex flex-wrap items-center gap-1.5">
          {onCycleNextWing && (
            <button
              type="button"
              onClick={() => setAutoReel((r) => !r)}
              className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-medium backdrop-blur-md ${
                autoReel ? 'border-sky-400/50 bg-sky-500/25 text-sky-100' : 'border-white/15 bg-black/60 text-slate-200 hover:bg-white/15'
              }`}
            >
              <Play className="h-3 w-3" /> {autoReel ? 'Cycling...' : 'Cycle Wings'}
            </button>
          )}
          <button
            type="button"
            onClick={handleScreenshot}
            className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/60 px-2 py-1 text-[11px] font-medium text-slate-100 backdrop-blur-md hover:bg-white/15"
          >
            <Camera className="h-3 w-3" /> PNG
          </button>
          <button
            type="button"
            onClick={handleMultiAngleCard}
            className="inline-flex items-center gap-1 rounded-lg border border-white/15 bg-black/60 px-2 py-1 text-[11px] font-medium text-slate-100 backdrop-blur-md hover:bg-white/15"
          >
            <Grid className="h-3 w-3" /> Card
          </button>
          <button
            type="button"
            onClick={handleToggleRecord}
            className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-semibold backdrop-blur-md ${
              recording ? 'animate-pulse border-rose-400/60 bg-rose-600/80 text-white' : 'border-white/15 bg-black/60 text-slate-100 hover:bg-white/15'
            }`}
          >
            {recording ? <Square className="h-3 w-3 fill-white" /> : <Video className="h-3 w-3" />}
            {recording ? 'Stop & Save' : 'Rec Video'}
          </button>
        </div>
      </div>

      {/* Bottom Camera Controls */}
      <div className="absolute right-3 bottom-3 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => setAutoSpin((s) => !s)}
          className={`inline-flex items-center gap-1 rounded-lg border px-2 py-1.5 text-[11px] font-medium backdrop-blur-md ${
            autoSpin ? 'border-emerald-400/40 bg-emerald-500/20 text-emerald-200' : 'border-white/15 bg-black/60 text-slate-300 hover:bg-white/15'
          }`}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${autoSpin && animationsEnabled ? 'animate-spin' : ''}`} />
          Spin
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.min(1.85, z + 0.15))}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => setZoom((z) => Math.max(0.65, z - 0.15))}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            setYawDeg(148);
            setPitchDeg(11);
            setZoom(1.0);
          }}
          className="rounded-lg border border-white/15 bg-black/60 p-1.5 text-slate-200 hover:bg-white/15"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};
