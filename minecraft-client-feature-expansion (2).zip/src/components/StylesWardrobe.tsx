import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  CloudDownload,
  Download,
  Film,
  Heart,
  ImagePlus,
  Layers,
  LayoutGrid,
  Loader2,
  Palette,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  COSMETIC_CATEGORY_LABELS,
  COSMETICS_CATALOG,
  OnlineStylePackListing,
  TRUSTED_ONLINE_STYLE_LIBRARY,
} from '../data/cosmeticsCatalog';
import { ClientConfig, CosmeticCategory, CosmeticItem, OutfitPreset } from '../types/client';
import { drawCustomCapeCanvas } from '../utils/capeEngine';
import { PlayerModel3D } from './PlayerModel3D';
import { SliderRow, ToggleRow } from './SettingTooltip';

interface WardrobeProps {
  config: ClientConfig;
  setConfig: React.Dispatch<React.SetStateAction<ClientConfig>>;
  onEquip: (category: CosmeticCategory, id: string | undefined) => void;
  onToast: (title: string, detail?: string, tone?: 'info' | 'success' | 'warning' | 'error') => void;
}

const CATEGORIES: ('all' | 'favorites' | CosmeticCategory)[] = [
  'all',
  'favorites',
  'wings',
  'capes',
  'hats',
  'headAccessories',
  'masks',
  'shoulderAccessories',
  'backAccessories',
  'footwear',
  'outfitOverlays',
];

function CapeLiveThumb({ item }: { item: CosmeticItem }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    drawCustomCapeCanvas(ctx, c.width, c.height, item.shapeVariant, item.defaultPrimary, item.defaultSecondary, 0.8);
  }, [item]);
  return <canvas ref={ref} width={44} height={68} className="h-12 w-8 shrink-0 rounded border border-white/15 shadow" />;
}

function CosmeticPreviewThumb({ item, large = false }: { item: CosmeticItem; large?: boolean }) {
  if (item.category === 'capes' && !large) {
    return <CapeLiveThumb item={item} />;
  }

  const p = item.defaultPrimary;
  const s = item.defaultSecondary;
  const v = item.shapeVariant;
  const sizeClass = large ? 'h-20 w-full' : 'h-10 w-10 shrink-0';

  return (
    <svg
      viewBox="0 0 36 36"
      className={`${sizeClass} rounded-lg border border-white/10 bg-gradient-to-b from-slate-900/90 to-slate-950 p-1`}
    >
      {item.category === 'wings' && (
        <>
          {v === 2 || v === 4 || v === 13 || v === 8 ? (
            <>
              <g className="mc-wing-left">
                <path d="M18 18 C11 7 2 8 3 16 C4 20 10 21 18 20 Z" fill={p} />
                <path d="M18 20 C12 22 6 28 8 31 C12 31 16 26 18 22 Z" fill={s} opacity="0.9" />
              </g>
              <g className="mc-wing-right">
                <path d="M18 18 C25 7 34 8 33 16 C32 20 26 21 18 20 Z" fill={p} />
                <path d="M18 20 C24 22 30 28 28 31 C24 31 20 26 18 22 Z" fill={s} opacity="0.9" />
              </g>
            </>
          ) : v === 3 || v === 14 || v === 15 || v === 19 ? (
            <>
              <g className="mc-wing-left">
                <polygon points="17,15 3,8 6,13 17,18" fill={p} />
                <polygon points="17,19 4,17 7,21 17,22" fill={s} />
                <polygon points="17,23 7,25 10,29 17,25" fill={p} />
              </g>
              <g className="mc-wing-right">
                <polygon points="19,15 33,8 30,13 19,18" fill={p} />
                <polygon points="19,19 32,17 29,21 19,22" fill={s} />
                <polygon points="19,23 29,25 26,29 19,25" fill={p} />
              </g>
            </>
          ) : (
            <>
              <g className="mc-wing-left">
                <path d="M18 19 C13 7 3 6 3 15 C5 20 9 23 18 21 Z" fill={p} />
                <path d="M17 19 C12 13 5 15 6 24 C10 25 14 24 18 22 Z" fill={s} opacity="0.88" />
              </g>
              <g className="mc-wing-right">
                <path d="M18 19 C23 7 33 6 33 15 C31 20 27 23 18 21 Z" fill={p} />
                <path d="M19 19 C24 13 31 15 30 24 C26 25 22 24 18 22 Z" fill={s} opacity="0.88" />
              </g>
            </>
          )}
          <circle cx="18" cy="19" r="2" fill={s} />
        </>
      )}
      {item.category === 'capes' && (
        <>
          <rect x="10" y="5" width="16" height="26" rx="1.5" fill={p} stroke={s} strokeWidth="1.5" />
          <circle cx="18" cy="15" r="4" fill={s} />
        </>
      )}
      {item.category === 'hats' && (
        <>
          <rect x="6" y="21" width="24" height="4" rx="1.5" fill={p} />
          <path d="M10 21 L14 9 L22 9 L26 21 Z" fill={p} />
          <rect x="13" y="17" width="10" height="3" fill={s} />
        </>
      )}
      {item.category === 'headAccessories' && (
        <>
          <ellipse cx="18" cy="13" rx="11" ry="4" fill="none" stroke={p} strokeWidth="2.8" />
          <circle cx="12" cy="23" r="3" fill={s} />
          <circle cx="24" cy="23" r="3" fill={s} />
        </>
      )}
      {item.category === 'masks' && (
        <>
          <rect x="7" y="11" width="22" height="14" rx="4" fill={p} />
          <rect x="10" y="15" width="5" height="3" rx="1" fill={s} />
          <rect x="21" y="15" width="5" height="3" rx="1" fill={s} />
        </>
      )}
      {item.category === 'shoulderAccessories' && (
        <>
          <rect x="9" y="16" width="18" height="10" rx="3" fill={p} />
          <circle cx="14" cy="13" r="4.5" fill={s} />
        </>
      )}
      {item.category === 'backAccessories' && (
        <>
          <line x1="9" y1="27" x2="27" y2="9" stroke={s} strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="18" cy="18" r="7" fill="none" stroke={p} strokeWidth="3" />
        </>
      )}
      {item.category === 'footwear' && (
        <>
          <path d="M9 10 L16 10 L16 21 L25 22 L25 27 L9 27 Z" fill={p} />
          <rect x="9" y="24" width="16" height="3" fill={s} />
        </>
      )}
      {item.category === 'outfitOverlays' && (
        <>
          <path d="M8 9 L14 7 L18 11 L22 7 L28 9 L26 28 L10 28 Z" fill={p} />
          <rect x="16" y="11" width="4" height="17" fill={s} />
        </>
      )}
    </svg>
  );
}

export const StylesWardrobe: React.FC<WardrobeProps> = ({
  config,
  setConfig,
  onEquip,
  onToast,
}) => {
  const [viewMode, setViewMode] = useState<'wardrobe' | 'showcase'>('wardrobe');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'favorites' | CosmeticCategory>('all');
  const [search, setSearch] = useState('');
  const [pose, setPose] = useState<'idle' | 'walk' | 'glide' | 'wave'>('idle');
  const [newPresetName, setNewPresetName] = useState('');
  const [onlinePanelOpen, setOnlinePanelOpen] = useState(false);
  const [onlineLoading, setOnlineLoading] = useState(false);
  const [onlineItems, setOnlineItems] = useState<OnlineStylePackListing[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const customCapeInputRef = useRef<HTMLInputElement | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return COSMETICS_CATALOG.filter((item) => {
      if (selectedCategory === 'favorites' && !config.cosmetics.favorites.includes(item.id)) return false;
      if (selectedCategory !== 'all' && selectedCategory !== 'favorites' && item.category !== selectedCategory) return false;
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        COSMETIC_CATEGORY_LABELS[item.category].toLowerCase().includes(q)
      );
    });
  }, [selectedCategory, search, config.cosmetics.favorites]);

  const equippedList = useMemo(() => {
    return (Object.entries(config.cosmetics.equipped) as [CosmeticCategory, string][])
      .map(([slot, id]) => ({
        slot,
        item: COSMETICS_CATALOG.find((c) => c.id === id),
      }))
      .filter((x): x is { slot: CosmeticCategory; item: CosmeticItem } => Boolean(x.item));
  }, [config.cosmetics.equipped]);

  const cycleNextWing = () => {
    const wings = COSMETICS_CATALOG.filter((c) => c.category === 'wings');
    const curId = config.cosmetics.equipped.wings;
    const idx = wings.findIndex((w) => w.id === curId);
    const next = wings[(idx + 1) % wings.length];
    setConfig((c) => ({
      ...c,
      cosmetics: {
        ...c.cosmetics,
        equipped: { ...c.cosmetics.equipped, wings: next.id },
        primaryDye: next.defaultPrimary,
        secondaryDye: next.defaultSecondary,
      },
    }));
  };

  const handleUploadCustomCape = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const lower = file.name.toLowerCase();
    const isGif = lower.endsWith('.gif');
    if (!lower.endsWith('.png') && !lower.endsWith('.jpg') && !lower.endsWith('.jpeg') && !lower.endsWith('.webp') && !isGif) {
      onToast('Unsupported File', 'Please select a .png, .jpg, .webp, or animated .gif image.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result);
      setConfig((c) => ({
        ...c,
        cosmetics: {
          ...c.cosmetics,
          customCapeDataUrl: dataUrl,
          customCapeName: file.name,
          customCapeIsGif: isGif,
          useCustomCapeImage: true,
        },
      }));
      onToast(
        isGif ? 'Animated GIF Cape Loaded' : 'Custom Image Cape Loaded',
        `"${file.name}" is now waving live on your 3D cape!`,
        'success'
      );
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const toggleFavorite = (id: string) => {
    setConfig((c) => {
      const exists = c.cosmetics.favorites.includes(id);
      return {
        ...c,
        cosmetics: {
          ...c.cosmetics,
          favorites: exists ? c.cosmetics.favorites.filter((f) => f !== id) : [...c.cosmetics.favorites, id],
        },
      };
    });
  };

  const saveCurrentOutfit = () => {
    const trimmed = newPresetName.trim();
    if (!trimmed) return;
    const preset: OutfitPreset = {
      id: `outfit_${Date.now()}`,
      name: trimmed,
      equipped: { ...config.cosmetics.equipped },
      primaryDye: config.cosmetics.primaryDye,
      secondaryDye: config.cosmetics.secondaryDye,
    };
    setConfig((c) => ({
      ...c,
      cosmetics: {
        ...c.cosmetics,
        outfits: [preset, ...c.cosmetics.outfits],
      },
    }));
    setNewPresetName('');
    onToast('Outfit Saved', `Saved "${trimmed}" preset.`, 'success');
  };

  const applyOutfit = (preset: OutfitPreset) => {
    setConfig((c) => ({
      ...c,
      cosmetics: {
        ...c.cosmetics,
        equipped: { ...preset.equipped },
        primaryDye: preset.primaryDye,
        secondaryDye: preset.secondaryDye,
      },
    }));
    onToast('Outfit Applied', `Equipped "${preset.name}".`, 'success');
  };

  const exportStylePack = () => {
    const payload = {
      format: 'itsm3liodas-style-pack-v1',
      targetMinecraft: '1.21.11',
      author: 'Local Player',
      exportedAt: new Date().toISOString(),
      outfit: {
        id: `exported_${Date.now()}`,
        name: 'My ItsM3liodas Style Pack',
        equipped: config.cosmetics.equipped,
        primaryDye: config.cosmetics.primaryDye,
        secondaryDye: config.cosmetics.secondaryDye,
      },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'itsm3liodas-style-pack.json';
    a.click();
    URL.revokeObjectURL(url);
    onToast('Style Pack Exported', 'Saved validated style pack JSON.', 'success');
  };

  const handleImportStylePack = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.json')) {
      onToast('Validation Blocked', 'Style packs must be verified .json manifest bundles.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (parsed.format !== 'itsm3liodas-style-pack-v1' || !parsed.outfit || typeof parsed.outfit.equipped !== 'object') {
          onToast('Invalid Style Pack', 'Unsupported style pack schema.', 'error');
          return;
        }
        const validIds = new Set(COSMETICS_CATALOG.map((c) => c.id));
        const cleanEquipped: Partial<Record<CosmeticCategory, string>> = {};
        for (const [k, v] of Object.entries(parsed.outfit.equipped)) {
          if (typeof v === 'string' && validIds.has(v)) {
            cleanEquipped[k as CosmeticCategory] = v;
          }
        }
        const importedPreset: OutfitPreset = {
          id: `imported_${Date.now()}`,
          name: String(parsed.outfit.name || 'Imported Style').slice(0, 40),
          equipped: cleanEquipped,
          primaryDye: String(parsed.outfit.primaryDye || '#7C5CFF'),
          secondaryDye: String(parsed.outfit.secondaryDye || '#38BDF8'),
        };
        setConfig((c) => ({
          ...c,
          cosmetics: {
            ...c.cosmetics,
            equipped: importedPreset.equipped,
            primaryDye: importedPreset.primaryDye,
            secondaryDye: importedPreset.secondaryDye,
            outfits: [importedPreset, ...c.cosmetics.outfits],
          },
        }));
        onToast('Style Pack Imported', `Validated and equipped "${importedPreset.name}".`, 'success');
      } catch {
        onToast('Import Failed', 'Malformed JSON inside style pack.', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const fetchTrustedLibraryAsync = () => {
    setOnlinePanelOpen(true);
    setOnlineLoading(true);
    window.setTimeout(() => {
      setOnlineItems(TRUSTED_ONLINE_STYLE_LIBRARY);
      setOnlineLoading(false);
    }, 550);
  };

  if (viewMode === 'showcase') {
    return (
      <div className="flex h-full flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-[#0D101B] px-3.5 py-2.5">
          <div>
            <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
              <LayoutGrid className="h-4 w-4" style={{ color: config.theme.accentColor }} />
              All {COSMETICS_CATALOG.length} Free Cosmetics &amp; Capes Showcase
            </h2>
            <p className="text-[11px] text-slate-400">
              Click any item to equip it onto your 3D Minecraft Diorama Model for PNG screenshots or 60fps WebM video capture.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter showcase..."
                className="w-44 rounded-lg border border-white/10 bg-black/40 py-1 pr-2.5 pl-8 text-xs text-white placeholder-slate-500"
              />
            </div>
            <button
              type="button"
              onClick={() => setViewMode('wardrobe')}
              style={{ backgroundColor: config.theme.accentColor }}
              className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold text-white"
            >
              <Sparkles className="h-3.5 w-3.5" /> Back to 3D Studio
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((cat) => {
            const catCount =
              cat === 'all'
                ? COSMETICS_CATALOG.length
                : cat === 'favorites'
                ? config.cosmetics.favorites.length
                : COSMETICS_CATALOG.filter((c) => c.category === cat).length;
            const label =
              cat === 'all'
                ? `All (${catCount})`
                : cat === 'favorites'
                ? `Favorites (${catCount})`
                : `${COSMETIC_CATEGORY_LABELS[cat]} (${catCount})`;
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                  active ? 'border-transparent text-white' : 'border-white/10 bg-[#0D101B] text-slate-300 hover:bg-white/10'
                }`}
                style={active ? { backgroundColor: config.theme.accentColor } : undefined}
              >
                {label}
              </button>
            );
          })}
        </div>

        <div className="grid max-h-[600px] grid-cols-2 gap-2.5 overflow-y-auto pr-1 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {filtered.map((item) => {
            const isEquipped = config.cosmetics.equipped[item.category] === item.id;
            return (
              <div
                key={item.id}
                onClick={() => {
                  onEquip(item.category, item.id);
                  setConfig((c) => ({
                    ...c,
                    cosmetics: {
                      ...c.cosmetics,
                      ...(item.category === 'capes' ? { useCustomCapeImage: false } : {}),
                      primaryDye: item.defaultPrimary,
                      secondaryDye: item.defaultSecondary,
                    },
                  }));
                  setViewMode('wardrobe');
                  onToast('Equipped on 3D Model', `Previewing "${item.name}" in 3D Minecraft Diorama.`, 'success');
                }}
                className={`cursor-pointer rounded-xl border p-2.5 transition-all hover:scale-[1.02] ${
                  isEquipped ? 'border-white/45 bg-white/15' : 'border-white/10 bg-[#0D101B] hover:border-white/25 hover:bg-white/[0.06]'
                }`}
              >
                <CosmeticPreviewThumb item={item} large />
                <div className="mt-2 truncate text-xs font-semibold text-white">{item.name}</div>
                <div className="mt-0.5 flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">{COSMETIC_CATEGORY_LABELS[item.category]}</span>
                  <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-violet-200">{item.rarity}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="grid h-full grid-cols-1 gap-4 lg:grid-cols-12">
      {/* Left: Realistic + Minecraft Voxel 3D Showcase */}
      <div className="flex flex-col gap-3 lg:col-span-5">
        <div className="flex items-center justify-between rounded-xl border border-white/10 bg-[#0D101B] px-3.5 py-2.5">
          <div>
            <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Sparkles className="h-4 w-4" style={{ color: config.theme.accentColor }} />
              3D Cosmetics &amp; Capes Studio
            </h2>
            <p className="text-[11px] text-slate-400">
              {COSMETICS_CATALOG.length} Free Cosmetics · Custom PNG/GIF Capes · WebGL Diorama
            </p>
          </div>
          <button
            type="button"
            onClick={() => setViewMode('showcase')}
            className="inline-flex items-center gap-1 rounded-lg border border-violet-400/40 bg-violet-500/20 px-2.5 py-1 text-[11px] font-semibold text-violet-100 hover:bg-violet-500/35"
          >
            <LayoutGrid className="h-3.5 w-3.5" /> Showcase All {COSMETICS_CATALOG.length}
          </button>
        </div>

        <div className="min-h-[385px] flex-1">
          <PlayerModel3D
            equipped={config.cosmetics.equipped}
            primaryDye={config.cosmetics.primaryDye}
            secondaryDye={config.cosmetics.secondaryDye}
            cosmeticsEnabled={config.cosmetics.enabled}
            animationsEnabled={config.cosmetics.animationsEnabled}
            wingFlapSpeed={config.cosmetics.wingFlapSpeed}
            wingSpread={config.cosmetics.wingSpread}
            customCapeDataUrl={config.cosmetics.customCapeDataUrl}
            customCapeIsGif={config.cosmetics.customCapeIsGif}
            useCustomCapeImage={config.cosmetics.useCustomCapeImage}
            showcaseScene={config.cosmetics.showcaseScene}
            onChangeScene={(sc) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, showcaseScene: sc } }))}
            accentColor={config.theme.accentColor}
            pose={pose}
            onCycleNextWing={cycleNextWing}
            onToast={onToast}
          />
        </div>

        {/* Custom Image / Animated GIF Cape Studio */}
        <div className="space-y-2 rounded-xl border border-sky-400/25 bg-[#0B1220] p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-200">
              <Film className="h-4 w-4" />
              Custom Image / Animated GIF Cape
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => customCapeInputRef.current?.click()}
                style={{ backgroundColor: config.theme.accentColor }}
                className="inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-semibold text-white hover:opacity-90"
              >
                <ImagePlus className="h-3.5 w-3.5" /> Upload PNG / GIF
              </button>
              <input
                ref={customCapeInputRef}
                type="file"
                accept=".png,.jpg,.jpeg,.webp,.gif,image/*"
                onChange={handleUploadCustomCape}
                className="hidden"
              />
              {config.cosmetics.customCapeDataUrl && (
                <button
                  type="button"
                  onClick={() =>
                    setConfig((c) => ({
                      ...c,
                      cosmetics: {
                        ...c.cosmetics,
                        customCapeDataUrl: null,
                        customCapeName: null,
                        useCustomCapeImage: false,
                      },
                    }))
                  }
                  className="rounded-lg border border-white/15 bg-white/5 p-1 text-slate-300 hover:text-rose-300"
                  title="Remove custom image/GIF cape"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {config.cosmetics.customCapeDataUrl ? (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-black/40 p-2">
              <div className="flex min-w-0 items-center gap-2">
                <img
                  src={config.cosmetics.customCapeDataUrl}
                  alt="Custom Cape"
                  className="h-9 w-6 rounded border border-white/20 object-cover"
                />
                <div className="min-w-0">
                  <div className="truncate text-xs font-medium text-white">{config.cosmetics.customCapeName}</div>
                  <div className="text-[10px] text-emerald-300">
                    {config.cosmetics.customCapeIsGif ? 'Animated GIF frames playing on 3D Cape' : 'Static Image mapped on 3D Cape'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  setConfig((c) => ({
                    ...c,
                    cosmetics: { ...c.cosmetics, useCustomCapeImage: !c.cosmetics.useCustomCapeImage },
                  }))
                }
                className={`rounded-md px-2.5 py-1 text-[11px] font-semibold ${
                  config.cosmetics.useCustomCapeImage ? 'bg-emerald-500/25 text-emerald-200' : 'bg-white/10 text-slate-300'
                }`}
              >
                {config.cosmetics.useCustomCapeImage ? 'Active' : 'Use Custom'}
              </button>
            </div>
          ) : (
            <p className="text-[11px] text-slate-400">
              Upload any <strong>.PNG, .JPG, or animated .GIF</strong> to wear it as a flowing 3D cape, or pick any custom-made cape on the right!
            </p>
          )}
        </div>

        {/* Pose & Wing Motion Controls */}
        <div className="space-y-2.5 rounded-xl border border-white/10 bg-[#0D101B] p-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-medium text-slate-300">Pose</span>
            <div className="flex gap-1">
              {(['idle', 'walk', 'glide', 'wave'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPose(p)}
                  className={`rounded-md px-2.5 py-1 text-[11px] font-medium capitalize transition-colors ${
                    pose === p ? 'text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                  }`}
                  style={pose === p ? { backgroundColor: config.theme.accentColor } : undefined}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <ToggleRow
              label="Cosmetics Master"
              checked={config.cosmetics.enabled}
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, enabled: v } }))}
            />
            <ToggleRow
              label="Wings & Motion"
              checked={config.cosmetics.animationsEnabled}
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, animationsEnabled: v } }))}
            />
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <SliderRow
              label="Wing Flap Speed"
              value={config.cosmetics.wingFlapSpeed}
              min={0.25}
              max={2.4}
              step={0.05}
              unit="x"
              docKey="cosmetics.wingFlapSpeed"
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, wingFlapSpeed: v } }))}
            />
            <SliderRow
              label="Wing Spread"
              value={config.cosmetics.wingSpread}
              min={0.65}
              max={1.55}
              step={0.05}
              unit="x"
              docKey="cosmetics.wingSpread"
              accentColor={config.theme.accentColor}
              onChange={(v) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, wingSpread: v } }))}
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/35 px-2.5 py-1.5 text-xs">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Palette className="h-3.5 w-3.5" /> Primary Dye
              </span>
              <input
                type="color"
                value={config.cosmetics.primaryDye}
                onChange={(e) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, primaryDye: e.target.value } }))}
                className="h-5 w-7 cursor-pointer rounded border-0 bg-transparent"
              />
            </label>
            <label className="flex items-center justify-between rounded-lg border border-white/10 bg-black/35 px-2.5 py-1.5 text-xs">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Palette className="h-3.5 w-3.5" /> Accent Dye
              </span>
              <input
                type="color"
                value={config.cosmetics.secondaryDye}
                onChange={(e) => setConfig((c) => ({ ...c, cosmetics: { ...c.cosmetics, secondaryDye: e.target.value } }))}
                className="h-5 w-7 cursor-pointer rounded border-0 bg-transparent"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Right: Catalog, Search, Presets & Style Packs */}
      <div className="flex flex-col gap-3 lg:col-span-7">
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-[#0D101B] p-3">
          <div className="relative min-w-[200px] flex-1">
            <Search className="absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search ${COSMETICS_CATALOG.length} cosmetics & capes...`}
              className="w-full rounded-lg border border-white/10 bg-black/40 py-1.5 pr-3 pl-8 text-xs text-white placeholder-slate-500 focus:border-white/30 focus:outline-none"
            />
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={fetchTrustedLibraryAsync}
              className="inline-flex items-center gap-1.5 rounded-lg border border-sky-400/30 bg-sky-500/15 px-2.5 py-1.5 text-xs font-medium text-sky-200 hover:bg-sky-500/25"
            >
              <CloudDownload className="h-3.5 w-3.5" /> Online Library
            </button>
            <button
              type="button"
              onClick={exportStylePack}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-white/10"
            >
              <Download className="h-3.5 w-3.5" /> Export
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1.5 text-xs text-slate-200 hover:bg-white/10"
            >
              <Upload className="h-3.5 w-3.5" /> Import
            </button>
            <input ref={fileInputRef} type="file" accept=".json" onChange={handleImportStylePack} className="hidden" />
          </div>
        </div>

        {onlinePanelOpen && (
          <div className="rounded-xl border border-sky-400/30 bg-sky-950/30 p-3">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-sky-200">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                Trusted Online Style Library (Async · Validated JSON Only)
              </div>
              <button type="button" onClick={() => setOnlinePanelOpen(false)} className="text-xs text-slate-400 hover:text-white">
                Close
              </button>
            </div>
            {onlineLoading ? (
              <div className="flex items-center gap-2 py-3 text-xs text-slate-300">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading verified style manifests...
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                {onlineItems.map((entry) => (
                  <div key={entry.id} className="rounded-lg border border-white/10 bg-black/40 p-2.5 text-xs">
                    <div className="font-semibold text-white">{entry.name}</div>
                    <div className="mt-0.5 text-[10px] text-slate-400">
                      by {entry.author} · v{entry.version}
                    </div>
                    <p className="mt-1 text-[11px] text-slate-300">{entry.description}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="font-mono text-[10px] text-emerald-300">{entry.sha256Preview}</span>
                      <button
                        type="button"
                        onClick={() => applyOutfit(entry.preset)}
                        className="rounded bg-sky-500/25 px-2 py-1 text-[11px] font-medium text-sky-200 hover:bg-sky-500/40"
                      >
                        Apply
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-[#0D101B] px-3 py-2">
          <span className="flex items-center gap-1 text-[11px] font-semibold text-slate-300">
            <Layers className="h-3.5 w-3.5" /> Outfits:
          </span>
          {config.cosmetics.outfits.map((preset) => (
            <div key={preset.id} className="inline-flex items-center overflow-hidden rounded-lg border border-white/10 bg-white/5">
              <button
                type="button"
                onClick={() => applyOutfit(preset)}
                className="px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:bg-white/10"
              >
                {preset.name}
              </button>
              {preset.id.startsWith('outfit_') && (
                <button
                  type="button"
                  onClick={() =>
                    setConfig((c) => ({
                      ...c,
                      cosmetics: { ...c.cosmetics, outfits: c.cosmetics.outfits.filter((o) => o.id !== preset.id) },
                    }))
                  }
                  className="px-1.5 py-1 text-slate-400 hover:text-rose-300"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              )}
            </div>
          ))}
          <div className="ml-auto flex items-center gap-1">
            <input
              type="text"
              value={newPresetName}
              onChange={(e) => setNewPresetName(e.target.value)}
              placeholder="Save outfit..."
              className="w-28 rounded-md border border-white/10 bg-black/40 px-2 py-1 text-[11px] text-white placeholder-slate-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={saveCurrentOutfit}
              className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-white"
              style={{ backgroundColor: config.theme.accentColor }}
            >
              <Plus className="h-3 w-3" /> Save
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((cat) => {
            const catCount =
              cat === 'all'
                ? COSMETICS_CATALOG.length
                : cat === 'favorites'
                ? config.cosmetics.favorites.length
                : COSMETICS_CATALOG.filter((c) => c.category === cat).length;
            const label =
              cat === 'all'
                ? `All (${catCount})`
                : cat === 'favorites'
                ? `Favorites (${catCount})`
                : `${COSMETIC_CATEGORY_LABELS[cat]} (${catCount})`;
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                  active ? 'border-transparent text-white' : 'border-white/10 bg-[#0D101B] text-slate-300 hover:bg-white/10'
                }`}
                style={active ? { backgroundColor: config.theme.accentColor } : undefined}
              >
                {label}
              </button>
            );
          })}
        </div>

        <div className="grid max-h-[465px] grid-cols-1 gap-2.5 overflow-y-auto pr-1 sm:grid-cols-2">
          {filtered.map((item) => {
            const isEquipped = config.cosmetics.equipped[item.category] === item.id;
            const isFav = config.cosmetics.favorites.includes(item.id);
            return (
              <div
                key={item.id}
                className={`flex flex-col justify-between rounded-xl border p-2.5 transition-all ${
                  isEquipped
                    ? 'border-white/35 bg-white/[0.08]'
                    : 'border-white/10 bg-[#0D101B] hover:border-white/20 hover:bg-white/[0.04]'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <CosmeticPreviewThumb item={item} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      <span className="truncate text-xs font-semibold text-white">{item.name}</span>
                      <button
                        type="button"
                        onClick={() => toggleFavorite(item.id)}
                        className="shrink-0 text-slate-400 hover:text-rose-400"
                      >
                        <Heart className={`h-3.5 w-3.5 ${isFav ? 'fill-rose-400 text-rose-400' : ''}`} />
                      </button>
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10px]">
                      <span className="rounded bg-white/10 px-1.5 py-0.5 text-slate-300">
                        {COSMETIC_CATEGORY_LABELS[item.category]}
                      </span>
                      <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-violet-200">{item.rarity}</span>
                      <span className="text-slate-400">{item.animationType}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[11px] text-slate-300">{item.description}</p>
                  </div>
                </div>
                <div className="mt-2.5 flex items-center justify-between border-t border-white/10 pt-2">
                  <div className="flex items-center gap-1">
                    <span className="h-3 w-3 rounded-full border border-white/20" style={{ backgroundColor: item.defaultPrimary }} />
                    <span className="h-3 w-3 rounded-full border border-white/20" style={{ backgroundColor: item.defaultSecondary }} />
                    <span className="ml-1 text-[10px] text-emerald-300">Free</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onEquip(item.category, item.id);
                      setConfig((c) => ({
                        ...c,
                        cosmetics: {
                          ...c.cosmetics,
                          ...(item.category === 'capes' ? { useCustomCapeImage: false } : {}),
                          primaryDye: item.defaultPrimary,
                          secondaryDye: item.defaultSecondary,
                        },
                      }));
                    }}
                    className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
                      isEquipped ? 'bg-emerald-500/25 text-emerald-200' : 'text-white'
                    }`}
                    style={!isEquipped ? { backgroundColor: config.theme.accentColor } : undefined}
                  >
                    {isEquipped ? (
                      <>
                        <Check className="h-3 w-3" /> Equipped
                      </>
                    ) : (
                      'Equip & Preview'
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Equipped summary strip */}
        {equippedList.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/10 bg-[#0D101B] px-3 py-2 text-[11px]">
            <span className="font-semibold text-slate-400">Active ({equippedList.length}/9):</span>
            {equippedList.map(({ slot, item }) => (
              <button
                key={slot}
                type="button"
                onClick={() => onEquip(slot, undefined)}
                className="rounded border border-white/10 bg-white/5 px-2 py-0.5 text-slate-200 hover:border-rose-400/40 hover:bg-rose-500/15"
              >
                {item.name} ×
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
