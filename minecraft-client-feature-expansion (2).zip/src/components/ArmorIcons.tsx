import React from 'react';

export type ArmorSlotKind = 'helmet' | 'chestplate' | 'leggings' | 'boots' | 'shield';

interface ArmorPixelIconProps {
  kind: ArmorSlotKind;
  enchanted?: boolean;
  size?: number;
}

export const ArmorPixelIcon: React.FC<ArmorPixelIconProps> = ({
  kind,
  enchanted = true,
  size = 24,
}) => {
  return (
    <div className="relative inline-flex items-center justify-center overflow-hidden" style={{ width: size, height: size }}>
      <svg viewBox="0 0 16 16" width={size} height={size} shapeRendering="crispEdges">
        {kind === 'helmet' && (
          <>
            <rect x="4" y="2" width="8" height="2" fill="#5EEAD4" />
            <rect x="3" y="3" width="10" height="3" fill="#2DD4BF" />
            <rect x="3" y="6" width="3" height="5" fill="#14B8A6" />
            <rect x="10" y="6" width="3" height="5" fill="#14B8A6" />
            <rect x="5" y="6" width="6" height="2" fill="#0F766E" />
            <rect x="4" y="3" width="4" height="1" fill="#CCFBF1" />
          </>
        )}
        {kind === 'chestplate' && (
          <>
            <rect x="2" y="2" width="4" height="5" fill="#2DD4BF" />
            <rect x="10" y="2" width="4" height="5" fill="#2DD4BF" />
            <rect x="4" y="3" width="8" height="10" fill="#14B8A6" />
            <rect x="6" y="3" width="4" height="2" fill="#0F172A" />
            <rect x="5" y="5" width="6" height="3" fill="#5EEAD4" />
            <rect x="4" y="11" width="8" height="2" fill="#0F766E" />
          </>
        )}
        {kind === 'leggings' && (
          <>
            <rect x="4" y="2" width="8" height="3" fill="#3B82F6" />
            <rect x="4" y="5" width="3" height="8" fill="#1D4ED8" />
            <rect x="9" y="5" width="3" height="8" fill="#1D4ED8" />
            <rect x="5" y="3" width="6" height="1" fill="#93C5FD" />
            <rect x="4" y="11" width="3" height="2" fill="#1E3A8A" />
            <rect x="9" y="11" width="3" height="2" fill="#1E3A8A" />
          </>
        )}
        {kind === 'boots' && (
          <>
            <rect x="3" y="6" width="4" height="6" fill="#334155" />
            <rect x="9" y="6" width="4" height="6" fill="#334155" />
            <rect x="2" y="10" width="5" height="3" fill="#475569" />
            <rect x="9" y="10" width="5" height="3" fill="#475569" />
            <rect x="3" y="6" width="4" height="2" fill="#7C5CFF" />
            <rect x="9" y="6" width="4" height="2" fill="#7C5CFF" />
          </>
        )}
        {kind === 'shield' && (
          <>
            <rect x="3" y="2" width="10" height="11" fill="#78350F" />
            <rect x="4" y="3" width="8" height="9" fill="#94A3B8" />
            <rect x="5" y="4" width="6" height="7" fill="#4F46E5" />
            <rect x="7" y="5" width="2" height="5" fill="#FACC15" />
          </>
        )}
      </svg>
      {enchanted && <div className="mc-glint pointer-events-none absolute inset-0 mix-blend-screen" />}
    </div>
  );
};
