import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  Compass,
  Disc3,
  Eye,
  Move,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  Sparkles,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { LiveWorldTelemetry, MusicPlayerState } from '../store/useClientStore';
import {
  ClientConfig,
  FONT_FAMILY_META,
  HudElementConfig,
  HudElementId,
} from '../types/client';
import { ArmorPixelIcon, ArmorSlotKind } from './ArmorIcons';

interface MinecraftViewportProps {
  config: ClientConfig;
  world: LiveWorldTelemetry;
  setWorld: React.Dispatch<React.SetStateAction<LiveWorldTelemetry>>;
  musicState?: MusicPlayerState;
  onTogglePlayMusic?: () => void;
  onStepTrack?: (dir: 1 | -1) => void;
  onUpdateLyricsPos?: (x: number, y: number) => void;
  onMouseAction: (btn: 0 | 2, down: boolean) => void;
  interactiveMode?: boolean;
  onUpdateHudPosition?: (id: HudElementId, x: number, y: number) => void;
  selectedHudId?: HudElementId | null;
  onSelectHudId?: (id: HudElementId) => void;
  hudEditMode?: boolean;
}

const SHULKER_CONTENTS = [
  { name: 'Netherite Sword', count: 1, color: '#64748B', enchant: 'Sharpness V · Unbreaking III', dur: 94 },
  { name: 'Enchanted Golden Apple', count: 12, color: '#FACC15', enchant: 'Glint', dur: null },
  { name: 'Totem of Undying', count: 1, color: '#FDE047', enchant: null, dur: null },
  { name: 'Ender Pearl', count: 16, color: '#14B8A6', enchant: null, dur: null },
  { name: 'Diamond Pickaxe', count: 1, color: '#38BDF8', enchant: 'Efficiency V · Silk Touch', dur: 76 },
  { name: 'Chorus Fruit', count: 32, color: '#C084FC', enchant: null, dur: null },
  { name: 'Potion of Swiftness II', count: 1, color: '#7DD3FC', enchant: 'Speed II (1:30)', dur: null },
  { name: 'Rocket Firework', count: 64, color: '#F43F5E', enchant: 'Flight Duration 3', dur: null },
  { name: 'Obsidian', count: 64, color: '#312E81', enchant: null, dur: null },
];

function createBlockTex(draw: (ctx: CanvasRenderingContext2D) => void) {
  const c = document.createElement('canvas');
  c.width = 16;
  c.height = 16;
  draw(c.getContext('2d')!);
  const t = new THREE.CanvasTexture(c);
  t.magFilter = THREE.NearestFilter;
  t.minFilter = THREE.NearestFilter;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export const MinecraftViewport: React.FC<MinecraftViewportProps> = ({
  config,
  world,
  setWorld,
  musicState,
  onTogglePlayMusic,
  onStepTrack,
  onUpdateLyricsPos,
  onMouseAction,
  interactiveMode = true,
  onUpdateHudPosition,
  selectedHudId,
  onSelectHudId,
  hudEditMode = false,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const trailCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [shulkerHovered, setShulkerHovered] = useState(false);
  const [clockTick, setClockTick] = useState(() => new Date());
  const draggingHudRef = useRef<{ id: HudElementId; offsetX: number; offsetY: number } | null>(null);
  const draggingLyricRef = useRef<{ active: boolean; offsetX: number; offsetY: number }>({ active: false, offsetX: 0, offsetY: 0 });
  const camDragRef = useRef<{ active: boolean; lastX: number; lastY: number }>({ active: false, lastX: 0, lastY: 0 });
  const zoomAnimRef = useRef(1.0);
  const prevAnglesRef = useRef({ yaw: world.yaw, pitch: world.pitch });
  const fpsCounterRef = useRef({ frames: 0, lastReport: performance.now() });

  const stateRef = useRef({ config, world });
  stateRef.current = { config, world };

  useEffect(() => {
    const id = window.setInterval(() => setClockTick(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const activeTrack = useMemo(() => {
    if (!musicState) return null;
    return musicState.tracks.find((t) => t.id === musicState.currentTrackId) ?? musicState.tracks[0] ?? null;
  }, [musicState]);

  const lyricCursor = useMemo(() => {
    if (!activeTrack || !musicState) return { prev: null, current: null, next: null };
    const pos = musicState.positionSec;
    let activeIdx = 0;
    for (let i = 0; i < activeTrack.lyrics.length; i++) {
      if (activeTrack.lyrics[i].timeSec <= pos) activeIdx = i;
      else break;
    }
    return {
      prev: activeIdx > 0 ? activeTrack.lyrics[activeIdx - 1] : null,
      current: activeTrack.lyrics[activeIdx] ?? null,
      next: activeIdx + 1 < activeTrack.lyrics.length ? activeTrack.lyrics[activeIdx + 1] : null,
    };
  }, [activeTrack, musicState]);

  // Real Three.js WebGL 3D Minecraft World Viewport!
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(72, 1, 0.1, 140);

    const hemi = new THREE.HemisphereLight(0xc7d2fe, 0x0f172a, 1.0);
    scene.add(hemi);
    const moonLight = new THREE.DirectionalLight(0xe0e7ff, 1.65);
    moonLight.position.set(14, 24, -18);
    moonLight.castShadow = true;
    scene.add(moonLight);

    // Procedural Crisp Minecraft Block Textures
    const grassTopTex = createBlockTex((ctx) => {
      ctx.fillStyle = '#387A47';
      ctx.fillRect(0, 0, 16, 16);
      const shades = ['#4A965B', '#2E663A', '#56AB68', '#336E40'];
      for (let y = 0; y < 16; y += 2) {
        for (let x = 0; x < 16; x += 2) {
          ctx.fillStyle = shades[(x * 5 + y * 11) % shades.length];
          ctx.fillRect(x, y, 2, 2);
        }
      }
    });
    const grassSideTex = createBlockTex((ctx) => {
      ctx.fillStyle = '#6A472F';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#563722';
      for (let i = 0; i < 24; i++) ctx.fillRect((i * 5) % 14, 4 + ((i * 7) % 11), 2, 2);
      ctx.fillStyle = '#387A47';
      ctx.fillRect(0, 0, 16, 4);
      ctx.fillStyle = '#4A965B';
      for (let x = 0; x < 16; x += 4) ctx.fillRect(x, 4, 2, 1);
    });
    const stoneTex = createBlockTex((ctx) => {
      ctx.fillStyle = '#475569';
      ctx.fillRect(0, 0, 16, 16);
      const cols = ['#334155', '#64748B', '#3E4C61'];
      for (let y = 0; y < 16; y += 2) {
        for (let x = 0; x < 16; x += 2) {
          ctx.fillStyle = cols[(x * 3 + y * 7) % cols.length];
          ctx.fillRect(x, y, 2, 2);
        }
      }
    });
    const cherryLeafTex = createBlockTex((ctx) => {
      ctx.fillStyle = '#F472B6';
      ctx.fillRect(0, 0, 16, 16);
      const shades = ['#FBCFE8', '#EC4899', '#F9A8D4', '#DB2777'];
      for (let y = 0; y < 16; y += 2) {
        for (let x = 0; x < 16; x += 2) {
          ctx.fillStyle = shades[(x * 7 + y * 3) % shades.length];
          ctx.fillRect(x, y, 2, 2);
        }
      }
    });
    const cherryLogTex = createBlockTex((ctx) => {
      ctx.fillStyle = '#3B1E2E';
      ctx.fillRect(0, 0, 16, 16);
      ctx.fillStyle = '#582C44';
      ctx.fillRect(3, 0, 2, 16);
      ctx.fillRect(10, 0, 3, 16);
    });

    const grassMats = [
      new THREE.MeshStandardMaterial({ map: grassSideTex, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ map: grassSideTex, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ map: grassTopTex, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ color: 0x563722, roughness: 0.95 }),
      new THREE.MeshStandardMaterial({ map: grassSideTex, roughness: 0.9 }),
      new THREE.MeshStandardMaterial({ map: grassSideTex, roughness: 0.9 }),
    ];
    const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.85 });
    const leafMat = new THREE.MeshStandardMaterial({ map: cherryLeafTex, roughness: 0.75 });
    const logMat = new THREE.MeshStandardMaterial({ map: cherryLogTex, roughness: 0.85 });

    const blockGeo = new THREE.BoxGeometry(1, 1, 1);

    // Terrain Floor Grid (18x18 authentic Minecraft blocks)
    for (let x = -9; x <= 9; x++) {
      for (let z = -12; z <= 6; z++) {
        const yOff = Math.abs(x) > 5 && z < -4 ? 1 : 0;
        const m = new THREE.Mesh(blockGeo, (x + z) % 7 === 0 ? stoneMat : grassMats);
        m.position.set(x, -1 + yOff, z);
        m.receiveShadow = true;
        scene.add(m);
      }
    }

    // Cherry Blossom Trees on Left & Right
    const addCherryTree = (tx: number, tz: number) => {
      for (let y = 0; y < 4; y++) {
        const trunk = new THREE.Mesh(blockGeo, logMat);
        trunk.position.set(tx, y, tz);
        trunk.castShadow = true;
        scene.add(trunk);
      }
      for (let lx = -2; lx <= 2; lx++) {
        for (let lz = -2; lz <= 2; lz++) {
          for (let ly = 3; ly <= 5; ly++) {
            if (Math.abs(lx) === 2 && Math.abs(lz) === 2 && ly === 5) continue;
            if (ly === 5 && (Math.abs(lx) > 1 || Math.abs(lz) > 1)) continue;
            const leaf = new THREE.Mesh(blockGeo, leafMat);
            leaf.position.set(tx + lx, ly, tz + lz);
            leaf.castShadow = true;
            scene.add(leaf);
          }
        }
      }
    };
    addCherryTree(-6, -7);
    addCherryTree(6, -8);

    // Target Center Block + Custom Block Outline
    const targetBlock = new THREE.Mesh(blockGeo, stoneMat);
    targetBlock.position.set(0, 0, -4.5);
    targetBlock.castShadow = true;
    targetBlock.receiveShadow = true;
    scene.add(targetBlock);

    const outlineGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.015, 1.015, 1.015));
    const outlineMat = new THREE.LineBasicMaterial({ color: 0x7c5cff, transparent: true, opacity: 0.9 });
    const blockOutlineMesh = new THREE.LineSegments(outlineGeo, outlineMat);
    blockOutlineMesh.position.copy(targetBlock.position);
    scene.add(blockOutlineMesh);

    // Glowing Crescent Moon + Stars in Sky
    const moonMesh = new THREE.Mesh(
      new THREE.BoxGeometry(3.2, 3.2, 0.4),
      new THREE.MeshBasicMaterial({ color: 0xe2e8f0 })
    );
    moonMesh.position.set(16, 22, -48);
    scene.add(moonMesh);

    const starGeo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
    const starMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
    for (let i = 0; i < 65; i++) {
      const st = new THREE.Mesh(starGeo, starMat);
      st.position.set(Math.sin(i * 4.3) * 45, 10 + ((i * 7.1) % 24), -46 + Math.cos(i * 2.1) * 18);
      scene.add(st);
    }

    // 3D Dropped Items (Item Physics)
    const droppedGroup = new THREE.Group();
    scene.add(droppedGroup);
    const itemMeshes: THREE.Mesh[] = [];
    const itemColors = [0x38bdf8, 0xfacc15, 0xa855f7, 0x34d399];
    itemColors.forEach((col, i) => {
      const m = new THREE.Mesh(
        new THREE.BoxGeometry(0.32, 0.32, 0.32),
        new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.35, roughness: 0.3 })
      );
      m.position.set(-2.4 + i * 1.5, -0.2, -3.6 - (i % 2) * 0.8);
      droppedGroup.add(m);
      itemMeshes.push(m);
    });

    // Visible Distant Player with Animated Wings & Nametag Projection
    const npcGroup = new THREE.Group();
    npcGroup.position.set(-3.2, -0.5, -6.5);
    scene.add(npcGroup);
    const npcBody = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.25), new THREE.MeshStandardMaterial({ color: 0x7c5cff }));
    npcBody.position.y = 1.1;
    const npcHead = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), new THREE.MeshStandardMaterial({ color: 0xe8b796 }));
    npcHead.position.y = 1.75;
    const npcLegs = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.75, 0.25), new THREE.MeshStandardMaterial({ color: 0x0f172a }));
    npcLegs.position.y = 0.38;
    npcGroup.add(npcBody, npcHead, npcLegs);

    const npcWingL = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.45, 0.05), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, emissive: 0x7c5cff, emissiveIntensity: 0.35 }));
    npcWingL.position.set(-0.6, 1.25, -0.18);
    const npcWingR = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.45, 0.05), new THREE.MeshStandardMaterial({ color: 0xe2e8f0, emissive: 0x7c5cff, emissiveIntensity: 0.35 }));
    npcWingR.position.set(0.6, 1.25, -0.18);
    npcGroup.add(npcWingL, npcWingR);

    // 3D Decorative Particles Pool
    const pPool: { mesh: THREE.Mesh; bx: number; by: number; bz: number; ph: number }[] = [];
    const pGroup = new THREE.Group();
    scene.add(pGroup);
    const pGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
    const pMat = new THREE.MeshBasicMaterial({ color: 0xa78bfa, transparent: true, opacity: 0.8 });
    for (let i = 0; i < 60; i++) {
      const m = new THREE.Mesh(pGeo, pMat);
      const bx = (Math.sin(i * 3.1) * 7);
      const by = 0.2 + ((i * 0.4) % 4.5);
      const bz = -2 - ((i * 0.8) % 9);
      pGroup.add(m);
      pPool.push({ mesh: m, bx, by, bz, ph: i * 0.5 });
    }

    // First-Person Viewmodel Hand + Item attached to Camera!
    const handRig = new THREE.Group();
    camera.add(handRig);
    scene.add(camera);

    const fpArm = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.45, 0.18),
      new THREE.MeshStandardMaterial({ color: 0xe0a98c, roughness: 0.7 })
    );
    fpArm.position.set(0.45, -0.38, -0.58);
    fpArm.rotation.set(0.4, -0.25, 0.2);
    handRig.add(fpArm);

    const fpBlade = new THREE.Mesh(
      new THREE.BoxGeometry(0.05, 0.52, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x38bdf8, emissive: 0x7c5cff, emissiveIntensity: 0.35, metalness: 0.4, roughness: 0.2 })
    );
    fpBlade.position.set(0.39, -0.08, -0.74);
    fpBlade.rotation.set(-0.35, 0, -0.15);
    handRig.add(fpBlade);

    const handleResize = () => {
      const rect = canvas.getBoundingClientRect();
      const w = Math.max(10, Math.round(rect.width));
      const h = Math.max(10, Math.round(rect.height));
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    handleResize();
    const ro = new ResizeObserver(handleResize);
    ro.observe(canvas);

    let raf = 0;
    const start = performance.now();

    const animate = (now: number) => {
      const { config: cfg, world: wrd } = stateRef.current;

      fpsCounterRef.current.frames += 1;
      const elapsed = now - fpsCounterRef.current.lastReport;
      if (elapsed >= 500) {
        const measured = Math.round((fpsCounterRef.current.frames * 1000) / elapsed);
        const ft = Number((elapsed / fpsCounterRef.current.frames).toFixed(1));
        fpsCounterRef.current.frames = 0;
        fpsCounterRef.current.lastReport = now;
        setWorld((w) => (w.fps === measured ? w : { ...w, fps: measured, frameTimeMs: ft }));
      }

      const t = (now - start) * 0.001;

      // Sky & Fog reacts to Starlight Sky visual pack
      const starSky = cfg.visualPacks.enabled && cfg.visualPacks.packs.some((p) => p.id === 'pack_starlight_sky' && p.enabled);
      scene.background = new THREE.Color(starSky ? '#090D22' : '#1E3A68');
      scene.fog = new THREE.FogExp2(starSky ? '#090D22' : '#1E3A68', 0.032);

      // Zoom FOV
      const targetZoom = cfg.zoom.enabled && wrd.zoomEngaged ? cfg.zoom.strength : 1.0;
      const lerpAlpha = Math.min(1, 0.016 * cfg.zoom.transitionSpeed * 1.4);
      zoomAnimRef.current += (targetZoom - zoomAnimRef.current) * lerpAlpha;
      camera.fov = 72 / zoomAnimRef.current;
      camera.updateProjectionMatrix();

      // Camera Rotation (Yaw/Pitch + Freelook)
      const camYaw = ((wrd.yaw - 142) + (cfg.freelook.enabled ? wrd.freelookYawOffset : 0)) * (Math.PI / 180);
      const camPitch = -(wrd.pitch + (cfg.freelook.enabled ? wrd.freelookPitchOffset : 0)) * (Math.PI / 180);
      prevAnglesRef.current = { yaw: camYaw, pitch: camPitch };
      camera.position.set(0, 1.15, 0.4);
      camera.rotation.order = 'YXZ';
      camera.rotation.y = -camYaw;
      camera.rotation.x = camPitch;

      // Custom Block Outline Color & Opacity
      blockOutlineMesh.visible = true;
      if (cfg.blockOutline.enabled) {
        outlineMat.color.set(cfg.blockOutline.color);
        outlineMat.opacity = cfg.blockOutline.opacity;
      } else {
        outlineMat.color.set('#000000');
        outlineMat.opacity = 0.55;
      }

      // Item Physics
      itemMeshes.forEach((m, idx) => {
        const sp = cfg.itemPhysics.enabled ? cfg.itemPhysics.speed : 1.0;
        if (cfg.itemPhysics.enabled && cfg.itemPhysics.style === 'Flat Lay') {
          m.position.y = -0.34;
          m.rotation.x = Math.PI / 2;
        } else {
          m.position.y = -0.15 + Math.sin(t * 2.5 * sp + idx) * 0.14;
          m.rotation.x = 0;
        }
        m.rotation.y = (!cfg.itemPhysics.enabled || cfg.itemPhysics.rotation) ? t * 1.8 * sp + idx : 0.6;
      });

      // Visible NPC Moving Wings
      if (cfg.cosmetics.enabled && cfg.cosmetics.animationsEnabled) {
        const beat = Math.sin(t * 3.8 * cfg.cosmetics.wingFlapSpeed) * 0.35;
        npcWingL.rotation.y = 0.35 + beat;
        npcWingR.rotation.y = -0.35 - beat;
      }
      npcWingL.visible = cfg.cosmetics.enabled;
      npcWingR.visible = cfg.cosmetics.enabled;

      // Decorative Particles
      pGroup.visible = cfg.particles.enabled;
      if (cfg.particles.enabled) {
        pMat.color.set(cfg.particles.primaryColor);
        pMat.opacity = cfg.particles.transparency;
        const limit = cfg.particles.performanceMode ? Math.min(20, cfg.particles.amount) : Math.min(60, cfg.particles.amount);
        pPool.forEach((p, idx) => {
          p.mesh.visible = idx < limit;
          if (!p.mesh.visible) return;
          const dir = cfg.particles.style === 'Ember Sparks' ? 1 : -1;
          p.mesh.position.y = ((p.by + t * 0.5 * cfg.particles.speed * dir + 5) % 4.5);
          p.mesh.position.x = p.bx + Math.sin(t * cfg.particles.speed + p.ph) * 0.35;
          p.mesh.scale.setScalar(cfg.particles.size);
        });
      }

      // First-Person Viewmodel & Hand Aura
      const vm = cfg.viewmodel.enabled
        ? cfg.viewmodel.categories[cfg.viewmodel.activeCategory]
        : { handX: 0, handY: 0, handZ: 0, itemX: 0, itemY: 0, itemZ: 0, scale: 1, rotX: 0, rotY: 0, rotZ: 0 };
      const swing = wrd.pressedKeys.lmb ? Math.sin(t * 18) * 0.25 : Math.sin(t * 2.2) * 0.015;
      handRig.position.set(vm.handX + vm.itemX, vm.handY + vm.itemY + swing, vm.handZ + vm.itemZ);
      handRig.scale.setScalar(vm.scale);
      handRig.rotation.set((vm.rotX * Math.PI) / 180, (vm.rotY * Math.PI) / 180, (vm.rotZ * Math.PI) / 180);

      const bladeMat = fpBlade.material as THREE.MeshStandardMaterial;
      if (cfg.handAura.enabled) {
        bladeMat.emissive.set(cfg.handAura.primaryColor);
        bladeMat.emissiveIntensity = 0.25 + cfg.handAura.intensity * 1.1;
      } else {
        bladeMat.emissiveIntensity = 0.05;
      }

      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    };

    raf = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      [grassTopTex, grassSideTex, stoneTex, cherryLeafTex, cherryLogTex].forEach((tx) => tx.dispose());
      renderer.dispose();
    };
  }, [setWorld]);

  const canvasFilterCss = useMemo(() => {
    const parts: string[] = [];
    if (config.colorGrading.enabled) {
      const b = config.colorGrading.brightness * (1 + (config.colorGrading.gamma - 1) * 0.45);
      parts.push(`brightness(${b.toFixed(2)}) contrast(${config.colorGrading.contrast.toFixed(2)}) saturate(${config.colorGrading.saturation.toFixed(2)})`);
    }
    if (config.motionBlur.enabled && config.motionBlur.cameraBlur) {
      parts.push(`blur(${(config.motionBlur.intensity * 1.2).toFixed(2)}px)`);
    }
    return parts.length > 0 ? parts.join(' ') : 'none';
  }, [config.colorGrading, config.motionBlur]);

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const getCardinal = (yawDeg: number) => {
    const norm = ((yawDeg % 360) + 360) % 360;
    const dirs = ['S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'];
    return dirs[Math.round(norm / 45) % 8];
  };

  const renderHudContent = (el: HudElementConfig) => {
    const nowTime = clockTick.toLocaleTimeString([], {
      hour12: !el.clock24h,
      hour: '2-digit',
      minute: '2-digit',
      ...(el.showSeconds ? { second: '2-digit' } : {}),
    });

    switch (el.id) {
      case 'fps':
        return <span>{el.format.replace('{fps}', String(world.fps))}</span>;
      case 'ping':
        return (
          <span className="flex items-center gap-1.5">
            {world.pingMs !== null ? <Wifi className="h-3 w-3 text-emerald-400" /> : <WifiOff className="h-3 w-3 text-amber-400" />}
            {el.format.replace('{ping}', world.pingMs !== null ? `${world.pingMs} ms` : el.pingUnavailableText || 'N/A')}
          </span>
        );
      case 'coordinates': {
        const p = el.precision ?? 1;
        return (
          <span>
            {el.format
              .replace('{x}', world.x.toFixed(p))
              .replace('{y}', world.y.toFixed(p))
              .replace('{z}', world.z.toFixed(p))}
          </span>
        );
      }
      case 'direction':
        return (
          <span className="flex items-center gap-1.5">
            <Compass className="h-3 w-3" />
            {el.format
              .replace('{dir}', getCardinal(world.yaw))
              .replace('{yaw}', String(Math.round(((world.yaw % 360) + 360) % 360)))}
          </span>
        );
      case 'biome':
        return <span>{el.format.replace('{biome}', world.biome)}</span>;
      case 'clock':
        return <span>{el.format.replace('{time}', nowTime)}</span>;
      case 'server':
        return <span>{el.format.replace('{addr}', world.serverAddress ?? 'Singleplayer (Local)')}</span>;
      case 'cps':
        return <span>{el.format.replace('{lmb}', String(world.lmbCps)).replace('{rmb}', String(world.rmbCps))}</span>;
      case 'session':
        return <span>{el.format.replace('{duration}', formatDuration(world.sessionSeconds))}</span>;
      case 'armor': {
        const pieces: { kind: ArmorSlotKind; pct: number; enchanted: boolean }[] = [
          { kind: 'helmet', pct: 88, enchanted: true },
          { kind: 'chestplate', pct: 62, enchanted: true },
          { kind: 'leggings', pct: 21, enchanted: true },
          { kind: 'boots', pct: 95, enchanted: true },
        ];
        if (el.showOffhandSlot) pieces.push({ kind: 'shield', pct: 74, enchanted: false });
        const thresh = el.lowDurabilityThreshold ?? 25;
        const horizontal = (el.armorOrientation ?? 'horizontal') === 'horizontal';
        const barColor = (pct: number) => (pct > 55 ? '#22C55E' : pct > thresh ? '#FACC15' : '#EF4444');

        return (
          <div className={`flex ${horizontal ? 'flex-row items-center gap-1.5' : 'flex-col gap-1.5'}`}>
            {pieces.map((pc) => {
              const isLow = pc.pct <= thresh;
              return (
                <div
                  key={pc.kind}
                  className={`relative flex flex-col items-center justify-center rounded ${
                    el.showArmorFrame ? 'border border-white/20 bg-slate-950/75 p-1' : 'px-0.5 py-0.5'
                  }`}
                >
                  <div className="relative">
                    <ArmorPixelIcon kind={pc.kind} enchanted={pc.enchanted} size={22} />
                    {el.showWarningBadge !== false && isLow && (
                      <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 animate-pulse items-center justify-center rounded-full bg-rose-600 text-[9px] font-black text-white shadow">
                        !
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 h-[3px] w-5 overflow-hidden bg-black/90">
                    <div className="h-full" style={{ width: `${pc.pct}%`, backgroundColor: barColor(pc.pct) }} />
                  </div>
                  {(el.armorStyle === 'uku-numbers' || el.showDurabilityPercent) && (
                    <span className={`mt-0.5 font-mono text-[9px] font-bold ${isLow ? 'text-rose-400' : 'text-slate-100'}`}>
                      {pc.pct}%
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        );
      }
      case 'musicCard': {
        if (!config.musicLyrics.enabled || !config.musicLyrics.showNowPlayingCard || !activeTrack || !musicState) return null;
        const pct = Math.min(100, (musicState.positionSec / Math.max(1, activeTrack.durationSec)) * 100);
        const [c1, c2] = activeTrack.coverColors;
        return (
          <div className="pointer-events-auto w-60 space-y-2">
            <div className="flex items-center gap-2.5">
              <div
                style={{ background: `linear-gradient(135deg, ${c1}, ${c2})` }}
                className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-white/20 shadow-lg"
              >
                <Disc3 className={`h-5 w-5 text-white ${musicState.playing ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-xs font-bold text-white">{activeTrack.title}</div>
                <div className="truncate text-[10px] text-slate-300">{activeTrack.artist}</div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-emerald-300">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  <span>{config.musicLyrics.spotifyStatus}</span>
                </div>
              </div>
              {config.musicLyrics.showEqualizer && (
                <div className="flex h-4 items-end gap-0.5">
                  {[0.6, 1.0, 0.45, 0.85].map((amp, i) => (
                    <span
                      key={i}
                      style={{
                        height: musicState.playing ? `${Math.round((0.35 + Math.abs(Math.sin(musicState.positionSec * 4 + i)) * 0.65) * amp * 16)}px` : '4px',
                        backgroundColor: c1,
                      }}
                      className="w-1 rounded-full transition-all duration-150"
                    />
                  ))}
                </div>
              )}
            </div>
            <div className="space-y-1">
              <div className="h-1 w-full overflow-hidden rounded-full bg-white/15">
                <div className="h-full rounded-full transition-all duration-200" style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${c1}, ${c2})` }} />
              </div>
              <div className="flex items-center justify-between font-mono text-[9px] text-slate-300">
                <span>{formatDuration(musicState.positionSec)}</span>
                <div className="flex items-center gap-2">
                  <button type="button" onClick={(e) => { e.stopPropagation(); onStepTrack?.(-1); }} className="hover:text-white">
                    <SkipBack className="h-3 w-3" />
                  </button>
                  <button type="button" onClick={(e) => { e.stopPropagation(); onTogglePlayMusic?.(); }} className="rounded-full bg-white/15 p-1 text-white hover:bg-white/25">
                    {musicState.playing ? <Pause className="h-2.5 w-2.5" /> : <Play className="h-2.5 w-2.5" />}
                  </button>
                  <button type="button" onClick={(e) => { e.stopPropagation(); onStepTrack?.(1); }} className="hover:text-white">
                    <SkipForward className="h-3 w-3" />
                  </button>
                </div>
                <span>{formatDuration(activeTrack.durationSec)}</span>
              </div>
            </div>
          </div>
        );
      }
      case 'heldItem': {
        const itemLabel =
          world.heldItemKey === 'sword'
            ? 'Diamond Sword (Sharp V)'
            : world.heldItemKey === 'pickaxe'
            ? 'Netherite Pickaxe (1482/2031)'
            : world.heldItemKey === 'apple'
            ? 'Golden Apple ×12'
            : world.heldItemKey === 'shulker'
            ? 'Purple Shulker Box [9/27]'
            : 'Enchanted Bow (Power V)';
        return (
          <div className="flex items-center gap-2">
            <Sparkles className="h-3.5 w-3.5 text-violet-300" />
            <span>{itemLabel}</span>
          </div>
        );
      }
      case 'potions':
        return (
          <div className="space-y-0.5 text-[11px]">
            <div>⚡ Speed II — 01:24</div>
            <div>🔥 Fire Res — 06:45</div>
          </div>
        );
      case 'keystrokes': {
        const keyBox = (lbl: string, pressed: boolean, extraClass = '') => (
          <div
            className={`flex items-center justify-center rounded border text-[10px] font-bold transition-colors ${extraClass} ${
              pressed ? 'border-white/70 text-white shadow-inner' : 'border-white/15 bg-black/50 text-slate-200'
            }`}
            style={pressed ? { backgroundColor: el.color } : undefined}
          >
            {lbl}
          </div>
        );
        return (
          <div className="w-[104px] space-y-1 select-none">
            <div className="grid grid-cols-3 gap-1">
              <div />
              {keyBox('W', world.pressedKeys.w, 'h-7')}
              <div />
              {keyBox('A', world.pressedKeys.a, 'h-7')}
              {keyBox('S', world.pressedKeys.s, 'h-7')}
              {keyBox('D', world.pressedKeys.d, 'h-7')}
            </div>
            <div className="grid grid-cols-2 gap-1">
              {keyBox('LMB', world.pressedKeys.lmb, 'h-5')}
              {keyBox('RMB', world.pressedKeys.rmb, 'h-5')}
            </div>
            {keyBox('SPACE', world.pressedKeys.space, 'h-5 w-full')}
          </div>
        );
      }
    }
  };

  // Compute ValenceMOD-style arbitrary lyric placement coordinates
  const lyricCoords = useMemo(() => {
    switch (config.musicLyrics.lyricPosition) {
      case 'sky-center':
        return { x: 50, y: 18 };
      case 'in-front':
        return { x: 50, y: 48 }; // Right in front of you!
      case 'above-crosshair':
        return { x: 50, y: 38 };
      case 'top-banner':
        return { x: 50, y: 9 };
      case 'above-hotbar':
        return { x: 50, y: 80 };
      case 'custom':
      default:
        return { x: config.musicLyrics.lyricX, y: config.musicLyrics.lyricY };
    }
  }, [config.musicLyrics.lyricPosition, config.musicLyrics.lyricX, config.musicLyrics.lyricY]);

  const activeLyricColor =
    config.musicLyrics.albumTintSync && activeTrack
      ? activeTrack.coverColors[0]
      : config.musicLyrics.lyricColor;

  return (
    <div
      ref={containerRef}
      onContextMenu={(e) => e.preventDefault()}
      onMouseDown={(e) => {
        if (hudEditMode) return;
        if (e.button === 0 || e.button === 2) onMouseAction(e.button, true);
        if (interactiveMode) camDragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
      }}
      onMouseMove={(e) => {
        if (draggingLyricRef.current.active && containerRef.current && onUpdateLyricsPos) {
          const rect = containerRef.current.getBoundingClientRect();
          const nx = Math.max(8, Math.min(92, ((e.clientX - rect.left - draggingLyricRef.current.offsetX) / rect.width) * 100));
          const ny = Math.max(8, Math.min(88, ((e.clientY - rect.top - draggingLyricRef.current.offsetY) / rect.height) * 100));
          onUpdateLyricsPos(Math.round(nx), Math.round(ny));
          return;
        }
        if (hudEditMode && draggingHudRef.current && containerRef.current && onUpdateHudPosition) {
          const rect = containerRef.current.getBoundingClientRect();
          const nx = Math.max(0, Math.min(92, ((e.clientX - rect.left - draggingHudRef.current.offsetX) / rect.width) * 100));
          const ny = Math.max(0, Math.min(92, ((e.clientY - rect.top - draggingHudRef.current.offsetY) / rect.height) * 100));
          onUpdateHudPosition(draggingHudRef.current.id, Math.round(nx * 10) / 10, Math.round(ny * 10) / 10);
          return;
        }
        if (camDragRef.current.active && interactiveMode) {
          const dx = e.clientX - camDragRef.current.lastX;
          const dy = e.clientY - camDragRef.current.lastY;
          camDragRef.current = { active: true, lastX: e.clientX, lastY: e.clientY };
          const sensScale =
            config.zoom.enabled && world.zoomEngaged && config.zoom.reduceSensitivity
              ? 1 / Math.max(1.2, config.zoom.strength * 0.7)
              : 1;

          setWorld((w) => {
            if (config.freelook.enabled && world.freelookEngaged) {
              const nextYawOff = Math.max(
                -config.freelook.maxHorizontalDeg,
                Math.min(config.freelook.maxHorizontalDeg, w.freelookYawOffset + dx * 0.35 * config.freelook.horizontalSensitivity * sensScale)
              );
              const nextPitchOff = Math.max(
                -config.freelook.maxVerticalDeg,
                Math.min(config.freelook.maxVerticalDeg, w.freelookPitchOffset + dy * 0.28 * config.freelook.verticalSensitivity * sensScale)
              );
              return { ...w, freelookYawOffset: nextYawOff, freelookPitchOffset: nextPitchOff };
            }
            return {
              ...w,
              yaw: w.yaw + dx * 0.35 * sensScale,
              pitch: Math.max(-60, Math.min(60, w.pitch + dy * 0.25 * sensScale)),
            };
          });
        }
      }}
      onMouseUp={(e) => {
        if (e.button === 0 || e.button === 2) onMouseAction(e.button, false);
        camDragRef.current.active = false;
        draggingHudRef.current = null;
        draggingLyricRef.current.active = false;
      }}
      onMouseLeave={() => {
        camDragRef.current.active = false;
        draggingHudRef.current = null;
        draggingLyricRef.current.active = false;
      }}
      className="relative h-full w-full overflow-hidden select-none"
    >
      <canvas ref={trailCanvasRef} className="hidden" />
      <canvas ref={canvasRef} style={{ filter: canvasFilterCss }} className="block h-full w-full cursor-crosshair" />

      {/* Color Grading Vignette Overlay */}
      {config.colorGrading.enabled && config.colorGrading.vignette > 0 && (
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background: `radial-gradient(circle, transparent 42%, rgba(0,0,0,${Math.min(0.9, config.colorGrading.vignette)}) 100%)`,
          }}
        />
      )}

      {/* ValenceMOD-Inspired Customizable & Freely Movable Sky / In-Front-of-You Lyrics! */}
      {config.musicLyrics.enabled && config.musicLyrics.showSkyLyrics && lyricCursor.current && (
        <div
          onMouseDown={(e) => {
            if (!onUpdateLyricsPos) return;
            e.stopPropagation();
            draggingLyricRef.current = { active: true, offsetX: 0, offsetY: 0 };
          }}
          style={{
            left: `${lyricCoords.x}%`,
            top: `${lyricCoords.y}%`,
            opacity: config.musicLyrics.lyricOpacity,
            fontFamily: FONT_FAMILY_META[config.musicLyrics.lyricFont].css,
            letterSpacing: `${config.musicLyrics.lyricLetterSpacing}px`,
            transform: `translate(-50%, -50%) scale(${config.musicLyrics.lyricScale})${
              config.musicLyrics.lyricTilt3D && config.musicLyrics.lyricPosition === 'sky-center'
                ? ' perspective(600px) rotateX(16deg)'
                : ''
            }`,
          }}
          className={`absolute z-10 flex flex-col items-center text-center transition-all duration-200 ${
            hudEditMode || interactiveMode ? 'cursor-move pointer-events-auto' : 'pointer-events-none'
          } ${
            config.musicLyrics.lyricStyle === 'glass-pill'
              ? 'rounded-2xl border border-white/15 bg-black/55 px-5 py-2.5 backdrop-blur-md shadow-2xl'
              : ''
          }`}
          title="Drag lyrics anywhere on screen!"
        >
          {hudEditMode && (
            <span className="mb-1 inline-flex items-center gap-1 rounded bg-white/15 px-1.5 py-0.5 font-sans text-[9px] text-white">
              <Move className="h-2.5 w-2.5" /> Drag Lyrics Anywhere
            </span>
          )}
          {lyricCursor.prev && (
            <span className="text-[11px] font-medium text-slate-300/55 drop-shadow">
              {lyricCursor.prev.text}
            </span>
          )}
          <span
            style={{
              color: activeLyricColor,
              textShadow:
                config.musicLyrics.lyricStyle === 'pixel-shadow'
                  ? '3px 3px 0px #000000'
                  : config.musicLyrics.lyricStyle === 'outline'
                  ? '-1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000'
                  : config.musicLyrics.lyricGlow
                  ? `0 0 20px ${activeLyricColor}, 0 2px 10px rgba(0,0,0,0.95)`
                  : '0 2px 6px rgba(0,0,0,0.9)',
            }}
            className="mt-0.5 text-lg font-bold drop-shadow-xl sm:text-xl"
          >
            {lyricCursor.current.text}
          </span>
          {config.musicLyrics.showNextLine && lyricCursor.next && (
            <span className="mt-0.5 text-xs font-medium text-slate-200/75 drop-shadow">
              {lyricCursor.next.text}
            </span>
          )}
        </div>
      )}

      {config.freelook.enabled && world.freelookEngaged && (
        <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 rounded-full border border-sky-400/40 bg-slate-950/75 px-3 py-1 text-[11px] font-medium text-sky-200 backdrop-blur-md">
          <Eye className="mr-1.5 inline h-3.5 w-3.5" />
          Freelook Active · Body Yaw: {Math.round(((world.yaw % 360) + 360) % 360)}° | Offset: {Math.round(world.freelookYawOffset)}°
        </div>
      )}

      {!hudEditMode && (
        <div className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          {config.crosshair.enabled ? (
            <div style={{ opacity: config.crosshair.opacity }} className="relative">
              <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, bottom: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: config.crosshair.gap, width: config.crosshair.thickness, height: config.crosshair.size, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, right: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              <div style={{ position: 'absolute', top: -config.crosshair.thickness / 2, left: config.crosshair.gap, width: config.crosshair.size, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              {config.crosshair.centerDot && (
                <div style={{ position: 'absolute', left: -config.crosshair.thickness / 2, top: -config.crosshair.thickness / 2, width: config.crosshair.thickness, height: config.crosshair.thickness, backgroundColor: config.crosshair.color, boxShadow: config.crosshair.outline ? '0 0 0 1px rgba(0,0,0,0.85)' : undefined }} />
              )}
            </div>
          ) : (
            <div className="relative h-4 w-4">
              <div className="absolute top-0 left-1/2 h-4 w-[2px] -translate-x-1/2 bg-white/80 mix-blend-difference" />
              <div className="absolute top-1/2 left-0 h-[2px] w-4 -translate-y-1/2 bg-white/80 mix-blend-difference" />
            </div>
          )}
        </div>
      )}

      {hudEditMode && (
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              'linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        />
      )}

      {/* All HUD Elements */}
      {(Object.values(config.hudElements) as HudElementConfig[]).map((el) => {
        if (!el.enabled) return null;
        if (el.id === 'musicCard' && (!config.musicLyrics.enabled || !config.musicLyrics.showNowPlayingCard)) return null;
        const isSelected = hudEditMode && selectedHudId === el.id;
        const hideShell = el.id === 'keystrokes' || (el.id === 'armor' && !el.showArmorFrame && el.bgOpacity === 0);
        return (
          <div
            key={el.id}
            onMouseDown={(e) => {
              if (!hudEditMode || !containerRef.current) return;
              e.stopPropagation();
              onSelectHudId?.(el.id);
              if (el.locked) return;
              const box = e.currentTarget.getBoundingClientRect();
              draggingHudRef.current = {
                id: el.id,
                offsetX: e.clientX - box.left,
                offsetY: e.clientY - box.top,
              };
            }}
            style={{
              left: `${el.x}%`,
              top: `${el.y}%`,
              transform: `scale(${el.scale * config.hudScale})`,
              transformOrigin: 'top left',
              opacity: el.opacity * config.hudOpacity,
              color: el.color,
              fontFamily: FONT_FAMILY_META[el.font]?.css ?? FONT_FAMILY_META.inter.css,
              padding: `${el.spacing}px ${el.spacing + 4}px`,
              backgroundColor: hideShell ? 'transparent' : `rgba(8, 11, 22, ${el.bgOpacity})`,
              borderRadius: `${Math.min(10, config.theme.cornerRadius)}px`,
            }}
            className={`absolute z-10 text-xs font-medium transition-shadow ${
              hudEditMode
                ? 'cursor-move border border-dashed'
                : hideShell
                ? 'pointer-events-none'
                : 'pointer-events-none border border-white/10 shadow-md backdrop-blur-sm'
            } ${isSelected ? 'ring-2 ring-violet-400' : hudEditMode ? 'border-white/35' : ''}`}
          >
            {hudEditMode && (
              <span className="mb-0.5 block text-[9px] font-bold tracking-wider uppercase opacity-75">
                {el.label} {el.locked ? '🔒' : ''}
              </span>
            )}
            {renderHudContent(el)}
          </div>
        );
      })}

      {/* Hotbar + Shulker Preview */}
      {!hudEditMode && (
        <div className="absolute bottom-3 left-1/2 z-20 flex -translate-x-1/2 flex-col items-center gap-2">
          {config.shulkerPreview.enabled && shulkerHovered && (
            <div
              style={{
                transform: `scale(${config.shulkerPreview.previewScale})`,
                transformOrigin: 'bottom center',
                backgroundColor:
                  config.shulkerPreview.backgroundStyle === 'Vanilla Classic'
                    ? 'rgba(30, 27, 46, 0.96)'
                    : config.shulkerPreview.backgroundStyle === 'Obsidian Dark'
                    ? 'rgba(5, 6, 12, 0.94)'
                    : 'rgba(13, 17, 34, 0.88)',
                borderColor:
                  config.shulkerPreview.backgroundStyle === 'Accent Border' ? config.theme.accentColor : 'rgba(192,132,252,0.45)',
              }}
              className={`rounded-xl border p-3 shadow-2xl backdrop-blur-xl ${
                config.shulkerPreview.smoothAnimation ? 'mc-animate-in' : ''
              }`}
            >
              <div className="mb-2 flex items-center justify-between gap-4 border-b border-white/10 pb-1.5 text-xs">
                <span className="font-semibold text-purple-200">Purple Shulker Box (Legit Client Preview)</span>
                <span className="font-mono text-[10px] text-slate-400">9 / 27 slots</span>
              </div>
              <div className="grid grid-cols-9 gap-1.5">
                {Array.from({ length: 27 }, (_, idx) => {
                  const item = SHULKER_CONTENTS[idx];
                  return (
                    <div
                      key={idx}
                      title={item ? `${item.name}${item.enchant ? ` (${item.enchant})` : ''}` : 'Empty Slot'}
                      className="relative flex h-8 w-8 items-center justify-center rounded border border-white/10 bg-black/50"
                    >
                      {item && (
                        <>
                          <div
                            className="h-4 w-4 rounded-sm"
                            style={{
                              backgroundColor: item.color,
                              boxShadow:
                                config.shulkerPreview.showEnchantments && item.enchant
                                  ? '0 0 8px rgba(192,132,252,0.85)'
                                  : undefined,
                            }}
                          />
                          {item.count > 1 && (
                            <span className="absolute right-0.5 bottom-0 font-mono text-[9px] font-bold text-white drop-shadow">
                              {item.count}
                            </span>
                          )}
                          {config.shulkerPreview.showDurability && item.dur !== null && (
                            <div className="absolute right-0.5 bottom-0.5 left-0.5 h-0.5 bg-black/70">
                              <div className="h-full bg-emerald-400" style={{ width: `${item.dur}%` }} />
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex items-center gap-1 rounded-lg border border-white/15 bg-black/65 p-1 backdrop-blur-md">
            {(
              [
                { key: 'sword', label: 'Sword', color: '#38BDF8' },
                { key: 'pickaxe', label: 'Pickaxe', color: '#64748B' },
                { key: 'apple', label: 'Apple', color: '#FACC15' },
                { key: 'bow', label: 'Bow', color: '#B45309' },
                { key: 'shulker', label: 'Shulker Box (Hover!)', color: '#A855F7' },
              ] as const
            ).map((slot) => {
              const active = world.heldItemKey === slot.key;
              return (
                <button
                  key={slot.key}
                  type="button"
                  onClick={() => setWorld((w) => ({ ...w, heldItemKey: slot.key }))}
                  onMouseEnter={() => slot.key === 'shulker' && setShulkerHovered(true)}
                  onMouseLeave={() => slot.key === 'shulker' && setShulkerHovered(false)}
                  className={`relative flex h-9 w-9 items-center justify-center rounded border transition-all ${
                    active ? 'border-white bg-white/15' : 'border-white/10 bg-black/40 hover:bg-white/10'
                  }`}
                  title={slot.label}
                >
                  <div className="h-4 w-4 rounded-sm" style={{ backgroundColor: slot.color }} />
                  {slot.key === 'shulker' && (
                    <span className="absolute -top-1.5 -right-1 rounded bg-purple-600 px-1 text-[8px] font-bold text-white">
                      BOX
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
