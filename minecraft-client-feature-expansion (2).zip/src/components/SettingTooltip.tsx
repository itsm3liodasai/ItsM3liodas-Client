import React, { useState } from 'react';
import { HelpCircle, Zap, ShieldAlert } from 'lucide-react';
import { SETTING_DOCS } from '../data/themesAndDocs';

interface TooltipBadgeProps {
  docKey: string;
}

export const SettingTooltip: React.FC<TooltipBadgeProps> = ({ docKey }) => {
  const [open, setOpen] = useState(false);
  const doc = SETTING_DOCS[docKey];
  if (!doc) return null;

  return (
    <div
      className="relative inline-flex items-center"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={`Explain ${doc.title}`}
        className="ml-1.5 inline-flex h-4 w-4 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-white/10 hover:text-white"
      >
        <HelpCircle className="h-3.5 w-3.5" />
      </button>
      {open && (
        <div
          className="fixed z-[90] w-80 rounded-xl border border-white/15 bg-slate-950/95 p-3.5 text-left text-xs shadow-2xl backdrop-blur-xl"
          style={{ transform: 'translate(12px, -50%)' }}
        >
          <div className="mb-1.5 flex items-center justify-between border-b border-white/10 pb-1.5">
            <span className="font-semibold text-white">{doc.title}</span>
            <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">Docs</span>
          </div>
          <div className="space-y-1.5 leading-relaxed text-slate-300">
            <p><span className="font-semibold text-slate-100">What it does:</span> {doc.whatItDoes}</p>
            <p><span className="font-semibold text-slate-100">Affects:</span> {doc.affects}</p>
            <p><span className="font-semibold text-emerald-300">Increasing:</span> {doc.increasing}</p>
            <p><span className="font-semibold text-sky-300">Decreasing:</span> {doc.decreasing}</p>
            <p className="flex items-start gap-1 text-amber-200/90">
              <Zap className="mt-0.5 h-3 w-3 shrink-0" />
              <span><strong>Performance:</strong> {doc.performance}</span>
            </p>
            <p className="flex items-start gap-1 text-violet-200/90">
              <ShieldAlert className="mt-0.5 h-3 w-3 shrink-0" />
              <span><strong>Compatibility:</strong> {doc.compatibility}</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

interface SliderRowProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  docKey?: string;
  accentColor: string;
  onChange: (val: number) => void;
}

export const SliderRow: React.FC<SliderRowProps> = ({
  label,
  value,
  min,
  max,
  step = 0.05,
  unit = '',
  docKey,
  accentColor,
  onChange,
}) => {
  const display = step >= 1 ? Math.round(value) : value.toFixed(2);
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center font-medium text-slate-200">
          {label}
          {docKey && <SettingTooltip docKey={docKey} />}
        </span>
        <span className="font-mono text-[11px] text-slate-300">
          {display}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{ accentColor }}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/15"
      />
    </div>
  );
};

interface ToggleRowProps {
  label: string;
  description?: string;
  checked: boolean;
  accentColor: string;
  onChange: (checked: boolean) => void;
}

export const ToggleRow: React.FC<ToggleRowProps> = ({
  label,
  description,
  checked,
  accentColor,
  onChange,
}) => {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 transition-colors hover:bg-white/[0.06]">
      <div className="min-w-0">
        <div className="text-xs font-medium text-slate-100">{label}</div>
        {description && <div className="text-[11px] text-slate-400">{description}</div>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        style={{ backgroundColor: checked ? accentColor : 'rgba(255,255,255,0.14)' }}
        className="relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors"
      >
        <span
          className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform ${
            checked ? 'translate-x-4.5' : 'translate-x-1'
          }`}
        />
      </button>
    </label>
  );
};
