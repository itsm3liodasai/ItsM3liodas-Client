import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ClientConfig,
  ColorGradingPreset,
  CosmeticCategory,
  HudElementId,
  KeybindActionId,
  MotionBlurPreset,
  MusicTrack,
  PerformancePreset,
  SyncedLyricLine,
  ThemeId,
  VisualPackEntry,
} from '../types/client';
import {
  COLOR_GRADING_PRESETS,
  createDefaultConfig,
  createDefaultHudElements,
  THEME_PRESETS,
} from '../data/themesAndDocs';
import { BUILTIN_SYNCED_TRACKS, fetchSyncedLyricsAsync, parseLrcLyrics } from '../data/musicCatalog';

const STORAGE_KEY = 'itsm3liodas_client_config_v3';
const BACKUP_KEY = 'itsm3liodas_client_config_backup_v3';

export interface ToastNotice {
  id: string;
  title: string;
  detail?: string;
  tone: 'info' | 'success' | 'warning' | 'error';
}

export interface LiveWorldTelemetry {
  fps: number;
  frameTimeMs: number;
  pingMs: number | null;
  serverAddress: string | null;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  biome: string;
  heldItemKey: 'sword' | 'pickaxe' | 'apple' | 'bow' | 'shulker';
  pressedKeys: {
    w: boolean;
    a: boolean;
    s: boolean;
    d: boolean;
    space: boolean;
    lmb: boolean;
    rmb: boolean;
  };
  lmbCps: number;
  rmbCps: number;
  sessionSeconds: number;
  zoomEngaged: boolean;
  freelookEngaged: boolean;
  freelookYawOffset: number;
  freelookPitchOffset: number;
}

export interface MusicPlayerState {
  tracks: MusicTrack[];
  currentTrackId: string;
  playing: boolean;
  positionSec: number;
  fetchingLyrics: boolean;
}

function clamp(n: number, min: number, max: number): number {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

export function validateAndMergeConfig(raw: unknown): ClientConfig {
  const defaults = createDefaultConfig();
  if (!raw || typeof raw !== 'object') return defaults;
  const obj = raw as Partial<ClientConfig>;

  return {
    ...defaults,
    ...obj,
    schemaVersion: 3,
    hudScale: clamp(Number(obj.hudScale ?? defaults.hudScale), 0.5, 2.2),
    hudOpacity: clamp(Number(obj.hudOpacity ?? defaults.hudOpacity), 0.1, 1),
    theme: {
      ...defaults.theme,
      ...(obj.theme ?? {}),
      panelOpacity: clamp(Number(obj.theme?.panelOpacity ?? defaults.theme.panelOpacity), 0.35, 1),
      blurStrength: clamp(Number(obj.theme?.blurStrength ?? defaults.theme.blurStrength), 0, 28),
      cornerRadius: clamp(Number(obj.theme?.cornerRadius ?? defaults.theme.cornerRadius), 0, 24),
      animationSpeed: clamp(Number(obj.theme?.animationSpeed ?? defaults.theme.animationSpeed), 0.3, 2.5),
    },
    motionBlur: {
      ...defaults.motionBlur,
      ...(obj.motionBlur ?? {}),
      intensity: clamp(Number(obj.motionBlur?.intensity ?? defaults.motionBlur.intensity), 0, 1),
      durationMs: clamp(Number(obj.motionBlur?.durationMs ?? defaults.motionBlur.durationMs), 8, 120),
      qualitySamples: Math.round(clamp(Number(obj.motionBlur?.qualitySamples ?? defaults.motionBlur.qualitySamples), 2, 16)),
    },
    menuBlur: {
      ...defaults.menuBlur,
      ...(obj.menuBlur ?? {}),
      strength: clamp(Number(obj.menuBlur?.strength ?? defaults.menuBlur.strength), 0, 28),
      dimming: clamp(Number(obj.menuBlur?.dimming ?? defaults.menuBlur.dimming), 0, 0.9),
      opacity: clamp(Number(obj.menuBlur?.opacity ?? defaults.menuBlur.opacity), 0.3, 1),
    },
    nametags: { ...defaults.nametags, ...(obj.nametags ?? {}) },
    crosshair: { ...defaults.crosshair, ...(obj.crosshair ?? {}) },
    blockOutline: { ...defaults.blockOutline, ...(obj.blockOutline ?? {}) },
    itemPhysics: { ...defaults.itemPhysics, ...(obj.itemPhysics ?? {}) },
    colorGrading: { ...defaults.colorGrading, ...(obj.colorGrading ?? {}) },
    visualPacks: {
      enabled: obj.visualPacks?.enabled ?? defaults.visualPacks.enabled,
      packs:
        Array.isArray(obj.visualPacks?.packs) && obj.visualPacks.packs.length > 0
          ? obj.visualPacks.packs
          : defaults.visualPacks.packs,
    },
    handAura: { ...defaults.handAura, ...(obj.handAura ?? {}) },
    zoom: {
      ...defaults.zoom,
      ...(obj.zoom ?? {}),
      strength: clamp(Number(obj.zoom?.strength ?? defaults.zoom.strength), 1.5, 12),
      transitionSpeed: clamp(Number(obj.zoom?.transitionSpeed ?? defaults.zoom.transitionSpeed), 1, 20),
    },
    freelook: { ...defaults.freelook, ...(obj.freelook ?? {}) },
    shulkerPreview: { ...defaults.shulkerPreview, ...(obj.shulkerPreview ?? {}) },
    viewmodel: {
      ...defaults.viewmodel,
      ...(obj.viewmodel ?? {}),
      categories: {
        ...defaults.viewmodel.categories,
        ...(obj.viewmodel?.categories ?? {}),
      },
    },
    cosmetics: {
      ...defaults.cosmetics,
      ...(obj.cosmetics ?? {}),
      wingFlapSpeed: clamp(Number(obj.cosmetics?.wingFlapSpeed ?? defaults.cosmetics.wingFlapSpeed), 0.25, 2.5),
      wingSpread: clamp(Number(obj.cosmetics?.wingSpread ?? defaults.cosmetics.wingSpread), 0.6, 1.6),
      customCapeDataUrl: obj.cosmetics?.customCapeDataUrl ?? null,
      customCapeName: obj.cosmetics?.customCapeName ?? null,
      customCapeIsGif: Boolean(obj.cosmetics?.customCapeIsGif ?? false),
      useCustomCapeImage: Boolean(obj.cosmetics?.useCustomCapeImage ?? false),
      showcaseScene: obj.cosmetics?.showcaseScene ?? 'cherry-grove',
    },
    particles: { ...defaults.particles, ...(obj.particles ?? {}) },
    musicLyrics: {
      ...defaults.musicLyrics,
      ...(obj.musicLyrics ?? {}),
      lyricX: clamp(Number(obj.musicLyrics?.lyricX ?? defaults.musicLyrics.lyricX), 5, 95),
      lyricY: clamp(Number(obj.musicLyrics?.lyricY ?? defaults.musicLyrics.lyricY), 5, 92),
      lyricScale: clamp(Number(obj.musicLyrics?.lyricScale ?? defaults.musicLyrics.lyricScale), 0.65, 2.0),
      lyricOpacity: clamp(Number(obj.musicLyrics?.lyricOpacity ?? defaults.musicLyrics.lyricOpacity), 0.2, 1.0),
    },
    performance: { ...defaults.performance, ...(obj.performance ?? {}) },
    hudElements: {
      ...defaults.hudElements,
      ...(obj.hudElements ?? {}),
    },
    hudProfiles:
      Array.isArray(obj.hudProfiles) && obj.hudProfiles.length > 0 ? obj.hudProfiles : defaults.hudProfiles,
    keybinds: {
      ...defaults.keybinds,
      ...(obj.keybinds ?? {}),
    },
    favoriteModules: Array.isArray(obj.favoriteModules) ? obj.favoriteModules : defaults.favoriteModules,
    recentSettings: Array.isArray(obj.recentSettings) ? obj.recentSettings : defaults.recentSettings,
  };
}

function loadInitialConfig(): { config: ClientConfig; recoveredFromBackup: boolean } {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return { config: validateAndMergeConfig(JSON.parse(saved)), recoveredFromBackup: false };
    }
  } catch {
    try {
      const backup = localStorage.getItem(BACKUP_KEY);
      if (backup) {
        return { config: validateAndMergeConfig(JSON.parse(backup)), recoveredFromBackup: true };
      }
    } catch {
      // Fallback
    }
  }
  return { config: createDefaultConfig(), recoveredFromBackup: false };
}

export function formatKeyCodeLabel(code: string): string {
  if (!code) return 'Unbound';
  return code
    .replace(/^Key/, '')
    .replace(/^Digit/, '')
    .replace('ShiftRight', 'R-Shift')
    .replace('ShiftLeft', 'L-Shift')
    .replace('AltLeft', 'L-Alt')
    .replace('AltRight', 'R-Alt')
    .replace('ControlLeft', 'L-Ctrl')
    .replace('ControlRight', 'R-Ctrl');
}

export function useClientStore() {
  const initialRef = useRef<{ config: ClientConfig; recoveredFromBackup: boolean } | null>(null);
  if (!initialRef.current) {
    initialRef.current = loadInitialConfig();
  }

  const [config, setConfig] = useState<ClientConfig>(initialRef.current.config);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const [menuOpen, setMenuOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'studio' | 'hud' | 'wardrobe' | 'delivery'>('studio');

  const [musicState, setMusicState] = useState<MusicPlayerState>({
    tracks: BUILTIN_SYNCED_TRACKS,
    currentTrackId: BUILTIN_SYNCED_TRACKS[0].id,
    playing: true,
    positionSec: 0,
    fetchingLyrics: false,
  });

  const audioElRef = useRef<HTMLAudioElement | null>(null);

  const [world, setWorld] = useState<LiveWorldTelemetry>({
    fps: 144,
    frameTimeMs: 6.9,
    pingMs: 24,
    serverAddress: 'play.itsm3liodas.net',
    x: 128.4,
    y: 68.0,
    z: -412.7,
    yaw: 142,
    pitch: -8,
    biome: 'minecraft:cherry_grove',
    heldItemKey: 'sword',
    pressedKeys: { w: false, a: false, s: false, d: false, space: false, lmb: false, rmb: false },
    lmbCps: 0,
    rmbCps: 0,
    sessionSeconds: 0,
    zoomEngaged: false,
    freelookEngaged: false,
    freelookYawOffset: 0,
    freelookPitchOffset: 0,
  });

  const lmbTimestamps = useRef<number[]>([]);
  const rmbTimestamps = useRef<number[]>([]);
  const lastSavedStr = useRef<string>('');

  const pushToast = useCallback((title: string, detail?: string, tone: ToastNotice['tone'] = 'info') => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, title, detail, tone }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  }, []);

  useEffect(() => {
    if (initialRef.current?.recoveredFromBackup) {
      pushToast('Config Recovered from Backup', 'Corrupted primary data was safely restored.', 'warning');
    }
  }, [pushToast]);

  // Persistent save + rolling backup
  useEffect(() => {
    const handle = window.setTimeout(() => {
      try {
        const serialized = JSON.stringify(config);
        if (serialized !== lastSavedStr.current) {
          const prev = localStorage.getItem(STORAGE_KEY);
          if (prev) localStorage.setItem(BACKUP_KEY, prev);
          localStorage.setItem(STORAGE_KEY, serialized);
          lastSavedStr.current = serialized;
        }
      } catch {
        // Ignore storage quota errors
      }
    }, 220);
    return () => window.clearTimeout(handle);
  }, [config]);

  // Sync CSS theme variables cleanly
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--mc-accent', config.theme.accentColor);
    root.style.setProperty('--mc-accent-secondary', config.theme.secondaryColor);
    root.style.setProperty('--mc-radius', `${config.theme.cornerRadius}px`);
    root.style.setProperty(
      '--mc-menu-blur',
      `${config.menuBlur.enabled ? (config.menuBlur.performanceFriendly ? Math.min(8, config.menuBlur.strength) : config.menuBlur.strength) : 0}px`
    );
    const baseMs = Math.round(220 / Math.max(0.25, config.theme.animationSpeed));
    root.style.setProperty('--mc-anim-duration', config.theme.reducedMotion ? '0ms' : `${baseMs}ms`);
    if (config.theme.reducedMotion) {
      root.classList.add('mc-reduced-motion');
    } else {
      root.classList.remove('mc-reduced-motion');
    }
  }, [config.theme, config.menuBlur]);

  // Music timeline clock (syncs with real HTMLAudioElement when local audio file is loaded, otherwise ticks cleanly)
  useEffect(() => {
    const interval = window.setInterval(() => {
      setMusicState((ms) => {
        if (!ms.playing) return ms;
        const track = ms.tracks.find((t) => t.id === ms.currentTrackId) ?? ms.tracks[0];
        if (!track) return ms;
        if (track.audioUrl && audioElRef.current && !audioElRef.current.paused) {
          return { ...ms, positionSec: audioElRef.current.currentTime };
        }
        const nextPos = ms.positionSec + 0.25;
        if (nextPos >= track.durationSec) {
          const idx = ms.tracks.findIndex((t) => t.id === track.id);
          const nextTrack = ms.tracks[(idx + 1) % ms.tracks.length];
          return { ...ms, currentTrackId: nextTrack.id, positionSec: 0 };
        }
        return { ...ms, positionSec: nextPos };
      });
    }, 250);
    return () => window.clearInterval(interval);
  }, []);

  // Sync HTMLAudioElement for real uploaded audio files
  useEffect(() => {
    const track = musicState.tracks.find((t) => t.id === musicState.currentTrackId);
    if (!track?.audioUrl) {
      if (audioElRef.current) {
        audioElRef.current.pause();
      }
      return;
    }
    if (!audioElRef.current) {
      audioElRef.current = new Audio();
    }
    const el = audioElRef.current;
    if (el.src !== track.audioUrl) {
      el.src = track.audioUrl;
      el.onloadedmetadata = () => {
        if (Number.isFinite(el.duration) && el.duration > 1) {
          setMusicState((ms) => ({
            ...ms,
            tracks: ms.tracks.map((t) => (t.id === track.id ? { ...t, durationSec: Math.round(el.duration) } : t)),
          }));
        }
      };
    }
    if (musicState.playing) {
      el.play().catch(() => {});
    } else {
      el.pause();
    }
  }, [musicState.currentTrackId, musicState.playing, musicState.tracks]);

  // Session timer & CPS decay
  useEffect(() => {
    const timer = window.setInterval(() => {
      const now = performance.now();
      lmbTimestamps.current = lmbTimestamps.current.filter((t) => now - t < 1000);
      rmbTimestamps.current = rmbTimestamps.current.filter((t) => now - t < 1000);
      setWorld((w) => ({
        ...w,
        sessionSeconds: w.sessionSeconds + 1,
        lmbCps: lmbTimestamps.current.length,
        rmbCps: rmbTimestamps.current.length,
      }));
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  // Real browser keyboard & keybind listener
  useEffect(() => {
    const isTypingInInput = (target: EventTarget | null) => {
      if (!(target instanceof HTMLElement)) return false;
      const tag = target.tagName;
      return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || target.isContentEditable;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (isTypingInInput(e.target)) return;
      const code = e.code;

      if (code === config.keybinds.openMenu.key && !e.repeat) setMenuOpen((v) => !v);
      if (code === config.keybinds.hudEditor.key && !e.repeat) {
        setActiveTab('hud');
        setMenuOpen(true);
      }
      if (code === config.keybinds.wardrobe.key && !e.repeat) {
        setActiveTab('wardrobe');
        setMenuOpen(true);
      }
      if (code === config.keybinds.toggleCrosshair.key && !e.repeat) {
        setConfig((c) => ({ ...c, crosshair: { ...c.crosshair, enabled: !c.crosshair.enabled } }));
      }
      if (code === config.keybinds.toggleColorGrading.key && !e.repeat) {
        setConfig((c) => ({ ...c, colorGrading: { ...c.colorGrading, enabled: !c.colorGrading.enabled } }));
      }
      if (code === config.keybinds.resetCamera.key && !e.repeat) {
        setWorld((w) => ({ ...w, zoomEngaged: false, freelookEngaged: false, freelookYawOffset: 0, freelookPitchOffset: 0 }));
      }

      if (code === config.keybinds.zoom.key && config.zoom.enabled && !e.repeat) {
        setWorld((w) => ({ ...w, zoomEngaged: config.zoom.mode === 'Toggle' ? !w.zoomEngaged : true }));
      }
      if (code === config.keybinds.freelook.key && config.freelook.enabled && !e.repeat) {
        setWorld((w) => ({ ...w, freelookEngaged: config.freelook.mode === 'Toggle' ? !w.freelookEngaged : true }));
      }

      if (code === 'KeyW' || code === 'KeyA' || code === 'KeyS' || code === 'KeyD' || code === 'Space') {
        setWorld((w) => {
          const step = 0.28;
          const rad = (w.yaw * Math.PI) / 180;
          let dx = 0;
          let dz = 0;
          if (code === 'KeyW') {
            dx -= Math.sin(rad) * step;
            dz += Math.cos(rad) * step;
          } else if (code === 'KeyS') {
            dx += Math.sin(rad) * step;
            dz -= Math.cos(rad) * step;
          } else if (code === 'KeyA') {
            dx += Math.cos(rad) * step;
            dz += Math.sin(rad) * step;
          } else if (code === 'KeyD') {
            dx -= Math.cos(rad) * step;
            dz -= Math.sin(rad) * step;
          }
          return {
            ...w,
            x: Number((w.x + dx).toFixed(2)),
            z: Number((w.z + dz).toFixed(2)),
            pressedKeys: {
              ...w.pressedKeys,
              w: code === 'KeyW' ? true : w.pressedKeys.w,
              a: code === 'KeyA' ? true : w.pressedKeys.a,
              s: code === 'KeyS' ? true : w.pressedKeys.s,
              d: code === 'KeyD' ? true : w.pressedKeys.d,
              space: code === 'Space' ? true : w.pressedKeys.space,
            },
          };
        });
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      if (code === config.keybinds.zoom.key && config.zoom.mode === 'Hold') {
        setWorld((w) => ({ ...w, zoomEngaged: false }));
      }
      if (code === config.keybinds.freelook.key && config.freelook.mode === 'Hold') {
        setWorld((w) => ({ ...w, freelookEngaged: false, freelookYawOffset: 0, freelookPitchOffset: 0 }));
      }
      if (code === 'KeyW' || code === 'KeyA' || code === 'KeyS' || code === 'KeyD' || code === 'Space') {
        setWorld((w) => ({
          ...w,
          pressedKeys: {
            ...w.pressedKeys,
            w: code === 'KeyW' ? false : w.pressedKeys.w,
            a: code === 'KeyA' ? false : w.pressedKeys.a,
            s: code === 'KeyS' ? false : w.pressedKeys.s,
            d: code === 'KeyD' ? false : w.pressedKeys.d,
            space: code === 'Space' ? false : w.pressedKeys.space,
          },
        }));
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [config.keybinds, config.zoom.enabled, config.zoom.mode, config.freelook.enabled, config.freelook.mode]);

  const togglePlayMusic = useCallback(() => {
    setMusicState((ms) => ({ ...ms, playing: !ms.playing }));
  }, []);

  const stepTrack = useCallback((dir: 1 | -1) => {
    setMusicState((ms) => {
      const idx = ms.tracks.findIndex((t) => t.id === ms.currentTrackId);
      const nextIdx = (idx + dir + ms.tracks.length) % ms.tracks.length;
      if (audioElRef.current) audioElRef.current.currentTime = 0;
      return { ...ms, currentTrackId: ms.tracks[nextIdx].id, positionSec: 0, playing: true };
    });
  }, []);

  const seekMusic = useCallback((sec: number) => {
    if (audioElRef.current) audioElRef.current.currentTime = sec;
    setMusicState((ms) => ({ ...ms, positionSec: sec }));
  }, []);

  const selectTrack = useCallback((id: string) => {
    if (audioElRef.current) audioElRef.current.currentTime = 0;
    setMusicState((ms) => ({ ...ms, currentTrackId: id, positionSec: 0, playing: true }));
  }, []);

  const loadLocalAudioTrack = useCallback(
    (file: File, lrcText?: string) => {
      const url = URL.createObjectURL(file);
      const cleanName = file.name.replace(/\.[^.]+$/, '');
      const lyrics: SyncedLyricLine[] = lrcText
        ? parseLrcLyrics(lrcText)
        : [
            { timeSec: 0, text: `♪ Playing: ${cleanName}` },
            { timeSec: 5, text: 'Import an .lrc file or click Fetch Synced Lyrics below' },
          ];
      const newTrack: MusicTrack = {
        id: `local_${Date.now()}`,
        title: cleanName,
        artist: 'Local Audio File',
        album: 'Custom Track',
        durationSec: 180,
        coverColors: [config.theme.accentColor, config.theme.secondaryColor, '#0B0F1E'],
        bpm: 120,
        audioUrl: url,
        lyrics,
      };
      setMusicState((ms) => ({
        ...ms,
        tracks: [newTrack, ...ms.tracks],
        currentTrackId: newTrack.id,
        positionSec: 0,
        playing: true,
      }));
      pushToast('Audio Loaded', `Playing "${cleanName}" with Web Audio playback.`, 'success');
    },
    [config.theme.accentColor, config.theme.secondaryColor, pushToast]
  );

  const attachLrcToCurrentTrack = useCallback(
    (rawLrc: string) => {
      const parsed = parseLrcLyrics(rawLrc);
      if (parsed.length === 0) {
        pushToast('No Synced Lines Found', 'Make sure the .lrc file uses [mm:ss.xx] timestamps.', 'warning');
        return;
      }
      setMusicState((ms) => ({
        ...ms,
        tracks: ms.tracks.map((t) => (t.id === ms.currentTrackId ? { ...t, lyrics: parsed } : t)),
      }));
      pushToast('Synced Lyrics Loaded', `Attached ${parsed.length} timestamped lyric lines.`, 'success');
    },
    [pushToast]
  );

  const lookupOnlineLyrics = useCallback(
    async (artist: string, title: string) => {
      if (!artist.trim() || !title.trim()) return;
      setMusicState((ms) => ({ ...ms, fetchingLyrics: true }));
      const fetched = await fetchSyncedLyricsAsync(artist.trim(), title.trim());
      if (fetched && fetched.length > 0) {
        const customTrack: MusicTrack = {
          id: `lrclib_${Date.now()}`,
          title: title.trim(),
          artist: artist.trim(),
          album: 'LRCLIB Synced',
          durationSec: Math.max(45, Math.ceil(fetched[fetched.length - 1].timeSec + 6)),
          coverColors: [config.theme.accentColor, config.theme.secondaryColor, '#0F172A'],
          bpm: 120,
          lyrics: fetched,
        };
        setMusicState((ms) => ({
          ...ms,
          fetchingLyrics: false,
          tracks: [customTrack, ...ms.tracks],
          currentTrackId: customTrack.id,
          positionSec: 0,
          playing: true,
        }));
        pushToast('Synced Lyrics Found', `Loaded ${fetched.length} lines from LRCLIB for "${title}".`, 'success');
      } else {
        setMusicState((ms) => ({ ...ms, fetchingLyrics: false }));
        pushToast('No LRCLIB Match', 'Could not find synced lyrics for that artist/track.', 'warning');
      }
    },
    [config.theme.accentColor, config.theme.secondaryColor, pushToast]
  );

  const recordMouseClick = useCallback((button: 0 | 2, down: boolean) => {
    const now = performance.now();
    if (down) {
      if (button === 0) lmbTimestamps.current.push(now);
      if (button === 2) rmbTimestamps.current.push(now);
    }
    setWorld((w) => ({
      ...w,
      lmbCps: lmbTimestamps.current.length,
      rmbCps: rmbTimestamps.current.length,
      pressedKeys: {
        ...w.pressedKeys,
        lmb: button === 0 ? down : w.pressedKeys.lmb,
        rmb: button === 2 ? down : w.pressedKeys.rmb,
      },
    }));
  }, []);

  const recordSettingChange = useCallback((id: string, label: string, category: string) => {
    setConfig((c) => {
      const filtered = c.recentSettings.filter((r) => r.id !== id);
      return {
        ...c,
        recentSettings: [{ id, label, category, timestamp: Date.now() }, ...filtered].slice(0, 8),
      };
    });
  }, []);

  const applyThemePreset = useCallback(
    (themeId: ThemeId) => {
      setConfig((c) => ({
        ...c,
        theme: { ...THEME_PRESETS[themeId], reducedMotion: c.theme.reducedMotion },
      }));
      pushToast('Theme Applied', `Switched UI palette to ${themeId.toUpperCase()}.`, 'success');
    },
    [pushToast]
  );

  const applyMotionBlurPreset = useCallback((preset: MotionBlurPreset) => {
    const map: Record<MotionBlurPreset, { enabled: boolean; intensity: number; durationMs: number; qualitySamples: number }> = {
      Off: { enabled: false, intensity: 0, durationMs: 12, qualitySamples: 2 },
      Low: { enabled: true, intensity: 0.25, durationMs: 18, qualitySamples: 4 },
      Medium: { enabled: true, intensity: 0.45, durationMs: 32, qualitySamples: 6 },
      High: { enabled: true, intensity: 0.68, durationMs: 48, qualitySamples: 10 },
      Cinematic: { enabled: true, intensity: 0.85, durationMs: 68, qualitySamples: 14 },
      Custom: { enabled: true, intensity: 0.5, durationMs: 36, qualitySamples: 8 },
    };
    const next = map[preset];
    setConfig((c) => ({
      ...c,
      motionBlur: { ...c.motionBlur, ...next, preset },
    }));
  }, []);

  const applyColorGradingPreset = useCallback((preset: ColorGradingPreset) => {
    const vals = COLOR_GRADING_PRESETS[preset];
    setConfig((c) => ({
      ...c,
      colorGrading: { ...c.colorGrading, enabled: true, preset, ...vals },
    }));
  }, []);

  const applyPerformancePreset = useCallback(
    (preset: PerformancePreset) => {
      setConfig((c) => {
        if (preset === 'Ultra Quality') {
          return {
            ...c,
            performance: { preset, avoidPerFrameAllocations: true, cacheAssets: true, optimizeBlur: false, optimizeParticles: false, optimizeCosmetics: false, reducedQualityMode: false },
            menuBlur: { ...c.menuBlur, performanceFriendly: false },
            particles: { ...c.particles, performanceMode: false, quality: 'High' },
            handAura: { ...c.handAura, quality: 'High' },
          };
        }
        if (preset === 'Balanced') {
          return {
            ...c,
            performance: { preset, avoidPerFrameAllocations: true, cacheAssets: true, optimizeBlur: true, optimizeParticles: true, optimizeCosmetics: true, reducedQualityMode: false },
            menuBlur: { ...c.menuBlur, performanceFriendly: false },
            particles: { ...c.particles, performanceMode: false, quality: 'Balanced' },
            handAura: { ...c.handAura, quality: 'Balanced' },
          };
        }
        if (preset === 'Performance') {
          return {
            ...c,
            performance: { preset, avoidPerFrameAllocations: true, cacheAssets: true, optimizeBlur: true, optimizeParticles: true, optimizeCosmetics: true, reducedQualityMode: false },
            menuBlur: { ...c.menuBlur, performanceFriendly: true },
            motionBlur: { ...c.motionBlur, qualitySamples: Math.min(4, c.motionBlur.qualitySamples) },
            particles: { ...c.particles, performanceMode: true, quality: 'Low', amount: Math.min(14, c.particles.amount) },
            handAura: { ...c.handAura, quality: 'Low', particleAmount: Math.min(8, c.handAura.particleAmount) },
          };
        }
        return {
          ...c,
          performance: { preset, avoidPerFrameAllocations: true, cacheAssets: true, optimizeBlur: true, optimizeParticles: true, optimizeCosmetics: true, reducedQualityMode: true },
          menuBlur: { ...c.menuBlur, performanceFriendly: true, strength: Math.min(6, c.menuBlur.strength) },
          motionBlur: { ...c.motionBlur, enabled: false, preset: 'Off' },
          particles: { ...c.particles, performanceMode: true, quality: 'Low', amount: Math.min(8, c.particles.amount) },
          handAura: { ...c.handAura, quality: 'Low', particleAmount: 4 },
        };
      });
      pushToast('Performance Preset Applied', `${preset} profile active.`, 'success');
    },
    [pushToast]
  );

  const toggleFavoriteModule = useCallback((moduleId: string) => {
    setConfig((c) => {
      const exists = c.favoriteModules.includes(moduleId);
      return {
        ...c,
        favoriteModules: exists ? c.favoriteModules.filter((m) => m !== moduleId) : [...c.favoriteModules, moduleId],
      };
    });
  }, []);

  const updateHudElement = useCallback((id: HudElementId, patch: Partial<ClientConfig['hudElements'][HudElementId]>) => {
    setConfig((c) => ({
      ...c,
      hudElements: {
        ...c.hudElements,
        [id]: { ...c.hudElements[id], ...patch },
      },
    }));
  }, []);

  const resetAllHudElements = useCallback(() => {
    const fresh = createDefaultHudElements();
    setConfig((c) => ({ ...c, hudElements: fresh, hudScale: 1, hudOpacity: 0.9 }));
    pushToast('HUD Layout Reset', 'Restored all HUD elements to default positions.', 'info');
  }, [pushToast]);

  const equipCosmetic = useCallback((category: CosmeticCategory, cosmeticId: string | undefined) => {
    setConfig((c) => {
      const nextEquipped = { ...c.cosmetics.equipped };
      if (!cosmeticId || nextEquipped[category] === cosmeticId) {
        delete nextEquipped[category];
      } else {
        nextEquipped[category] = cosmeticId;
      }
      return {
        ...c,
        cosmetics: { ...c.cosmetics, equipped: nextEquipped },
      };
    });
  }, []);

  const toggleVisualPack = useCallback((packId: string) => {
    setConfig((c) => ({
      ...c,
      visualPacks: {
        ...c.visualPacks,
        packs: c.visualPacks.packs.map((p) => (p.id === packId ? { ...p, enabled: !p.enabled } : p)),
      },
    }));
  }, []);

  const importVisualPackJson = useCallback(
    (rawJson: string): boolean => {
      try {
        const parsed = JSON.parse(rawJson) as Partial<VisualPackEntry>;
        if (!parsed.name || !parsed.id || !Array.isArray(parsed.verifiedAssets)) {
          pushToast('Pack Rejected', 'Missing required pack metadata or asset manifest.', 'error');
          return false;
        }
        const forbidden = parsed.verifiedAssets.some((entry) => {
          const lower = String(entry).toLowerCase();
          return (
            lower.includes('..') ||
            lower.endsWith('.class') ||
            lower.endsWith('.jar') ||
            lower.endsWith('.js') ||
            lower.endsWith('.exe') ||
            lower.endsWith('.sh')
          );
        });
        if (forbidden) {
          pushToast('Security Validation Failed', 'Executable or path-traversal entry blocked!', 'error');
          return false;
        }
        const safePack: VisualPackEntry = {
          id: String(parsed.id),
          name: String(parsed.name),
          author: String(parsed.author ?? 'Local Creator'),
          version: String(parsed.version ?? '1.0.0'),
          mcFormat: String(parsed.mcFormat ?? 'pack_format 75 (MC 1.21.11)'),
          compatible: Boolean(parsed.compatible ?? true),
          enabled: true,
          description: String(parsed.description ?? 'Imported visual pack.'),
          license: String(parsed.license ?? 'Custom Local'),
          category: parsed.category ?? 'UI',
          swatchColors:
            Array.isArray(parsed.swatchColors) && parsed.swatchColors.length === 3
              ? parsed.swatchColors
              : ['#7C5CFF', '#38BDF8', '#0F172A'],
          verifiedAssets: parsed.verifiedAssets.map(String),
        };
        setConfig((c) => ({
          ...c,
          visualPacks: {
            ...c.visualPacks,
            packs: [safePack, ...c.visualPacks.packs.filter((p) => p.id !== safePack.id)],
          },
        }));
        pushToast('Visual Pack Verified & Loaded', safePack.name, 'success');
        return true;
      } catch {
        pushToast('Invalid Visual Pack', 'Could not parse pack JSON safely.', 'error');
        return false;
      }
    },
    [pushToast]
  );

  const keybindConflicts = useMemo(() => {
    const byKey: Record<string, KeybindActionId[]> = {};
    (Object.keys(config.keybinds) as KeybindActionId[]).forEach((action) => {
      const k = config.keybinds[action].key;
      if (!k) return;
      if (!byKey[k]) byKey[k] = [];
      byKey[k].push(action);
    });
    const conflicts: Record<KeybindActionId, KeybindActionId[]> = {} as Record<KeybindActionId, KeybindActionId[]>;
    (Object.keys(config.keybinds) as KeybindActionId[]).forEach((action) => {
      const k = config.keybinds[action].key;
      const list = k ? (byKey[k] ?? []).filter((other) => other !== action) : [];
      conflicts[action] = list;
    });
    return conflicts;
  }, [config.keybinds]);

  const exportFullConfig = useCallback(() => {
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `itsm3liodas-config-v${config.schemaVersion}.json`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast('Configuration Exported', `Saved itsm3liodas-config-v${config.schemaVersion}.json`, 'success');
  }, [config, pushToast]);

  const importFullConfig = useCallback(
    (rawJson: string) => {
      try {
        const parsed = JSON.parse(rawJson);
        const validated = validateAndMergeConfig(parsed);
        setConfig(validated);
        pushToast('Configuration Imported', 'Validated and applied settings safely.', 'success');
      } catch {
        pushToast('Import Failed', 'Invalid configuration JSON.', 'error');
      }
    },
    [pushToast]
  );

  const restoreBackupConfig = useCallback(() => {
    try {
      const backup = localStorage.getItem(BACKUP_KEY);
      if (!backup) {
        pushToast('No Backup Found', 'Make at least two changes to create a rolling backup.', 'warning');
        return;
      }
      setConfig(validateAndMergeConfig(JSON.parse(backup)));
      pushToast('Backup Restored', 'Rolled back to previous saved snapshot.', 'success');
    } catch {
      pushToast('Restore Failed', 'Backup snapshot could not be parsed.', 'error');
    }
  }, [pushToast]);

  const resetAllConfig = useCallback(() => {
    setConfig(createDefaultConfig());
    pushToast('Reset Complete', 'Restored all ItsM3liodas Client settings to safe defaults.', 'info');
  }, [pushToast]);

  return {
    config,
    setConfig,
    world,
    setWorld,
    musicState,
    togglePlayMusic,
    stepTrack,
    seekMusic,
    selectTrack,
    loadLocalAudioTrack,
    attachLrcToCurrentTrack,
    lookupOnlineLyrics,
    menuOpen,
    setMenuOpen,
    activeTab,
    setActiveTab,
    toasts,
    pushToast,
    recordMouseClick,
    recordSettingChange,
    applyThemePreset,
    applyMotionBlurPreset,
    applyColorGradingPreset,
    applyPerformancePreset,
    toggleFavoriteModule,
    updateHudElement,
    resetAllHudElements,
    equipCosmetic,
    toggleVisualPack,
    importVisualPackJson,
    keybindConflicts,
    exportFullConfig,
    importFullConfig,
    restoreBackupConfig,
    resetAllConfig,
  };
}
