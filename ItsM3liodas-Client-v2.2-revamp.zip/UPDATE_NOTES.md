# Update v2.1

- Removed `java.awt.Desktop` from the Minecraft screen to avoid runtime crashes on Java distributions without `java.desktop`.
- Spotify buttons now copy the selected Spotify search URL to the clipboard instead of trying to launch a desktop browser.
- Kept the existing client-side HUD, crosshair, themes, and module settings.
- Clamped the menu panel position for smaller game windows.

The visual-module switches remain experimental settings; they do not mean every rendering effect is implemented.

# Update v2.2 — Interface revamp

- Expanded the settings window from 400px to 540px wide and 420px tall for clearer spacing.
- Widened the navigation rail and content controls; visual modules now use two wider columns.
- Reworked module settings into a two-column layout and added saved controls for item-physics strength, block-outline color, cosmetic preset, and viewmodel X/Y/Z offsets.
- Kept the UI explicitly in legitimate visual/client utility mode; no combat modules or gameplay cheats were added.
- The experimental switches are still configuration placeholders unless a feature renderer/input hook exists.
- Spotify remains external search-link copy only; no playback or synced lyrics implementation.
- Build status: not compile-verified because Gradle distribution download could not resolve services.gradle.org in this environment.
