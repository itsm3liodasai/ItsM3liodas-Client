# Feature status — v2.2 source audit

## Implemented in source
- FPS, ping, coordinates, direction, local clock
- Armor count and durability; held item and biome; potion effect count and names
- Server address, keystrokes and client-brand HUD toggles
- Fifteen theme palette choices, accent presets, HUD scale/opacity and compact HUD
- HUD corner presets, background/accent-bar/text-shadow options
- Custom crosshair toggle, PLUS/DOT/RING styles, size, gap, thickness and colors
- Hold-to-zoom on C, restoring the previous FOV on release
- Spotify search-link copy shortcuts for Misery, Heat Waves and Love Nwantiti
- Wider v2.2 client settings interface with two-column visual-mod and module-settings pages
- Saved settings for experimental motion blur, Hand Aura, nametag, item physics, block outline, color grading, texture preset, shulker preview, viewmodel offsets, cosmetics and Spotify overlay switches

## Experimental placeholders — not yet wired to game rendering/input
- Motion blur, Hand Aura, Free Look, nametags, item physics and custom block outlines
- Color grading pipeline, texture editor, Shulker Preview, viewmodel renderer/editor and cosmetics
- Spotify playback and synchronized lyrics

## Explicit exclusions
- No KillAura, AimAssist, AutoClicker, Reach, Fly, Speed, X-ray, ESP, Scaffold, gameplay automation, packet manipulation or anti-cheat bypass.
- No in-game browser.

## Build verification
- ZIP integrity is checked at packaging.
- Java/Fabric compile is not verified; Gradle distribution download could not resolve services.gradle.org in this environment.
