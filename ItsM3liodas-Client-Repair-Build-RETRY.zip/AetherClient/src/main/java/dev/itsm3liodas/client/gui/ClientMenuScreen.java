package dev.itsm3liodas.client.gui;

import dev.itsm3liodas.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A compact, client-side settings interface. */
public final class ClientMenuScreen extends Screen {
    private int page = 0;
    private static final int ACCENT_DEFAULT = 0x45B7FF;

    public ClientMenuScreen() { super(Component.literal("ItsM3liodas Client")); }

    @Override protected void init() { rebuild(); }

    private int panelLeft() { return width / 2 - 200; }
    private int panelTop() { return height / 2 - 145; }

    private void rebuild() {
        clearWidgets();
        int left = panelLeft();
        int top = panelTop();
        int navX = left + 14;
        int contentX = left + 126;
        int contentW = 244;

        addRenderableWidget(nav("HUD", 0, navX, top + 67, page == 0));
        addRenderableWidget(nav("Appearance", 1, navX, top + 94, page == 1));
        addRenderableWidget(nav("Reset", 2, navX, top + 121, page == 2));
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + 14, top + 245, 96, 20).build());

        if (page == 0) {
            addRenderableWidget(Button.builder(Component.literal("FPS  " + state("showFps")), b -> flip("showFps"))
                    .bounds(contentX, top + 68, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Ping  " + state("showPing")), b -> flip("showPing"))
                    .bounds(contentX, top + 96, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Coordinates  " + state("showCoordinates")), b -> flip("showCoordinates"))
                    .bounds(contentX, top + 124, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Direction  " + state("showDirection")), b -> flip("showDirection"))
                    .bounds(contentX, top + 152, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Clock  " + state("showClock")), b -> flip("showClock"))
                    .bounds(contentX, top + 180, contentW, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Armor  " + state("showArmor")), b -> flip("showArmor"))
                    .bounds(contentX, top + 208, 116, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Effects  " + state("showEffects")), b -> flip("showEffects"))
                    .bounds(contentX + 122, top + 208, 122, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Gear %  " + state("showArmorDurability")), b -> flip("showArmorDurability"))
                    .bounds(contentX, top + 236, 78, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Held item  " + state("showHeldItem")), b -> flip("showHeldItem"))
                    .bounds(contentX + 82, top + 236, 80, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Biome  " + state("showBiome")), b -> flip("showBiome"))
                    .bounds(contentX + 166, top + 236, 78, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Potion names  " + state("showStatusEffectNames")), b -> flip("showStatusEffectNames"))
                    .bounds(contentX, top + 260, contentW, 20).build());
        } else if (page == 1) {
            addRenderableWidget(Button.builder(Component.literal("Theme  ·  " + ClientConfig.get().theme), b -> {
                String[] themes = {"DARK", "LIGHT", "BLUE", "CUSTOM"};
                int i = 0; for (; i < themes.length; i++) if (themes[i].equals(ClientConfig.get().theme)) break;
                ClientConfig.get().theme = themes[(i + 1) % themes.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 75, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Accent  ·  " + String.format("#%06X", ClientConfig.get().accent)), b -> {
                int[] colors = {0x00B2FF, 0x9B7BFF, 0x35D49A, 0xFF9D45, 0xFF6FAE};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().accent) break;
                ClientConfig.get().accent = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 107, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD scale  ·  " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 139, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("HUD opacity  ·  " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(contentX, top + 171, contentW, 24).build());
            addRenderableWidget(Button.builder(Component.literal("Compact HUD  ·  " + state("compactHud")), b -> flip("compactHud"))
                    .bounds(contentX, top + 203, contentW, 24).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Restore default settings"), b -> { ClientConfig.reset(); rebuild(); })
                    .bounds(contentX, top + 90, contentW, 26).build());
        }
    }

    private Button nav(String label, int target, int x, int y, boolean selected) {
        return Button.builder(Component.literal((selected ? "◆  " : "   ") + label), b -> { page = target; rebuild(); })
                .bounds(x, y, 96, 22).build();
    }

    private String state(String field) { return readBoolean(field) ? "ON" : "OFF"; }
    private void flip(String field) { writeBoolean(field, !readBoolean(field)); rebuild(); }
    private boolean readBoolean(String field) {
        try { return ClientConfig.Data.class.getField(field).getBoolean(ClientConfig.get()); }
        catch (ReflectiveOperationException ignored) { return false; }
    }
    private void writeBoolean(String field, boolean value) {
        try { ClientConfig.Data.class.getField(field).setBoolean(ClientConfig.get(), value); ClientConfig.save(); }
        catch (ReflectiveOperationException ignored) { }
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        int x = panelLeft(), y = panelTop();
        String theme = ClientConfig.get().theme;
        boolean light = theme.equals("LIGHT");
        int panel = light ? 0xF0F3F6FA : theme.equals("BLUE") ? 0xF0122038 : 0xF0111722;
        int sidebar = light ? 0xFFe7ebf1 : 0xFF090F19;
        int mainText = light ? 0xFF18202C : 0xFFF2F6FC;
        int muted = light ? 0xFF657184 : 0xFF91A0B4;
        int accent = 0xFF000000 | (ClientConfig.get().accent & 0xFFFFFF);
        int edge = light ? 0xFFD8DEE8 : 0xFF26364B;
        int card = light ? 0xFFE8EDF4 : 0xFF172333;
        // Layered shell and accent rail give the screen a distinct client-style frame.
        g.fill(x - 5, y - 5, x + 405, y + 305, 0x70000000);
        g.fill(x, y, x + 400, y + 300, 0xFF05080E);
        g.fill(x + 1, y + 1, x + 399, y + 299, panel);
        g.fill(x + 1, y + 1, x + 399, y + 4, accent);
        g.fill(x + 2, y + 49, x + 398, y + 50, edge);
        g.fill(x + 2, y + 51, x + 118, y + 298, sidebar);
        g.fill(x + 117, y + 51, x + 118, y + 298, edge);
        // Small brand mark and status chip.
        g.fill(x + 13, y + 11, x + 34, y + 32, accent);
        g.drawString(font, "✦", x + 19, y + 17, 0xFFFFFFFF, false);
        g.drawString(font, "ITSM3LIODAS", x + 42, y + 12, mainText, false);
        g.drawString(font, "CLIENT  /  FABRIC 1.21.11", x + 42, y + 27, muted, false);
        g.fill(x + 323, y + 13, x + 386, y + 34, light ? 0xFFDDEFE7 : 0xFF102D2B);
        g.fill(x + 331, y + 21, x + 336, y + 26, 0xFF45D69A);
        g.drawString(font, "LEGIT MODE", x + 340, y + 20, light ? 0xFF176B50 : 0xFF75E6B7, false);
        String heading = page == 0 ? "HUD MODULES" : page == 1 ? "CLIENT STYLE" : "CONFIGURATION";
        String sub = page == 0 ? "Toggle the information displayed in-game" : page == 1 ? "Personalise colours and interface behaviour" : "Restore the default client configuration";
        g.drawString(font, heading, x + 132, y + 14, mainText, false);
        g.drawString(font, sub, x + 132, y + 31, muted, false);
        // Content card surfaces sit behind the interactive controls.
        if (page == 0) {
            g.fill(x + 126, y + 61, x + 390, y + 284, card);
            g.fill(x + 126, y + 61, x + 129, y + 284, accent);
            g.drawString(font, "ON-SCREEN WIDGETS", x + 136, y + 54, muted, false);
        } else if (page == 1) {
            g.fill(x + 126, y + 67, x + 390, y + 245, card);
            g.fill(x + 126, y + 67, x + 129, y + 245, accent);
            g.drawString(font, "APPEARANCE OPTIONS", x + 136, y + 54, muted, false);
        } else {
            g.fill(x + 126, y + 82, x + 390, y + 145, card);
            g.fill(x + 126, y + 82, x + 129, y + 145, accent);
        }
        g.drawString(font, "RIGHT SHIFT  ·  OPEN MENU", x + 13, y + 275, muted, false);
        g.drawString(font, "ITS M3LIODAS CLIENT  /  v1.1", x + 252, y + 286, muted, false);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
}
