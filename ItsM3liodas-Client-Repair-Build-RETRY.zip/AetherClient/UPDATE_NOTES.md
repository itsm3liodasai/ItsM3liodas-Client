# Update notes

This incremental source update adds two HUD widgets:
- Server address (or Singleplayer)
- Keystrokes (W/A/S/D, Space, Shift, Sprint)

They are enabled by default and are controlled by the persistent client config fields
`showServerAddress` and `showKeystrokes` in `config/itsm3liodas-client.json`.

This is not the complete requested feature set. Motion blur, nametags, custom crosshair,
block outline settings, item physics, menu blur, Colorly-style grading, Bauloo-style texture
editing, Hand Aura, zoom/freelook, shulker preview, Spotify/lyrics, and browser are not
implemented in this update. Build with Java 21 and the included GitHub Actions workflow.
