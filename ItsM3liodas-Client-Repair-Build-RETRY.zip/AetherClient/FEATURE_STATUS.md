# ItsM3liodas Client — feature status

Target: Minecraft 1.21.11, Fabric, Java 21.

## Included in this source
- Right Shift opens the client settings screen.
- HUD: FPS, ping, XYZ coordinates, facing direction, local clock.
- HUD: armor count and durability, held item, biome, active effects and effect names.
- HUD: server address / Singleplayer label and keyboard state display (WASD, Space, Shift, Sprint).
- Appearance settings: Dark/Light/Blue/Custom theme selection, accent presets, HUD scale, opacity and compact mode.
- Local JSON configuration persistence.

## Not implemented yet
Motion blur, nametags, crosshair editor, block outline editor, item physics, menu blur, hitbox visuals, Hand Aura, viewmodel editor, Zoom, Free Look, Colorly-style grading, Bauloo-style texture editor, Shulker Preview, Spotify playback/lyrics, and embedded browser.

This status file is intentionally explicit. A feature is not considered implemented merely because it appears in a roadmap.
