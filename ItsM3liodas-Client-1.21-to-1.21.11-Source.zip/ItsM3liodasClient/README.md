# ItsM3liodas Client

Fabric-only client-side visual/QoL mod project. Requested main release targets: **1.21.1, 1.21.4, 1.21.8 and 1.21.11**. Java 21.

## Important build status

This ZIP updates the project metadata and GitHub Actions matrix for the requested 1.21.x targets. **The Java source has not yet been ported from the previous 26.3 API to the 1.21.x rendering and GUI APIs, so these matrix builds are not yet guaranteed to compile.** The workflow is a build attempt, not proof of compatibility. Do not publish the artifacts as working releases unless every matrix job passes and each JAR is tested in its matching game version.

## Current source features

- Right Shift settings screen (source carried forward; API port still required).
- Persistent HUD settings.
- FPS, ping, coordinates, direction, clock, armor count and active-effect count HUD concepts.
- Theme, accent, scale and opacity settings.
- Fabric only; no Forge or NeoForge.

## Requested but not yet implemented

A complete draggable HUD editor, performance optimization implementation, dedicated mod menu, custom icon in the name/TAB list, screenshot/resource-pack managers, custom chat/hotbar/scoreboard styling and other advanced visual features remain unfinished. A client-side name/TAB decoration may only be visible locally and cannot force other players to see it on a server.

## GitHub build

1. Upload the contents of this folder to the root of a GitHub repository.
2. Push to `main` to start the workflow, or use **Actions → Build ItsM3liodas Client → Run workflow**.
3. Each matrix job attempts a separate version build and uploads its JAR as an artifact if compilation succeeds.
4. Download artifacts from the completed Actions run.

## Local build

Install JDK 21 and Gradle 8.12, then run `gradle clean build`. CI supplies version-specific Minecraft, Fabric Loader and Fabric API properties.

## No false build claim

No successful compilation or in-game test is claimed for this updated archive. The source still needs version-specific API migration and testing before it is a working release.
