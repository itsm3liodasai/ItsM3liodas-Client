package dev.aether.client.gui;

import dev.aether.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Arrays;

public final class AetherScreen extends Screen {
    private int page = 0;
    public AetherScreen() { super(Component.literal("ItsM3liodas Client")); }
    @Override protected void init() { rebuild(); }

    private void rebuild() {
        clearWidgets();
        int left = this.width / 2 - 145;
        int top = this.height / 2 - 105;
        addRenderableWidget(Button.builder(Component.literal("HUD"), b -> { page = 0; rebuild(); }).bounds(left, top, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Appearance"), b -> { page = 1; rebuild(); }).bounds(left + 95, top, 95, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> { page = 2; rebuild(); }).bounds(left + 195, top, 95, 20).build());
        int y = top + 34;
        if (page == 0) {
            toggle(left, y, "FPS", "showFps"); y += 25;
            toggle(left, y, "Ping", "showPing"); y += 25;
            toggle(left, y, "Coordinates", "showCoordinates"); y += 25;
            toggle(left, y, "Direction", "showDirection"); y += 25;
            toggle(left, y, "Clock", "showClock"); y += 25;
            toggle(left, y, "Armor status", "showArmor"); y += 25;
            toggle(left, y, "Active-effect count", "showPotionStatus");
        } else if (page == 1) {
            addRenderableWidget(Button.builder(Component.literal("Theme: " + ClientConfig.get().theme), b -> {
                String[] themes = {"DARK", "LIGHT", "BLUE", "CUSTOM"};
                int next = (Arrays.asList(themes).indexOf(ClientConfig.get().theme) + 1) % themes.length;
                ClientConfig.get().theme = themes[next]; ClientConfig.save(); rebuild();
            }).bounds(left, y, 190, 20).build());
            y += 28;
            addRenderableWidget(Button.builder(Component.literal("Accent color: " + String.format("#%06X", ClientConfig.get().accent)), b -> {
                int[] colors = {0x4B8DFF, 0x8B5CF6, 0x22C55E, 0xF97316, 0xEC4899};
                int i = 0; for (; i < colors.length; i++) if (colors[i] == ClientConfig.get().accent) break;
                ClientConfig.get().accent = colors[(i + 1) % colors.length]; ClientConfig.save(); rebuild();
            }).bounds(left, y, 190, 20).build());
            y += 28;
            addRenderableWidget(Button.builder(Component.literal("HUD scale: " + String.format("%.2f", ClientConfig.get().hudScale)), b -> {
                ClientConfig.get().hudScale = ClientConfig.get().hudScale >= 1.5f ? 0.75f : ClientConfig.get().hudScale + 0.25f;
                ClientConfig.save(); rebuild();
            }).bounds(left, y, 190, 20).build());
            y += 28;
            addRenderableWidget(Button.builder(Component.literal("HUD opacity: " + Math.round(ClientConfig.get().hudOpacity * 100) + "%"), b -> {
                ClientConfig.get().hudOpacity = ClientConfig.get().hudOpacity <= 0.4f ? 1.0f : ClientConfig.get().hudOpacity - 0.15f;
                ClientConfig.save(); rebuild();
            }).bounds(left, y, 190, 20).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Reset all settings to defaults"), b -> { ClientConfig.reset(); rebuild(); })
                    .bounds(left, y, 220, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(this.width / 2 - 45, top + 225, 90, 20).build());
    }

    private void toggle(int x, int y, String label, String field) {
        boolean value = readBoolean(field);
        addRenderableWidget(Button.builder(Component.literal(label + ": " + (value ? "ON" : "OFF")), b -> {
            writeBoolean(field, !readBoolean(field)); rebuild();
        }).bounds(x, y, 190, 20).build());
    }
    private boolean readBoolean(String field) {
        try { return ClientConfig.Data.class.getField(field).getBoolean(ClientConfig.get()); }
        catch (ReflectiveOperationException ignored) { return false; }
    }
    private void writeBoolean(String field, boolean value) {
        try { ClientConfig.Data.class.getField(field).setBoolean(ClientConfig.get(), value); ClientConfig.save(); }
        catch (ReflectiveOperationException ignored) { }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        int x = this.width / 2 - 160, y = this.height / 2 - 125;
        String theme = ClientConfig.get().theme;
        int panel = switch (theme) {
            case "LIGHT" -> 0xEEF0F3F8;
            case "BLUE" -> 0xEE101F35;
            default -> 0xEE111722;
        };
        int text = theme.equals("LIGHT") ? 0xFF18202C : 0xFFFFFFFF;
        graphics.fill(x, y, x + 320, y + 270, panel);
        graphics.fill(x, y, x + 320, y + 3, 0xFF000000 | (ClientConfig.get().accent & 0xFFFFFF));
        graphics.text(this.font, "ITSM3LIODAS CLIENT", x + 15, y + 12, text, false);
        graphics.text(this.font, "VISUALS  /  CUSTOMIZATION  /  QOL", x + 15, y + 24, theme.equals("LIGHT") ? 0xFF566273 : 0xFF9BA9BC, false);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }
    @Override public boolean isPauseScreen() { return false; }
}
