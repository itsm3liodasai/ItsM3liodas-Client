package dev.aether.client;

import dev.aether.client.config.ClientConfig;
import dev.aether.client.gui.AetherScreen;
import dev.aether.client.hud.HudOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

public final class ItsM3liodasClient implements ClientModInitializer {
    public static final String MOD_ID = "itsm3liodasclient";
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        ClientConfig.load();
        HudOverlay.register();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.itsm3liodasclient.open_menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) client.gui.setScreen(new AetherScreen());
            }
        });
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public static Minecraft minecraft() {
        return Minecraft.getInstance();
    }
}
