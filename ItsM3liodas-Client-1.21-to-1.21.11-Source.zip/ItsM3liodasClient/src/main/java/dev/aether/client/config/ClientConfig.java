package dev.aether.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent settings for the client-only HUD and appearance. */
public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("itsm3liodasclient.json");
    private static Data data = new Data();
    private ClientConfig() {}
    public static Data get() { return data; }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Data loaded = GSON.fromJson(Files.readString(FILE), Data.class);
                if (loaded != null) data = loaded;
            }
        } catch (Exception ignored) { data = new Data(); }
        save();
    }
    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(data));
        } catch (IOException exception) {
            System.err.println("[ItsM3liodas Client] Could not save config: " + exception.getMessage());
        }
    }
    public static void reset() { data = new Data(); save(); }

    public static final class Data {
        public String theme = "DARK";
        public int accent = 0x4B8DFF;
        public float hudScale = 1.0f;
        public float hudOpacity = 0.92f;
        public boolean showFps = true;
        public boolean showPing = true;
        public boolean showCoordinates = true;
        public boolean showDirection = true;
        public boolean showClock = true;
        public boolean showArmor = true;
        public boolean showPotionStatus = true;
    }
}
