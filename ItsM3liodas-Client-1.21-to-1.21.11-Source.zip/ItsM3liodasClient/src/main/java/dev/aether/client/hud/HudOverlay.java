package dev.aether.client.hud;

import dev.aether.client.ItsM3liodasClient;
import dev.aether.client.config.ClientConfig;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Client-only information overlay. It reads local game state and never changes gameplay. */
public final class HudOverlay {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");
    private HudOverlay() {}

    public static void register() {
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.addLast(
                ItsM3liodasClient.id("information_hud"), HudOverlay::extract);
    }

    private static void extract(GuiGraphicsExtractor graphics, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        ClientConfig.Data config = ClientConfig.get();
        if (mc.player == null || mc.gui.hud.isHidden()) return;

        List<String> lines = new ArrayList<>();
        if (config.showFps) lines.add("FPS  " + mc.getFps());
        if (config.showPing && mc.getConnection() != null) {
            var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
            if (info != null) lines.add("PING  " + info.getLatency() + " ms");
        }
        if (config.showCoordinates) {
            lines.add(String.format(java.util.Locale.ROOT, "XYZ  %.1f  %.1f  %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (config.showDirection) lines.add("FACING  " + mc.player.getDirection().getName().toUpperCase(java.util.Locale.ROOT));
        if (config.showClock) lines.add("TIME  " + LocalTime.now().format(CLOCK));
        if (config.showArmor) {
            long pieces = mc.player.getInventory().armor.stream().filter(stack -> !stack.isEmpty()).count();
            lines.add("ARMOR  " + pieces + "/4");
        }
        if (config.showPotionStatus) lines.add("EFFECTS  " + mc.player.getActiveEffects().size());

        int x = 8, y = 8;
        int alpha = Math.max(0, Math.min(255, Math.round(config.hudOpacity * 255)));
        int background = (alpha << 24) | 0x101722;
        int accent = 0xFF000000 | (config.accent & 0xFFFFFF);
        float scale = Math.max(0.75f, Math.min(1.5f, config.hudScale));
        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        int rowHeight = 12;
        int width = 0;
        for (String line : lines) width = Math.max(width, mc.font.width(line));
        if (!lines.isEmpty()) {
            graphics.fill(x - 4, y - 4, x + width + 10, y + lines.size() * rowHeight + 4, background);
            graphics.fill(x - 4, y - 4, x - 2, y + lines.size() * rowHeight + 4, accent);
            for (String line : lines) {
                graphics.text(mc.font, Component.literal(line), x + 1, y, 0xFFF2F5FA, true);
                y += rowHeight;
            }
        }
        graphics.pose().popMatrix();
    }
}
